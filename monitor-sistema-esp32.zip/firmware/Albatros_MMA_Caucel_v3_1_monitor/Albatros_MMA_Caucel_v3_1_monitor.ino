#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <ArduinoOTA.h>
#include <Update.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Preferences.h>
#include <esp_task_wdt.h>
#include <esp_system.h>
#include <esp_arduino_version.h>
#include <mbedtls/sha256.h>
#include <mbedtls/version.h>

// =====================================================
// PINES RFID
// =====================================================

#define SS_PIN 5
#define RST_PIN 4

// =====================================================
// PINES LEDS Y BUZZER
// =====================================================

#define LED_VERDE 21
#define LED_ROJO 22
#define LED_AMARILLO 2

#define BUZZER 15

// =====================================================
// PINES CONTROL DE PUERTA
// =====================================================

#define PIN_RELE 26
#define PIN_IR 27
#define PIN_PUERTA 34

// =====================================================
// PANTALLA LCD 1602 I2C
// =====================================================

#define LCD_SDA 32
#define LCD_SCL 33
#define LCD_DIRECCION 0x27

LiquidCrystal_I2C lcd(
  LCD_DIRECCION,
  16,
  2
);

bool lcdDisponible = false;

// =====================================================
// LÓGICA DEL HARDWARE
// =====================================================

/*
  Relé K2 conectado a IN2.

  Según las pruebas realizadas:

  LOW  = electroimán activado, puerta bloqueada.
  HIGH = electroimán desactivado, puerta liberada.
*/

const uint8_t RELE_BLOQUEAR = LOW;
const uint8_t RELE_DESBLOQUEAR = HIGH;

/*
  Sensor infrarrojo:
  LOW cuando detecta.

  Sensor magnético:
  LOW cuando la puerta está cerrada.
*/

const uint8_t IR_DETECTADO = LOW;
const uint8_t PUERTA_CERRADA = LOW;

// =====================================================
// TIEMPOS DE PUERTA
// =====================================================

const unsigned long TIEMPO_DESBLOQUEADA = 7000;
const unsigned long AVISO_AMARILLO_ANTES_CIERRE = 3000;
const unsigned long ESPERA_ANTES_BLOQUEO = 2000;
const unsigned long TIEMPO_CONFIRMACION_CIERRE = 500;
const unsigned long TIEMPO_LED_ROJO_BLOQUEO = 500;
const unsigned long INTERVALO_PARPADEO_CIERRE = 200;
const unsigned long ANTIRREBOTE_IR = 500;

// =====================================================
// REDES WIFI
// =====================================================

struct RedWiFi {
  const char* ssid;
  const char* password;
};

#include "albatros_secrets.h"

RedWiFi redes[] = {
  {WIFI_SSID_1, WIFI_PASSWORD_1},
  {WIFI_SSID_2, WIFI_PASSWORD_2},
  {WIFI_SSID_3, WIFI_PASSWORD_3},
  {WIFI_SSID_4, WIFI_PASSWORD_4}
};

const int totalRedes =
  sizeof(redes) / sizeof(redes[0]);

// =====================================================
// CONFIGURACIÓN OTA
// =====================================================

const char* NOMBRE_OTA = "Puerta-Albatros";
const char* CLAVE_OTA = ALBATROS_OTA_PASSWORD;

bool otaConfigurado = false;
String nombreOTAUnico = "";
bool wifiEstuvoConectado = false;
unsigned long ultimoIntentoWiFi = 0;
int indiceRedPreferida = 0;

const unsigned long INTERVALO_REINTENTO_WIFI = 15000;
const unsigned long LIMITE_RECONEXION_WIFI = 3500;

// =====================================================
// ENDPOINTS
// =====================================================

const char* endpointAcceso =
  "https://www.albatrosbjj.com/api/rfid";

const char* endpointPendiente =
  "https://www.albatrosbjj.com/api/rfid/vinculacion-pendiente";

const char* endpointVincular =
  "https://www.albatrosbjj.com/api/rfid/vincular";

const char* endpointHeartbeat =
  "https://www.albatrosbjj.com/api/dispositivo/heartbeat";

const char* endpointControlPuerta =
  "https://www.albatrosbjj.com/api/control-puerta";

const char* VERSION_FIRMWARE = "albatros-control-blindado-3.1-monitor";
const char* DEVICE_GROUP = "MMA_CAUCEL";

// Clave del ESP32. Debe coincidir exactamente con
// RFID_DEVICE_KEY configurada en Vercel.
const char* RFID_DEVICE_KEY =
  ALBATROS_DEVICE_KEY;

// =====================================================
// TARJETAS ESPECIALES
// =====================================================

const String RFID_MAESTROS[] = {
  "02A70307",
  "1113B964",
  "8B3B741C",
  "01380C64",
  "40CCE553"
};

const int TOTAL_RFID_MAESTROS =
  sizeof(RFID_MAESTROS) /
  sizeof(RFID_MAESTROS[0]);

const String RFID_CONFIG = "532C2FAD940001";
const String DISPOSITIVO = "Recepcion";

// =====================================================
// RFID
// =====================================================

MFRC522 rfid(SS_PIN, RST_PIN);

// =====================================================
// ESTADO GENERAL
// =====================================================

bool alarmaActiva = false;
bool alarmaPuertaAbierta = false;
bool beepEnCurso = false;
bool modoVinculacion = false;
bool puertaLiberadaRemota = false;
bool controlPuertaConfirmado = false;

Preferences preferencias;
String ultimoComandoConfirmado = "";
String bootId = "";
bool watchdogConfigurado = false;
bool lecturaRFIDEnCurso = false;
unsigned long inicioLecturaRFID = 0;
unsigned long ultimaVueltaLoop = 0;
uint8_t fallosRFIDConsecutivos = 0;
uint8_t reiniciosBrownoutConsecutivos = 0;
unsigned long proteccionAlimentacionHasta = 0;
bool brownoutEstabilizado = false;

// Enclavamiento de arranque: mientras sea false, ninguna ruta del programa
// puede energizar el electroiman. Se libera solamente al final de setup(),
// despues de LCD, GPIO, sensores, RFID, pruebas de salidas, WiFi y OTA.
bool arranqueHardwareCompleto = false;
bool rfidDisponible = true;
unsigned long proximoIntentoRFIDDegradado = 0;
const unsigned long INTERVALO_RECUPERACION_RFID_DEGRADADO = 30000;

const unsigned long LIMITE_CICLO_RFID = 12000;
const unsigned long TIEMPO_ESTABLE_PARA_LIMPIAR_BROWNOUT = 5UL * 60UL * 1000UL;

// Recuperación dirigida después de energizar el electroimán. La prueba
// aislada confirmó que el RC522 lee de forma estable y que el fallo aparece
// después del ciclo físico de puerta, por lo que no reiniciamos el lector de
// manera periódica ni durante una lectura normal.
bool recuperacionPostBloqueoPendiente = false;
unsigned long momentoBloqueoElectrico = 0;
uint8_t intentosRecuperacionPostBloqueo = 0;
const unsigned long ESPERA_ESTABILIZACION_POST_BLOQUEO = 700;
const uint8_t MAX_INTENTOS_RECUPERACION_POST_BLOQUEO = 3;

String vinculacionId = "";
String vinculacionSede = "";
unsigned long momentoInicioVinculacion = 0;
const unsigned long TIEMPO_MAXIMO_VINCULACION = 90000;

String ultimoRFID = "Ninguno";
String ultimoAlumno = "Ninguno";

int menuConfig = 0;

// =====================================================
// FUNCIONES DE PANTALLA LCD
// =====================================================

String textoLCD(String texto) {
  texto.replace("á", "a");
  texto.replace("é", "e");
  texto.replace("í", "i");
  texto.replace("ó", "o");
  texto.replace("ú", "u");
  texto.replace("Á", "A");
  texto.replace("É", "E");
  texto.replace("Í", "I");
  texto.replace("Ó", "O");
  texto.replace("Ú", "U");
  texto.replace("ñ", "n");
  texto.replace("Ñ", "N");

  if (texto.length() > 16) {
    texto = texto.substring(0, 16);
  }

  while (texto.length() < 16) {
    texto += " ";
  }

  return texto;
}

void mostrarLCD(
  String linea1,
  String linea2 = ""
) {
  if (!lcdDisponible) {
    return;
  }

  lcd.setCursor(0, 0);
  lcd.print(textoLCD(linea1));
  lcd.setCursor(0, 1);
  lcd.print(textoLCD(linea2));
}

void iniciarLCD() {
  Wire.begin(
    LCD_SDA,
    LCD_SCL
  );

  Wire.beginTransmission(
    LCD_DIRECCION
  );

  lcdDisponible =
    Wire.endTransmission() == 0;

  if (!lcdDisponible) {
    Serial.println(
      "LCD no detectada en 0x27"
    );

    return;
  }

  lcd.init();
  lcd.backlight();
  lcd.clear();

  mostrarLCD(
    "ALBATROS",
    "Iniciando..."
  );

  Serial.println(
    "LCD 1602 iniciada en 0x27"
  );
}

// =====================================================
// ESTADOS DE PUERTA
// =====================================================

enum EstadoPuerta {
  ESPERANDO_CIERRE_INICIAL,
  PUERTA_BLOQUEADA,
  PUERTA_LIBERADA_REMOTA,
  PUERTA_DESBLOQUEADA,
  ESPERANDO_CIERRE,
  ESPERANDO_BLOQUEO,
  CONFIRMANDO_CIERRE,
  INDICANDO_BLOQUEO
};

EstadoPuerta estadoPuerta =
  ESPERANDO_CIERRE_INICIAL;

// =====================================================
// VARIABLES DE TIEMPO DE PUERTA
// =====================================================

unsigned long momentoDesbloqueo = 0;
unsigned long momentoCierre = 0;
unsigned long momentoIndicacionPuerta = 0;
unsigned long ultimoParpadeoCierre = 0;
unsigned long ultimaDeteccionIR = 0;
unsigned long ultimoHeartbeat = 0;
unsigned long ultimoIntentoHeartbeat = 0;
unsigned long ultimaConsultaControlPuerta = 0;

const unsigned long INTERVALO_HEARTBEAT = 120000;
const unsigned long INTERVALO_REINTENTO_HEARTBEAT = 15000;
const unsigned long ESPERA_INICIAL_HEARTBEAT = 5000;
// Los errores se deduplican en RAM y viajan dentro del heartbeat. Aunque el
// heartbeat compruebe comandos cada dos minutos, el bloque de monitor solo se
// adjunta cada diez minutos y únicamente cuando contiene eventos.
const unsigned long INTERVALO_ENVIO_MONITOR = 600000;
const uint8_t MAX_EVENTOS_MONITOR = 10;
unsigned long ultimoEnvioMonitor = 0;

struct EventoMonitor {
  String level;
  String code;
  String message;
  unsigned long uptimeMs;
  uint16_t count;
};

EventoMonitor eventosMonitor[MAX_EVENTOS_MONITOR];
uint8_t totalEventosMonitor = 0;

void registrarEventoMonitor(
  const char* level,
  const char* code,
  const char* message
) {
  // Un mismo código se acumula en lugar de crear una escritura o una línea por
  // repetición. Los mensajes son constantes y nunca incluyen UID o alumnos.
  for (uint8_t i = 0; i < totalEventosMonitor; i++) {
    if (eventosMonitor[i].code == code) {
      eventosMonitor[i].level = level;
      eventosMonitor[i].message = String(message).substring(0, 160);
      eventosMonitor[i].uptimeMs = millis();
      if (eventosMonitor[i].count < 999) eventosMonitor[i].count++;
      return;
    }
  }

  if (totalEventosMonitor == MAX_EVENTOS_MONITOR) {
    for (uint8_t i = 1; i < MAX_EVENTOS_MONITOR; i++) {
      eventosMonitor[i - 1] = eventosMonitor[i];
    }
    totalEventosMonitor--;
  }

  EventoMonitor& evento = eventosMonitor[totalEventosMonitor++];
  evento.level = level;
  evento.code = code;
  evento.message = String(message).substring(0, 160);
  evento.uptimeMs = millis();
  evento.count = 1;
}

void limpiarEventosMonitor() {
  for (uint8_t i = 0; i < totalEventosMonitor; i++) {
    eventosMonitor[i].level = "";
    eventosMonitor[i].code = "";
    eventosMonitor[i].message = "";
    eventosMonitor[i].uptimeMs = 0;
    eventosMonitor[i].count = 0;
  }
  totalEventosMonitor = 0;
}
// Dos sedes comparten este controlador. Veinte segundos conservan una
// respuesta razonable y reducen en 60 % las consultas frente a v2.7.
const unsigned long INTERVALO_CONTROL_PUERTA = 20000;
const unsigned long ESPERA_INICIAL_CONTROL_PUERTA = 3000;

bool irAnterior = false;
bool aperturaIniciadaPorRFID = false;
bool estadoParpadeoCierre = false;

String ultimaUidProcesada = "";
unsigned long momentoUltimaLecturaRFID = 0;
unsigned long momentoSinTarjeta = 0;
unsigned long ultimaReinicializacionRFID = 0;

bool mismaTarjetaDebeRetirarse = false;

const unsigned long TIEMPO_RETIRO_TARJETA = 250;
const unsigned long INTERVALO_REVISION_RFID = 30000;

// =====================================================
// VARIABLES DE ALARMA
// =====================================================

unsigned long ultimoCambioBuzzer = 0;
bool estadoBuzzerAlarma = false;

// =====================================================
// VARIABLES DE PARPADEO DE VINCULACIÓN
// =====================================================

unsigned long ultimoParpadeoVinculacion = 0;
bool estadoParpadeoVinculacion = false;

// =====================================================
// LEDS
// =====================================================

void apagarLeds() {
  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_AMARILLO, LOW);
  digitalWrite(LED_ROJO, LOW);
}

// =====================================================
// LECTURA RFID
// =====================================================

String uidToString() {
  String uid = "";

  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) {
      uid += "0";
    }

    uid += String(
      rfid.uid.uidByte[i],
      HEX
    );
  }

  uid.toUpperCase();

  return uid;
}

bool esTarjetaMaestra(const String& uid) {
  for (
    int i = 0;
    i < TOTAL_RFID_MAESTROS;
    i++
  ) {
    if (uid == RFID_MAESTROS[i]) {
      return true;
    }
  }

  return false;
}

// =====================================================
// FUNCIONES DE PUERTA
// =====================================================

bool puertaEstaCerrada() {
  return digitalRead(PIN_PUERTA)
    == PUERTA_CERRADA;
}

bool sensorIRDetectado() {
  return digitalRead(PIN_IR)
    == IR_DETECTADO;
}

bool bloquearPuerta() {
  // Proteccion principal contra caidas de tension durante el encendido.
  // esperarConServicios() ejecuta la maquina de estados aun dentro de setup();
  // por eso la proteccion debe estar aqui, justo antes del unico punto que
  // puede aplicar corriente al iman.
  if (!arranqueHardwareCompleto) {
    if (digitalRead(PIN_RELE) != RELE_DESBLOQUEAR) {
      desbloquearPuerta();
    }

    Serial.println("Bloqueo aplazado: hardware aun iniciando");
    estadoPuerta = puertaEstaCerrada()
      ? ESPERANDO_BLOQUEO
      : ESPERANDO_CIERRE_INICIAL;
    momentoCierre = millis();
    return false;
  }

  if (puertaLiberadaRemota) {
    Serial.println("Bloqueo ignorado: liberacion remota activa");
    desbloquearPuerta();
    estadoPuerta = PUERTA_LIBERADA_REMOTA;
    return false;
  }

  // Tras una caída de tensión se mantiene el electroimán sin corriente. La
  // espera crece ante brownouts repetidos y rompe el ciclo de reinicios por
  // carga excesiva al volver a energizar el imán.
  if ((long)(proteccionAlimentacionHasta - millis()) > 0) {
    if (digitalRead(PIN_RELE) != RELE_DESBLOQUEAR) desbloquearPuerta();
    estadoPuerta = puertaEstaCerrada()
      ? ESPERANDO_BLOQUEO
      : ESPERANDO_CIERRE_INICIAL;
    return false;
  }

  digitalWrite(
    PIN_RELE,
    RELE_BLOQUEAR
  );

  // El electroimán acaba de recibir corriente. Damos tiempo a que la línea
  // eléctrica se estabilice antes de tocar SPI/I2C.
  momentoBloqueoElectrico = millis();
  recuperacionPostBloqueoPendiente = true;
  intentosRecuperacionPostBloqueo = 0;

  Serial.println(
    "PUERTA BLOQUEADA - IMAN ACTIVADO"
  );
  return true;
}

void desbloquearPuerta() {
  digitalWrite(
    PIN_RELE,
    RELE_DESBLOQUEAR
  );

  // Si la puerta vuelve a liberarse antes de la recuperación, no tocamos los
  // buses mientras el sistema está cambiando de estado.
  recuperacionPostBloqueoPendiente = false;

  Serial.println(
    "PUERTA LIBERADA - IMAN DESACTIVADO"
  );
}

void aplicarControlPuertaRemoto(
  bool liberar,
  const String& origen
) {
  if (
    controlPuertaConfirmado &&
    puertaLiberadaRemota == liberar
  ) {
    // Refuerza el estado físico aunque otro ciclo haya intentado cambiarlo.
    if (liberar && digitalRead(PIN_RELE) != RELE_DESBLOQUEAR) {
      desbloquearPuerta();
      estadoPuerta = PUERTA_LIBERADA_REMOTA;
    }
    return;
  }

  puertaLiberadaRemota = liberar;
  controlPuertaConfirmado = true;
  preferencias.putBool("puertaLibre", liberar);
  preferencias.putBool("puertaCfg", true);

  Serial.print("CONTROL REMOTO DE PUERTA (");
  Serial.print(origen);
  Serial.print("): ");
  Serial.println(liberar ? "LIBERADA" : "BLOQUEADA");

  if (liberar) {
    alarmaActiva = false;
    alarmaPuertaAbierta = false;
    estadoBuzzerAlarma = false;
    digitalWrite(BUZZER, LOW);
    aperturaIniciadaPorRFID = false;
    desbloquearPuerta();
    estadoPuerta = PUERTA_LIBERADA_REMOTA;
    apagarLeds();
    digitalWrite(LED_VERDE, HIGH);
    mostrarLCD("PUERTA LIBERADA", "Control remoto");
    return;
  }

  apagarLeds();
  aperturaIniciadaPorRFID = false;

  if (puertaEstaCerrada()) {
    alarmaPuertaAbierta = false;
    momentoCierre = millis();
    ultimoParpadeoCierre = millis();
    estadoParpadeoCierre = false;
    estadoPuerta = ESPERANDO_BLOQUEO;
    mostrarLCD("Puerta cerrada", "Bloqueando...");
  } else {
    alarmaPuertaAbierta = true;
    estadoPuerta = ESPERANDO_CIERRE;
    digitalWrite(LED_ROJO, HIGH);
    mostrarLCD("PUERTA ABIERTA", "Cierre la puerta");
  }
}

void iniciarDesbloqueo(
  const String& motivo,
  bool iniciadoPorRFID
) {
  if (puertaLiberadaRemota) {
    desbloquearPuerta();
    estadoPuerta = PUERTA_LIBERADA_REMOTA;
    Serial.print("Apertura temporal omitida; puerta ya liberada por web. Motivo: ");
    Serial.println(motivo);
    return;
  }

  /*
    Si la puerta ya fue liberada por una tarjeta,
    una detección posterior del infrarrojo no debe
    cambiar el origen ni cancelar la futura alarma.
  */
  if (
    aperturaIniciadaPorRFID &&
    !iniciadoPorRFID
  ) {
    Serial.println(
      "IR detectado durante acceso RFID; se conserva el origen RFID"
    );
    return;
  }

  desbloquearPuerta();

  momentoDesbloqueo = millis();
  estadoPuerta = PUERTA_DESBLOQUEADA;
  aperturaIniciadaPorRFID = iniciadoPorRFID;
  alarmaPuertaAbierta = false;

  /*
    Una apertura por proximidad se muestra en verde.
    Una alarma de acceso denegado siempre tiene prioridad.
  */
  if (!iniciadoPorRFID && !alarmaActiva) {
    apagarLeds();
    digitalWrite(LED_VERDE, HIGH);
  }

  Serial.print("Apertura iniciada por: ");
  Serial.println(motivo);

  Serial.println(
    "Temporizador de 7 segundos iniciado"
  );
}

// =====================================================
// ACTUALIZAR CONTROL DE PUERTA
// =====================================================

void actualizarPuerta() {
  const unsigned long ahora = millis();

  /*
    La liberación remota tiene prioridad absoluta sobre temporizadores,
    reed, RFID e infrarrojo. Mientras esté activa nunca energizamos el imán
    ni generamos alarma por puerta abierta.
  */
  if (puertaLiberadaRemota) {
    irAnterior = sensorIRDetectado();
    alarmaPuertaAbierta = false;
    aperturaIniciadaPorRFID = false;
    recuperacionPostBloqueoPendiente = false;

    if (digitalRead(PIN_RELE) != RELE_DESBLOQUEAR) {
      desbloquearPuerta();
    }

    estadoPuerta = PUERTA_LIBERADA_REMOTA;

    if (!alarmaActiva && !modoVinculacion && !beepEnCurso) {
      apagarLeds();
      digitalWrite(LED_VERDE, HIGH);
    }

    return;
  }

  const bool irActual =
    sensorIRDetectado();

  const bool nuevaDeteccionIR =
    irActual &&
    !irAnterior &&
    ahora - ultimaDeteccionIR
      >= ANTIRREBOTE_IR;

  irAnterior = irActual;

  /*
    El sensor IR permite salida libre.

    Puede abrir la puerta aunque esté
    activada una alarma por una tarjeta
    rechazada.
  */
  if (nuevaDeteccionIR) {
    ultimaDeteccionIR = ahora;

    Serial.println(
      "Sensor infrarrojo detectado"
    );

    iniciarDesbloqueo(
      "sensor infrarrojo",
      false
    );
  }

  switch (estadoPuerta) {

    case PUERTA_LIBERADA_REMOTA:
      // Solo se alcanza durante el cambio de liberada a bloqueada. La función
      // aplicarControlPuertaRemoto() asigna inmediatamente el siguiente estado.
      break;

    // -------------------------------------------------
    // Puerta abierta durante el arranque
    // -------------------------------------------------

    case ESPERANDO_CIERRE_INICIAL:

      if (puertaEstaCerrada()) {
        Serial.println(
          "Puerta cerrada al iniciar"
        );

        Serial.println(
          "Esperando 2 segundos para bloquear"
        );

        momentoCierre = ahora;
        estadoPuerta =
          ESPERANDO_BLOQUEO;
      }

      break;

    // -------------------------------------------------
    // Puerta bloqueada
    // -------------------------------------------------

    case PUERTA_BLOQUEADA:

      /*
        Aquí espera una tarjeta válida
        o una detección del sensor IR.
      */

      break;

    // -------------------------------------------------
    // Puerta liberada durante 10 segundos
    // -------------------------------------------------

    case PUERTA_DESBLOQUEADA:

      /*
        En aperturas por proximidad:
        - verde durante la mayor parte del tiempo;
        - amarillo durante los últimos 3 segundos.
      */
      if (
        !aperturaIniciadaPorRFID &&
        !alarmaActiva &&
        !alarmaPuertaAbierta
      ) {
        const unsigned long tiempoTranscurrido =
          ahora - momentoDesbloqueo;

        apagarLeds();

        if (
          tiempoTranscurrido >=
          TIEMPO_DESBLOQUEADA -
          AVISO_AMARILLO_ANTES_CIERRE
        ) {
          digitalWrite(LED_AMARILLO, HIGH);
        } else {
          digitalWrite(LED_VERDE, HIGH);
        }
      }

      if (
        ahora - momentoDesbloqueo
        >= TIEMPO_DESBLOQUEADA
      ) {
        Serial.println(
          "Finalizaron los 7 segundos"
        );

        if (puertaEstaCerrada()) {
          Serial.println(
            "La puerta está cerrada"
          );

          /*
            El ciclo iniciado por RFID ya terminó.
            Se libera el origen del acceso para que
            el sensor infrarrojo pueda volver a abrir.
          */
          aperturaIniciadaPorRFID = false;
          alarmaPuertaAbierta = false;

          Serial.println(
            "Esperando 2 segundos para bloquear"
          );

          momentoCierre = ahora;

          estadoPuerta =
            ESPERANDO_BLOQUEO;
        } else {
          Serial.println(
            "La puerta sigue abierta"
          );

          Serial.println(
            "Esperando a que cierre"
          );

          estadoPuerta =
            ESPERANDO_CIERRE;

          /*
            Sin importar si abrió RFID o proximidad,
            una puerta que permanece abierta genera alarma.
          */
          alarmaPuertaAbierta = true;
          apagarLeds();
          digitalWrite(LED_ROJO, HIGH);

          Serial.println(
            "ALARMA: la puerta permanece abierta"
          );
        }
      }

      break;

    // -------------------------------------------------
    // Esperando cierre de puerta
    // -------------------------------------------------

    case ESPERANDO_CIERRE:

      if (puertaEstaCerrada()) {
        alarmaPuertaAbierta = false;
        aperturaIniciadaPorRFID = false;

        if (!alarmaActiva) {
          digitalWrite(LED_ROJO, LOW);
        }

        Serial.println(
          "La puerta acaba de cerrarse"
        );

        Serial.println(
          "Esperando 2 segundos para bloquear"
        );

        momentoCierre = ahora;
        ultimoParpadeoCierre = ahora;
        estadoParpadeoCierre = false;

        estadoPuerta =
          ESPERANDO_BLOQUEO;
      }

      break;

    // -------------------------------------------------
    // Espera de seguridad antes de bloquear
    // -------------------------------------------------

    case ESPERANDO_BLOQUEO:

      /*
        Si la puerta vuelve a abrirse
        antes de terminar los 2 segundos,
        se cancela el bloqueo.
      */

      if (!puertaEstaCerrada()) {
        Serial.println(
          "La puerta se abrió antes del bloqueo"
        );

        alarmaPuertaAbierta = true;
        apagarLeds();
        digitalWrite(LED_ROJO, HIGH);

        estadoPuerta =
          ESPERANDO_CIERRE;

        break;
      }

      /*
        Durante los 2 segundos de comprobación,
        el LED amarillo parpadea sin usar delay().
      */
      if (!alarmaActiva) {
        if (
          ahora - ultimoParpadeoCierre >=
          INTERVALO_PARPADEO_CIERRE
        ) {
          ultimoParpadeoCierre = ahora;
          estadoParpadeoCierre =
            !estadoParpadeoCierre;

          digitalWrite(LED_VERDE, LOW);
          digitalWrite(LED_ROJO, LOW);
          digitalWrite(
            LED_AMARILLO,
            estadoParpadeoCierre ? HIGH : LOW
          );
        }
      }

      if (
        ahora - momentoCierre
        >= ESPERA_ANTES_BLOQUEO
      ) {
        /*
          La puerta permaneció cerrada durante toda
          la comprobación: verde 0.5 s para confirmarlo.
        */
        apagarLeds();
        digitalWrite(LED_VERDE, HIGH);

        momentoIndicacionPuerta = ahora;
        estadoPuerta = CONFIRMANDO_CIERRE;
      }

      break;

    // -------------------------------------------------
    // Confirmación verde de puerta cerrada
    // -------------------------------------------------

    case CONFIRMANDO_CIERRE:

      if (!puertaEstaCerrada()) {
        alarmaPuertaAbierta = true;
        apagarLeds();
        digitalWrite(LED_ROJO, HIGH);
        estadoPuerta = ESPERANDO_CIERRE;
        break;
      }

      if (
        ahora - momentoIndicacionPuerta >=
        TIEMPO_CONFIRMACION_CIERRE
      ) {
        if (!bloquearPuerta()) break;

        aperturaIniciadaPorRFID = false;
        alarmaPuertaAbierta = false;

        apagarLeds();
        digitalWrite(LED_ROJO, HIGH);

        momentoIndicacionPuerta = ahora;
        estadoPuerta = INDICANDO_BLOQUEO;
      }

      break;

    // -------------------------------------------------
    // Indicación roja breve después de bloquear
    // -------------------------------------------------

    case INDICANDO_BLOQUEO:

      if (
        ahora - momentoIndicacionPuerta >=
        TIEMPO_LED_ROJO_BLOQUEO
      ) {
        if (!alarmaActiva && !alarmaPuertaAbierta) {
          apagarLeds();
        }

        estadoPuerta = PUERTA_BLOQUEADA;

        Serial.println(
          "Sistema listo para otro acceso"
        );
      }

      break;
  }
}

// =====================================================
// ACTUALIZAR ALARMA SIN DELAY
// =====================================================

void actualizarAlarma() {
  /*
    Mientras beep() controla físicamente el buzzer,
    esta función no debe apagarlo.
  */
  if (beepEnCurso) {
    return;
  }

  const bool debePitar =
    alarmaActiva ||
    alarmaPuertaAbierta;

  if (!debePitar) {
    estadoBuzzerAlarma = false;
    digitalWrite(BUZZER, LOW);
    return;
  }

  const unsigned long ahora = millis();

  if (
    ahora - ultimoCambioBuzzer >= 150
  ) {
    ultimoCambioBuzzer = ahora;

    estadoBuzzerAlarma =
      !estadoBuzzerAlarma;

    digitalWrite(
      BUZZER,
      estadoBuzzerAlarma
        ? HIGH
        : LOW
    );
  }
}

// =====================================================
// PARPADEO DE VINCULACIÓN SIN DELAY
// =====================================================

void actualizarParpadeoVinculacion() {
  if (!modoVinculacion) {
    estadoParpadeoVinculacion = false;
    return;
  }

  const unsigned long ahora = millis();

  if (
    ahora - ultimoParpadeoVinculacion
    >= 250
  ) {
    ultimoParpadeoVinculacion = ahora;

    estadoParpadeoVinculacion =
      !estadoParpadeoVinculacion;

    digitalWrite(
      LED_VERDE,
      estadoParpadeoVinculacion
        ? HIGH
        : LOW
    );

    digitalWrite(
      LED_ROJO,
      estadoParpadeoVinculacion
        ? HIGH
        : LOW
    );

    digitalWrite(
      LED_AMARILLO,
      LOW
    );
  }
}

void actualizarCaducidadVinculacion() {
  if (
    !modoVinculacion ||
    momentoInicioVinculacion == 0 ||
    millis() - momentoInicioVinculacion < TIEMPO_MAXIMO_VINCULACION
  ) {
    return;
  }

  Serial.println("Vinculacion cancelada por tiempo agotado");
  modoVinculacion = false;
  vinculacionId = "";
  vinculacionSede = "";
  momentoInicioVinculacion = 0;
  apagarLeds();

  if (puertaLiberadaRemota) {
    digitalWrite(LED_VERDE, HIGH);
    mostrarLCD("PUERTA LIBERADA", "Control remoto");
  } else {
    mostrarLCD("Vinculacion", "Tiempo agotado");
  }
}

// =====================================================
// RECUPERACIÓN POST-ELECTROIMÁN
// =====================================================

bool reinicializarRC522PostBloqueo() {
  Serial.println("Recuperando RC522 despues del bloqueo...");

  // Reinicio físico real del MFRC522. Esto es más fuerte que confiar solo en
  // VersionReg, porque un RC522 puede seguir contestando por SPI aunque su
  // estado RF haya quedado alterado por un transitorio eléctrico.
  SPI.end();

  pinMode(RST_PIN, OUTPUT);
  digitalWrite(RST_PIN, LOW);
  delay(8);
  digitalWrite(RST_PIN, HIGH);
  delay(50);

  SPI.begin();
  delay(10);
  rfid.PCD_Init();
  delay(25);

  const byte version = rfid.PCD_ReadRegister(MFRC522::VersionReg);
  Serial.print("RC522 VersionReg post-bloqueo: 0x");
  Serial.println(version, HEX);

  ultimaReinicializacionRFID = millis();
  fallosRFIDConsecutivos = 0;
  momentoSinTarjeta = 0;

  if (version == 0x00 || version == 0xFF) {
    Serial.println("RC522 no respondio despues de reinicializar");
    registrarEventoMonitor("error", "RFID_UNAVAILABLE", "El lector RFID no respondió después de reinicializar");
    return false;
  }

  Serial.println("RC522 recuperado correctamente");
  if (!rfidDisponible) {
    registrarEventoMonitor("recovery", "RFID_RECOVERED", "El lector RFID volvió a responder correctamente");
  }
  return true;
}

void reinicializarLCDPostBloqueo() {
  // El LCD mostró caracteres corruptos durante la misma falla eléctrica. Se
  // vuelve a inicializar la interfaz I2C y la secuencia HD44780 después de que
  // el electroimán ya se estabilizó.
  Wire.end();
  delay(8);
  Wire.begin(LCD_SDA, LCD_SCL);
  delay(10);

  Wire.beginTransmission(LCD_DIRECCION);
  lcdDisponible = Wire.endTransmission() == 0;

  if (!lcdDisponible) {
    Serial.println("LCD no respondio durante recuperacion post-bloqueo");
    return;
  }

  lcd.init();
  lcd.backlight();
  lcd.clear();

  if (alarmaActiva) {
    mostrarLCD("ACCESO DENEGADO", "Alarma activa");
  } else if (alarmaPuertaAbierta) {
    mostrarLCD("PUERTA ABIERTA", "Cierre la puerta");
  } else {
    mostrarLCD("Sistema listo", "Acerque tarjeta");
  }

  Serial.println("LCD/I2C recuperado post-bloqueo");
}

void actualizarRecuperacionPostBloqueo() {
  if (!recuperacionPostBloqueoPendiente) {
    return;
  }

  if (
    millis() - momentoBloqueoElectrico <
    ESPERA_ESTABILIZACION_POST_BLOQUEO
  ) {
    return;
  }

  // Nunca alteramos SPI/I2C durante una lectura, pitido activo, puerta abierta
  // o transición de seguridad. El modo de vinculación por sí solo no bloquea
  // esta recuperación: de lo contrario el loop esperaría indefinidamente y
  // nunca podría leer la tarjeta del alumno después de volver a bloquear.
  if (
    lecturaRFIDEnCurso ||
    beepEnCurso ||
    !puertaEstaCerrada() ||
    digitalRead(PIN_RELE) != RELE_BLOQUEAR ||
    (
      estadoPuerta != PUERTA_BLOQUEADA &&
      estadoPuerta != INDICANDO_BLOQUEO
    )
  ) {
    return;
  }

  recuperacionPostBloqueoPendiente = false;
  intentosRecuperacionPostBloqueo++;

  const bool rfidOk = reinicializarRC522PostBloqueo();
  reinicializarLCDPostBloqueo();

  if (rfidOk) {
    rfidDisponible = true;
    intentosRecuperacionPostBloqueo = 0;
    return;
  }

  if (
    intentosRecuperacionPostBloqueo <
    MAX_INTENTOS_RECUPERACION_POST_BLOQUEO
  ) {
    Serial.println("Se reintentara recuperar RC522 tras estabilizar la alimentacion");
    // Reiniciamos la referencia temporal. Nunca guardamos un instante futuro:
    // millis() es unsigned y una resta contra un valor futuro podria aparentar
    // un intervalo gigantesco al producirse wrap-around.
    momentoBloqueoElectrico = millis();
    recuperacionPostBloqueoPendiente = true;
    return;
  }

  // El fallo del RC522 no justifica reiniciar todo el controlador: el registro
  // de campo demostro que eso crea un ciclo infinito al volver a energizar el
  // iman. Conservamos puerta, IR, LCD, WiFi y OTA, y reintentamos el lector en
  // segundo plano con una cadencia baja.
  rfidDisponible = false;
  intentosRecuperacionPostBloqueo = 0;
  proximoIntentoRFIDDegradado = millis() +
    INTERVALO_RECUPERACION_RFID_DEGRADADO;
  Serial.println("RC522 fuera de servicio; ESP32 continua sin reiniciarse");
  mostrarLCD("RFID temporalmente", "fuera de servicio");
}

void actualizarRecuperacionRFIDDegradada() {
  if (
    rfidDisponible ||
    recuperacionPostBloqueoPendiente ||
    lecturaRFIDEnCurso ||
    beepEnCurso ||
    (long)(millis() - proximoIntentoRFIDDegradado) < 0
  ) {
    return;
  }

  Serial.println("Reintentando RC522 en modo degradado...");
  const bool recuperado = reinicializarRC522PostBloqueo();
  reinicializarLCDPostBloqueo();

  if (recuperado) {
    rfidDisponible = true;
    fallosRFIDConsecutivos = 0;
    Serial.println("RC522 disponible nuevamente sin reiniciar ESP32");
    mostrarLCD("Sistema listo", "Acerque tarjeta");
    return;
  }

  proximoIntentoRFIDDegradado = millis() +
    INTERVALO_RECUPERACION_RFID_DEGRADADO;
  Serial.println("RC522 sigue sin responder; nuevo intento en 30 segundos");
}

// =====================================================
// SERVICIOS PRINCIPALES
// =====================================================

void actualizarServicios() {
  if (watchdogConfigurado) {
    esp_task_wdt_reset();
  }

  actualizarPuerta();
  actualizarAlarma();
  actualizarCaducidadVinculacion();
  actualizarParpadeoVinculacion();
  actualizarRecuperacionPostBloqueo();
  actualizarRecuperacionRFIDDegradada();

  if (
    !brownoutEstabilizado
    && reiniciosBrownoutConsecutivos > 0
    && millis() >= TIEMPO_ESTABLE_PARA_LIMPIAR_BROWNOUT
  ) {
    reiniciosBrownoutConsecutivos = 0;
    preferencias.putUChar("brownouts", 0);
    brownoutEstabilizado = true;
    Serial.println("Alimentacion estable; contador de brownout restablecido");
  }

  if (otaConfigurado) {
    ArduinoOTA.handle();
  }
}

// =====================================================
// ESPERA SIN DESCUIDAR LA PUERTA
// =====================================================

void esperarConServicios(
  unsigned long tiempo
) {
  const unsigned long inicio = millis();

  while (millis() - inicio < tiempo) {
    actualizarServicios();
    delay(2);
  }
}

// =====================================================
// BUZZER
// =====================================================

void beep(
  int veces,
  int tiempo = 120
) {
  beepEnCurso = true;
  digitalWrite(BUZZER, LOW);

  for (int i = 0; i < veces; i++) {
    digitalWrite(BUZZER, HIGH);
    esperarConServicios(tiempo);

    digitalWrite(BUZZER, LOW);
    esperarConServicios(tiempo);
  }

  beepEnCurso = false;
  ultimoCambioBuzzer = millis();
  actualizarAlarma();
}

// =====================================================
// CONFIGURAR OTA
// =====================================================

void configurarOTA() {
  if (
    WiFi.status() != WL_CONNECTED ||
    otaConfigurado
  ) {
    return;
  }

  if (nombreOTAUnico.length() == 0) {
    nombreOTAUnico = String(NOMBRE_OTA) + "-" + obtenerIdDispositivo().substring(6);
  }
  ArduinoOTA.setHostname(nombreOTAUnico.c_str());
  ArduinoOTA.setPassword(CLAVE_OTA);

  ArduinoOTA.onStart([]() {
    Serial.println();
    Serial.println(
      "Iniciando actualización OTA"
    );

  });

  ArduinoOTA.onEnd([]() {
    Serial.println();
    Serial.println(
      "Actualización OTA finalizada"
    );
  });

  ArduinoOTA.onProgress(
    [](unsigned int progreso,
       unsigned int total) {

      unsigned int porcentaje =
        (progreso * 100) / total;

      Serial.printf(
        "Progreso OTA: %u%%\r",
        porcentaje
      );
    }
  );

  ArduinoOTA.onError(
    [](ota_error_t error) {
      Serial.printf(
        "Error OTA [%u]: ",
        error
      );

      if (error == OTA_AUTH_ERROR) {
        Serial.println(
          "Error de autenticación"
        );
      } else if (
        error == OTA_BEGIN_ERROR
      ) {
        Serial.println(
          "Error al iniciar"
        );
      } else if (
        error == OTA_CONNECT_ERROR
      ) {
        Serial.println(
          "Error de conexión"
        );
      } else if (
        error == OTA_RECEIVE_ERROR
      ) {
        Serial.println(
          "Error de recepción"
        );
      } else if (
        error == OTA_END_ERROR
      ) {
        Serial.println(
          "Error al finalizar"
        );
      }
    }
  );

  ArduinoOTA.begin();
  otaConfigurado = true;

  Serial.print(
    "OTA disponible como: "
  );

  Serial.println(nombreOTAUnico);
}

// =====================================================
// WIFI
// =====================================================

bool conectarWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);

  for (
    int i = 0;
    i < totalRedes;
    i++
  ) {
    Serial.print(
      "Intentando WiFi: "
    );

    Serial.println(
      redes[i].ssid
    );

    // Conserva la radio encendida para permitir recuperación y OTA.
    WiFi.disconnect(false);
    esperarConServicios(300);

    WiFi.begin(
      redes[i].ssid,
      redes[i].password
    );

    const unsigned long inicio =
      millis();

    while (
      WiFi.status() != WL_CONNECTED &&
      millis() - inicio < 5000
    ) {
      actualizarServicios();

      delay(20);

      if (
        (millis() - inicio) % 500 < 30
      ) {
        Serial.print(".");
      }
    }

    if (
      WiFi.status() == WL_CONNECTED
    ) {
      Serial.println();

      Serial.print(
        "WiFi conectado: "
      );

      Serial.println(
        redes[i].ssid
      );

      Serial.print("IP: ");
      Serial.println(
        WiFi.localIP()
      );

      configurarOTA();
      wifiEstuvoConectado = true;
      indiceRedPreferida = i;
      ultimoIntentoWiFi = 0;

      esperarConServicios(1000);

      return true;
    }

    Serial.println();
    Serial.println(
      "No se pudo conectar"
    );

    WiFi.disconnect(false);
    esperarConServicios(500);
  }

  beep(3, 250);

  return false;
}

bool verificarWiFi() {
  if (
    WiFi.status() == WL_CONNECTED
  ) {
    wifiEstuvoConectado = true;

    if (!otaConfigurado) {
      configurarOTA();
    }

    return true;
  }

  /*
    Durante una lectura no recorremos todas las redes durante más de
    veinte segundos. Se intenta recuperar la última conexión durante
    un máximo breve; si no vuelve, la operación falla y el loop queda
    inmediatamente disponible para sensores, RFID y puerta.
  */
  if (wifiEstuvoConectado) {
    wifiEstuvoConectado = false;
  }

  const unsigned long ahora = millis();
  if (
    ultimoIntentoWiFi != 0 &&
    ahora - ultimoIntentoWiFi < INTERVALO_REINTENTO_WIFI
  ) {
    return false;
  }

  ultimoIntentoWiFi = ahora;

  /*
    WiFi.reconnect() únicamente vuelve a intentar el último AP. Si esa red
    desaparece, la v2.7 podía permanecer fuera de línea aunque otra red de la
    lista estuviera disponible. Cada intento prueba una red y, si falla, deja
    preparada la siguiente sin bloquear el controlador durante veinte
    segundos consecutivos.
  */
  const int indiceIntento = indiceRedPreferida;
  Serial.print("Reconectando WiFi con: ");
  Serial.println(redes[indiceIntento].ssid);

  WiFi.disconnect(false);
  esperarConServicios(80);
  WiFi.begin(
    redes[indiceIntento].ssid,
    redes[indiceIntento].password
  );

  const unsigned long inicio = millis();
  while (
    WiFi.status() != WL_CONNECTED &&
    millis() - inicio < LIMITE_RECONEXION_WIFI
  ) {
    actualizarServicios();
    delay(10);
  }

  if (WiFi.status() != WL_CONNECTED) {
    indiceRedPreferida =
      (indiceIntento + 1) % totalRedes;

    Serial.print("WiFi no disponible; siguiente intento: ");
    Serial.println(redes[indiceRedPreferida].ssid);
    registrarEventoMonitor("warning", "WIFI_UNAVAILABLE", "No fue posible conectar con una red configurada");
    return false;
  }

  indiceRedPreferida = indiceIntento;
  wifiEstuvoConectado = true;
  ultimoIntentoWiFi = 0;
  configurarOTA();

  Serial.print("WiFi recuperado: ");
  Serial.println(redes[indiceRedPreferida].ssid);
  registrarEventoMonitor("recovery", "WIFI_RECOVERED", "La conexión WiFi fue recuperada");
  return true;
}

bool condicionesSegurasParaReinicio() {
  return puertaEstaCerrada()
    && digitalRead(PIN_RELE) == RELE_BLOQUEAR
    && estadoPuerta == PUERTA_BLOQUEADA
    && !puertaLiberadaRemota
    && !alarmaActiva
    && !alarmaPuertaAbierta
    && !lecturaRFIDEnCurso
    && !recuperacionPostBloqueoPendiente;
}

void prepararReinicioSeguro(const String& motivo) {
  Serial.print("Preparando reinicio seguro: ");
  Serial.println(motivo);
  digitalWrite(BUZZER, LOW);
  apagarLeds();
  desbloquearPuerta();
  delay(500);
}

// =====================================================
// ESTADO EN LÍNEA DEL CONTROLADOR
// =====================================================

String obtenerIdDispositivo() {
  const uint64_t chipId = ESP.getEfuseMac();
  char identificador[24];

  snprintf(
    identificador,
    sizeof(identificador),
    "ESP32-%04X%08X",
    (uint16_t)(chipId >> 32),
    (uint32_t)chipId
  );

  return String(identificador);
}

bool sha256EsperadoValido(const String& sha) {
  if (sha.length() != 64) {
    return false;
  }

  for (size_t i = 0; i < sha.length(); i++) {
    const char c = sha.charAt(i);
    const bool esHex =
      (c >= '0' && c <= '9') ||
      (c >= 'a' && c <= 'f') ||
      (c >= 'A' && c <= 'F');

    if (!esHex) {
      return false;
    }
  }

  return true;
}

String sha256AHex(const unsigned char hash[32]) {
  static const char hex[] = "0123456789abcdef";
  String resultado;
  resultado.reserve(64);

  for (int i = 0; i < 32; i++) {
    resultado += hex[(hash[i] >> 4) & 0x0F];
    resultado += hex[hash[i] & 0x0F];
  }

  return resultado;
}

bool actualizarFirmwareRemoto(
  const String& url,
  const String& nuevaVersion,
  const String& sha256Esperado,
  size_t tamanoEsperado
) {
  const size_t TAMANO_MINIMO = 100000;
  const size_t TAMANO_MAXIMO = 1300000;
  const unsigned long TIMEOUT_SIN_DATOS = 8000;

  if (
    WiFi.status() != WL_CONNECTED ||
    recuperacionPostBloqueoPendiente ||
    lecturaRFIDEnCurso ||
    modoVinculacion ||
    beepEnCurso ||
    alarmaActiva ||
    alarmaPuertaAbierta ||
    estadoPuerta != PUERTA_BLOQUEADA ||
    !puertaEstaCerrada() ||
    digitalRead(PIN_RELE) != RELE_BLOQUEAR ||
    sensorIRDetectado() ||
    !url.startsWith("https://") ||
    nuevaVersion.length() == 0 ||
    nuevaVersion == VERSION_FIRMWARE ||
    !sha256EsperadoValido(sha256Esperado) ||
    tamanoEsperado < TAMANO_MINIMO ||
    tamanoEsperado > TAMANO_MAXIMO
  ) {
    Serial.println("OTA remota rechazada: estado o metadatos inseguros");
    registrarEventoMonitor("warning", "OTA_REJECTED", "La actualización fue rechazada por condiciones de seguridad");
    return false;
  }

  Serial.print("OTA remota iniciada. Version objetivo: ");
  Serial.println(nuevaVersion);
  mostrarLCD("Actualizando", "No desconectar");
  apagarLeds();
  digitalWrite(LED_AMARILLO, HIGH);

  HTTPClient http;
  http.setReuse(false);
  http.useHTTP10(true);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setConnectTimeout(3000);
  http.setTimeout(8000);

  if (!http.begin(url)) {
    Serial.println("OTA: no se pudo abrir la URL privada");
    registrarEventoMonitor("error", "OTA_CONNECTION_ERROR", "No fue posible abrir el paquete de actualización");
    apagarLeds();
    mostrarLCD("Sistema listo", "Acerque tarjeta");
    return false;
  }

  const int codigo = http.GET();
  if (codigo != HTTP_CODE_OK) {
    Serial.print("OTA: descarga rechazada HTTP ");
    Serial.println(codigo);
    http.end();
    apagarLeds();
    mostrarLCD("Sistema listo", "Acerque tarjeta");
    return false;
  }

  const int longitudServidor = http.getSize();
  if (
    longitudServidor > 0 &&
    static_cast<size_t>(longitudServidor) != tamanoEsperado
  ) {
    Serial.println("OTA: tamano HTTP distinto al autorizado");
    http.end();
    apagarLeds();
    mostrarLCD("Sistema listo", "Acerque tarjeta");
    return false;
  }

  if (!Update.begin(tamanoEsperado)) {
    Serial.print("OTA: no se pudo preparar particion: ");
    Update.printError(Serial);
    http.end();
    apagarLeds();
    mostrarLCD("Sistema listo", "Acerque tarjeta");
    return false;
  }

  mbedtls_sha256_context shaContexto;
  mbedtls_sha256_init(&shaContexto);
#if MBEDTLS_VERSION_MAJOR >= 3
  int shaEstado = mbedtls_sha256_starts(&shaContexto, 0);
#else
  int shaEstado = mbedtls_sha256_starts_ret(&shaContexto, 0);
#endif

  if (shaEstado != 0) {
    Serial.println("OTA: no se pudo iniciar SHA-256");
    mbedtls_sha256_free(&shaContexto);
    Update.abort();
    http.end();
    apagarLeds();
    mostrarLCD("Sistema listo", "Acerque tarjeta");
    return false;
  }

  WiFiClient* stream = http.getStreamPtr();
  uint8_t buffer[2048];
  size_t recibidos = 0;
  unsigned long ultimoDato = millis();
  bool fallo = false;
  bool salidaDetectada = false;

  while (recibidos < tamanoEsperado) {
    if (watchdogConfigurado) {
      esp_task_wdt_reset();
    }

    const bool irAhora = sensorIRDetectado();
    if (
      !puertaEstaCerrada() ||
      digitalRead(PIN_RELE) != RELE_BLOQUEAR ||
      alarmaActiva ||
      alarmaPuertaAbierta ||
      irAhora
    ) {
      salidaDetectada = irAhora;
      Serial.println("OTA abortada: cambio de seguridad en la puerta");
      fallo = true;
      break;
    }

    const int disponibles = stream->available();
    if (disponibles > 0) {
      const size_t faltan = tamanoEsperado - recibidos;
      const size_t porLeer = min(
        static_cast<size_t>(disponibles),
        min(sizeof(buffer), faltan)
      );

      const int leidos = stream->readBytes(buffer, porLeer);
      if (leidos <= 0) {
        fallo = true;
        break;
      }

      const size_t escritos = Update.write(buffer, static_cast<size_t>(leidos));
      if (escritos != static_cast<size_t>(leidos)) {
        Serial.print("OTA: fallo de escritura: ");
        Update.printError(Serial);
        fallo = true;
        break;
      }

#if MBEDTLS_VERSION_MAJOR >= 3
      shaEstado = mbedtls_sha256_update(&shaContexto, buffer, static_cast<size_t>(leidos));
#else
      shaEstado = mbedtls_sha256_update_ret(&shaContexto, buffer, static_cast<size_t>(leidos));
#endif
      if (shaEstado != 0) {
        Serial.println("OTA: fallo calculando SHA-256");
        fallo = true;
        break;
      }

      recibidos += static_cast<size_t>(leidos);
      ultimoDato = millis();
    } else {
      if (!http.connected() && recibidos < tamanoEsperado) {
        Serial.println("OTA: conexion terminada antes de completar archivo");
        fallo = true;
        break;
      }

      if (millis() - ultimoDato > TIMEOUT_SIN_DATOS) {
        Serial.println("OTA: timeout sin recibir datos");
        fallo = true;
        break;
      }

      delay(2);
    }
  }

  unsigned char hashCalculado[32] = {0};
  if (!fallo && recibidos == tamanoEsperado) {
#if MBEDTLS_VERSION_MAJOR >= 3
    shaEstado = mbedtls_sha256_finish(&shaContexto, hashCalculado);
#else
    shaEstado = mbedtls_sha256_finish_ret(&shaContexto, hashCalculado);
#endif
    if (shaEstado != 0) {
      fallo = true;
    }
  } else {
    fallo = true;
  }

  mbedtls_sha256_free(&shaContexto);
  http.end();

  if (!fallo) {
    String esperado = sha256Esperado;
    esperado.toLowerCase();
    const String calculado = sha256AHex(hashCalculado);

    if (calculado != esperado) {
      Serial.println("OTA: SHA-256 no coincide; firmware descartado");
      fallo = true;
    }
  }

  if (fallo) {
    registrarEventoMonitor("error", "OTA_TRANSFER_ERROR", "La transferencia o verificación de firmware no se completó");
    Update.abort();
    apagarLeds();

    if (salidaDetectada) {
      iniciarDesbloqueo("sensor infrarrojo durante OTA", false);
    } else {
      actualizarPuerta();
      actualizarAlarma();
      mostrarLCD("Sistema listo", "Acerque tarjeta");
    }

    return false;
  }

  if (!Update.end(false) || !Update.isFinished()) {
    Serial.print("OTA: imagen incompleta o invalida: ");
    registrarEventoMonitor("error", "OTA_INVALID_IMAGE", "La imagen de firmware resultó incompleta o inválida");
    Update.printError(Serial);
    apagarLeds();
    mostrarLCD("Sistema listo", "Acerque tarjeta");
    return false;
  }

  Serial.println("OTA remota verificada y lista para reiniciar");
  registrarEventoMonitor("recovery", "OTA_VERIFIED", "La actualización fue verificada correctamente");
  mostrarLCD("Actualizacion OK", "Reiniciando...");
  return true;
}

bool consultarControlPuertaSede(
  const char* sede,
  bool& liberada
) {
  HTTPClient http;
  http.setReuse(false);
  http.useHTTP10(true);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setConnectTimeout(1200);
  http.setTimeout(2200);

  String url = String(endpointControlPuerta) + "?sede=" + sede;
  if (!http.begin(url)) {
    return false;
  }

  http.addHeader("x-device-key", RFID_DEVICE_KEY);
  http.addHeader("x-device-group", DEVICE_GROUP);
  const int codigo = http.GET();
  const String respuesta = http.getString();
  http.end();

  if (codigo < 200 || codigo >= 300) {
    Serial.print("Control puerta ");
    Serial.print(sede);
    Serial.print(" HTTP ");
    Serial.println(codigo);
    return false;
  }

  StaticJsonDocument<384> doc;
  const DeserializationError error = deserializeJson(doc, respuesta);
  if (error || doc["ok"] != true || !doc["puertaLiberada"].is<bool>()) {
    Serial.print("Respuesta de puerta invalida para sede ");
    Serial.println(sede);
    return false;
  }

  liberada = doc["puertaLiberada"].as<bool>();
  return true;
}

void consultarControlPuertaSiCorresponde() {
  const unsigned long ahora = millis();

  if (
    ahora < ESPERA_INICIAL_CONTROL_PUERTA ||
    (
      ultimaConsultaControlPuerta != 0 &&
      ahora - ultimaConsultaControlPuerta < INTERVALO_CONTROL_PUERTA
    ) ||
    recuperacionPostBloqueoPendiente ||
    lecturaRFIDEnCurso ||
    modoVinculacion ||
    beepEnCurso ||
    (
      estadoPuerta != PUERTA_BLOQUEADA &&
      estadoPuerta != PUERTA_LIBERADA_REMOTA &&
      estadoPuerta != ESPERANDO_CIERRE
    )
  ) {
    return;
  }

  ultimaConsultaControlPuerta = ahora;

  if (!verificarWiFi()) {
    return;
  }

  bool liberadaMMA = false;
  bool liberadaCaucel = false;
  const bool mmaOk = consultarControlPuertaSede("MMA", liberadaMMA);
  actualizarServicios();
  const bool caucelOk = consultarControlPuertaSede("CAUCEL", liberadaCaucel);

  /*
    Solo cambiamos el relé cuando ambas respuestas son válidas. Si una falla,
    conservamos el último estado confirmado guardado en Preferences.
  */
  if (!mmaOk || !caucelOk) {
    Serial.println("Control remoto incompleto; se conserva el ultimo estado");
    registrarEventoMonitor("warning", "REMOTE_CONTROL_INCOMPLETE", "No se recibió el estado de todas las sedes; se conservó el último valor seguro");
    return;
  }

  aplicarControlPuertaRemoto(
    liberadaMMA || liberadaCaucel,
    "consulta web"
  );
}

void enviarHeartbeatSiCorresponde() {
  const unsigned long ahora = millis();

  if (
    recuperacionPostBloqueoPendiente ||
    lecturaRFIDEnCurso ||
    beepEnCurso ||
    (
      estadoPuerta != PUERTA_BLOQUEADA &&
      estadoPuerta != PUERTA_LIBERADA_REMOTA &&
      estadoPuerta != ESPERANDO_CIERRE &&
      estadoPuerta != ESPERANDO_CIERRE_INICIAL
    )
  ) {
    return;
  }

  if (ahora < ESPERA_INICIAL_HEARTBEAT) {
    return;
  }

  if (
    ultimoHeartbeat != 0 &&
    ahora - ultimoHeartbeat < INTERVALO_HEARTBEAT
  ) {
    return;
  }

  if (
    ultimoIntentoHeartbeat != 0 &&
    ahora - ultimoIntentoHeartbeat < INTERVALO_REINTENTO_HEARTBEAT
  ) {
    return;
  }

  // Separamos último intento de último éxito. Un fallo se reintenta pronto,
  // pero nunca en un bucle cerrado que pueda saturar la red o el servidor.
  ultimoIntentoHeartbeat = ahora;

  if (!verificarWiFi()) {
    Serial.println("Heartbeat omitido: WiFi sin conexión");
    registrarEventoMonitor("warning", "HEARTBEAT_NO_WIFI", "El heartbeat fue aplazado por falta de WiFi");
    return;
  }

  HTTPClient http;
  http.setReuse(false);
  http.useHTTP10(true);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setConnectTimeout(1500);
  http.setTimeout(3500);

  if (!http.begin(endpointHeartbeat)) {
    Serial.println("Heartbeat: no se pudo abrir el endpoint");
    registrarEventoMonitor("error", "HEARTBEAT_ENDPOINT_ERROR", "No fue posible abrir el endpoint de heartbeat");
    return;
  }

  http.addHeader("Content-Type", "application/json");
  http.addHeader("x-device-key", RFID_DEVICE_KEY);
  http.addHeader("x-device-group", DEVICE_GROUP);

  const bool incluirMonitor =
    totalEventosMonitor > 0 &&
    (
      ultimoEnvioMonitor == 0
        ? ahora >= INTERVALO_ENVIO_MONITOR
        : ahora - ultimoEnvioMonitor >= INTERVALO_ENVIO_MONITOR
    );
  StaticJsonDocument<3072> estado;
  estado["deviceId"] = obtenerIdDispositivo();
  estado["dispositivo"] = "ESP32 recepción MMA/Caucel";
  estado["firmware"] = VERSION_FIRMWARE;
  estado["otaRemota"] = true;
  estado["controlaPuerta"] = true;
  estado["permiteVinculacion"] = true;
  estado["puertaCerrada"] = puertaEstaCerrada();
  estado["puertaBloqueada"] =
    digitalRead(PIN_RELE) == RELE_BLOQUEAR;
  estado["alarmaActiva"] = alarmaActiva;
  estado["rssi"] = WiFi.RSSI();
  estado["ip"] = WiFi.localIP().toString();
  estado["estadoSistema"] = modoVinculacion
    ? "VINCULACION"
    : alarmaActiva || alarmaPuertaAbierta
      ? "ALERTA"
      : "OPERATIVO";
  estado["modoVinculacion"] = modoVinculacion;
  estado["bootId"] = bootId;
  estado["uptimeMs"] = millis();
  estado["heapLibre"] = ESP.getFreeHeap();
  estado["reiniciosBrownout"] = reiniciosBrownoutConsecutivos;
  estado["rfidDisponible"] = rfidDisponible;
  estado["arranqueCompleto"] = arranqueHardwareCompleto;
  estado["ultimoComandoId"] = ultimoComandoConfirmado;
  JsonArray sedes = estado.createNestedArray("sedes");
  sedes.add("MMA");
  sedes.add("CAUCEL");
  if (incluirMonitor) {
    // Identificador estable: si la respuesta se pierde, el servidor vuelve a
    // confirmar el mismo bloque sin crear un documento duplicado.
    estado["monitorBatchId"] = bootId + "-" + String(eventosMonitor[0].uptimeMs);
    JsonArray monitor = estado.createNestedArray("monitor");
    for (uint8_t i = 0; i < totalEventosMonitor; i++) {
      JsonObject evento = monitor.createNestedObject();
      evento["level"] = eventosMonitor[i].level;
      evento["code"] = eventosMonitor[i].code;
      evento["message"] = eventosMonitor[i].message;
      evento["uptimeMs"] = eventosMonitor[i].uptimeMs;
      evento["count"] = eventosMonitor[i].count;
    }
  }

  String payload;
  serializeJson(estado, payload);

  const int codigo = http.POST(payload);
  const String respuesta = http.getString();

  if (codigo >= 200 && codigo < 300) {
    ultimoHeartbeat = millis();
    Serial.println("Heartbeat ESP32 enviado");

    DynamicJsonDocument respuestaDoc(6144);
    const DeserializationError errorComando = deserializeJson(respuestaDoc, respuesta);
    if (!errorComando) {
      if (incluirMonitor && respuestaDoc["monitorPersistido"] == true) {
        limpiarEventosMonitor();
        ultimoEnvioMonitor = millis();
        Serial.println("Monitor: bloque de diagnosticos confirmado");
      }
      if (respuestaDoc["puertaLiberada"].is<bool>()) {
        aplicarControlPuertaRemoto(
          respuestaDoc["puertaLiberada"].as<bool>(),
          "heartbeat"
        );
      }

      const char* tipoComando = respuestaDoc["comando"]["tipo"] | "";
      const char* idComando = respuestaDoc["comando"]["id"] | "";

      if (String(tipoComando) == "REINICIAR" && String(idComando).length() > 0) {
        if (!condicionesSegurasParaReinicio()) {
          Serial.println("Reinicio aplazado: puerta o alimentacion en estado inseguro");
          http.end();
          return;
        }
        ultimoComandoConfirmado = String(idComando);
        preferencias.putString("ultimoCmd", ultimoComandoConfirmado);
        Serial.println("Orden remota de reinicio confirmada");
        http.end();
        prepararReinicioSeguro("orden remota");
        ESP.restart();
        return;
      }

      if (
        String(tipoComando) == "ACTUALIZAR_FIRMWARE" &&
        String(idComando).length() > 0
      ) {
        const String url = respuestaDoc["comando"]["url"] | "";
        const String version = respuestaDoc["comando"]["version"] | "";
        const String sha256 = respuestaDoc["comando"]["sha256"] | "";
        const size_t tamano = respuestaDoc["comando"]["tamano"] | 0;

        // Recuperación idempotente: si el ESP ya arrancó la versión objetivo
        // (por ejemplo, hubo un corte justo después de Update.end), confirma la
        // orden sin volver a escribir la flash.
        if (version == VERSION_FIRMWARE) {
          ultimoComandoConfirmado = String(idComando);
          preferencias.putString("ultimoCmd", ultimoComandoConfirmado);
          http.end();
          Serial.println("OTA: version objetivo ya instalada; orden recuperada");
          return;
        }

        // Cerramos el POST de heartbeat antes de abrir la descarga grande.
        http.end();

        if (actualizarFirmwareRemoto(url, version, sha256, tamano)) {
          // Solo se confirma después de escribir y verificar la imagen completa.
          ultimoComandoConfirmado = String(idComando);
          preferencias.putString("ultimoCmd", ultimoComandoConfirmado);

          if (watchdogConfigurado) {
            esp_task_wdt_reset();
          }

          delay(250);
          ESP.restart();
        }

        return;
      }
    }
  } else {
    Serial.print("Error heartbeat HTTP: ");
    Serial.println(codigo);

    if (codigo < 0) {
      Serial.print("Detalle heartbeat: ");
      Serial.println(http.errorToString(codigo));
    }
    registrarEventoMonitor("error", "HEARTBEAT_HTTP_ERROR", "El servidor rechazó o no respondió al heartbeat");
  }

  http.end();
}

// =====================================================
// MENÚ DE CONFIGURACIÓN
// =====================================================

void mostrarMenuConfig() {
  menuConfig++;

  if (menuConfig > 4) {
    menuConfig = 1;
  }

  beep(1, 80);

  if (menuConfig == 1) {
    Serial.print("WiFi: ");
    Serial.println(
      WiFi.status() == WL_CONNECTED
        ? "Conectado"
        : "Sin conexion"
    );
  }

  if (menuConfig == 2) {
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
  }

  if (menuConfig == 3) {
    Serial.print("Modo: ");

    if (alarmaActiva) {
      Serial.println("ALARMA");
    } else if (modoVinculacion) {
      Serial.println("VINCULACION");
    } else {
      Serial.println("NORMAL");
    }
  }

  if (menuConfig == 4) {
    Serial.print("Ultimo alumno: ");
    Serial.println(ultimoAlumno);
    Serial.print("RFID: ");
    Serial.println(ultimoRFID);
  }

  esperarConServicios(1800);
}

// =====================================================
// ACCESO VERDE
// =====================================================

void accesoVerde(
  String nombre,
  String mensajePago
) {
  ultimoAlumno =
    nombre.length() > 0
      ? nombre
      : "Alumno";

  apagarLeds();

  digitalWrite(
    LED_VERDE,
    HIGH
  );

  mostrarLCD(
    "Acceso permitido",
    ultimoAlumno
  );

  beep(1);

  esperarConServicios(1400);

  Serial.print("Estado de pago: ");
  Serial.println(mensajePago);

  mostrarLCD(
    "Estado de pago",
    mensajePago
  );

  esperarConServicios(1600);

  digitalWrite(
    LED_VERDE,
    LOW
  );

  esperarConServicios(1000);

  if (puertaLiberadaRemota) {
    mostrarLCD(
      "PUERTA LIBERADA",
      "Control remoto"
    );
  } else {
    mostrarLCD(
      "Sistema listo",
      "Acerque tarjeta"
    );
  }
}

// =====================================================
// ACCESO AMARILLO
// =====================================================

void accesoAmarillo(
  String nombre,
  String mensajePago
) {
  ultimoAlumno =
    nombre.length() > 0
      ? nombre
      : "Alumno";

  apagarLeds();

  digitalWrite(
    LED_AMARILLO,
    HIGH
  );

  mostrarLCD(
    "Acceso permitido",
    ultimoAlumno
  );

  beep(2, 80);

  esperarConServicios(1400);

  Serial.print("Aviso de pago: ");
  Serial.println(mensajePago);

  mostrarLCD(
    "Aviso de pago",
    mensajePago
  );

  esperarConServicios(1800);

  digitalWrite(
    LED_AMARILLO,
    LOW
  );

  esperarConServicios(1000);

  mostrarLCD(
    "Sistema listo",
    "Acerque tarjeta"
  );
}

// =====================================================
// ALARMA
// =====================================================

void activarAlarma(
  String mensajePago
) {
  alarmaActiva = true;

  apagarLeds();

  digitalWrite(
    LED_ROJO,
    HIGH
  );

  mostrarLCD(
    "ACCESO DENEGADO",
    mensajePago.length() > 0
      ? mensajePago
      : "No autorizado"
  );

  Serial.print("ACCESO DENEGADO: ");
  Serial.println(
    mensajePago.length() > 0
      ? mensajePago
      : "Tarj. maestra"
  );

  Serial.println(
    "ALARMA ACTIVADA"
  );
}

void apagarAlarma() {
  alarmaActiva = false;
  estadoBuzzerAlarma = false;

  digitalWrite(
    BUZZER,
    LOW
  );

  digitalWrite(
    LED_ROJO,
    LOW
  );

  beep(3, 80);

  esperarConServicios(1000);

  Serial.println(
    "ALARMA APAGADA"
  );

  mostrarLCD(
    "Sistema listo",
    "Acerque tarjeta"
  );
}

// =====================================================
// CONSULTAR VINCULACIÓN PENDIENTE
// =====================================================

bool consultarVinculacionPendiente() {
  if (!verificarWiFi()) {
    return false;
  }

  HTTPClient http;
  http.setReuse(false);
  http.useHTTP10(true);

  mostrarLCD(
    "Buscando",
    "vinculacion..."
  );

  http.setFollowRedirects(
    HTTPC_STRICT_FOLLOW_REDIRECTS
  );

  http.setConnectTimeout(1500);
  http.setTimeout(3500);

  const String urlPendiente =
    String(endpointPendiente) +
    "?dispositivo=" + DISPOSITIVO +
    "&deviceId=" + obtenerIdDispositivo();

  if (!http.begin(urlPendiente)) {
    Serial.println("No se pudo abrir el endpoint de vinculacion");
    return false;
  }

  http.addHeader(
    "x-device-key",
    RFID_DEVICE_KEY
  );
  http.addHeader("x-device-group", DEVICE_GROUP);

  const int code = http.GET();
  const String response =
    http.getString();

  Serial.print(
    "HTTP vinculacion pendiente: "
  );

  Serial.println(code);
  Serial.println(response);

  StaticJsonDocument<512> doc;

  const DeserializationError jsonError =
    deserializeJson(
      doc,
      response
    );

  const String detalleHttp =
    code < 0
      ? String(http.errorToString(code))
      : "";

  http.end();

  if (
    code != 200 ||
    jsonError
  ) {
    Serial.println(
      "Error consultando vinculacion pendiente"
    );

    if (detalleHttp.length() > 0) {
      Serial.print("Detalle de red: ");
      Serial.println(detalleHttp);
    }

    if (code == 401 || code == 403) {
      mostrarLCD("Clave dispositivo", "No autorizada");
    } else {
      mostrarLCD("Error servidor", "HTTP " + String(code));
    }

    return false;
  }

  const bool pendiente =
    doc["pendiente"] | false;

  if (pendiente) {
    const char* idJson = doc["vinculacionId"] | "";
    const char* sedeJson = doc["sede"] | "";

    vinculacionId = String(idJson);
    vinculacionSede = String(sedeJson);
    vinculacionSede.trim();
    vinculacionSede.toUpperCase();

    const bool sedeValida =
      vinculacionSede == "MMA" ||
      vinculacionSede == "CAUCEL";

    if (vinculacionId.length() == 0 || !sedeValida) {
      Serial.println("Vinculacion pendiente incompleta o de sede no autorizada");
      vinculacionId = "";
      vinculacionSede = "";
      return false;
    }

    Serial.print("Vinculacion encontrada para sede: ");
    Serial.println(vinculacionSede);
    return true;
  }

  vinculacionId = "";
  vinculacionSede = "";
  Serial.println("No existe una vinculacion pendiente para Recepcion");
  return false;
}

// =====================================================
// ENTRAR EN VINCULACIÓN
// =====================================================

void entrarModoVinculacion() {
  Serial.println("Buscando vinculacion...");

  if (
    consultarVinculacionPendiente()
  ) {
    modoVinculacion = true;
    momentoInicioVinculacion = millis();

    apagarLeds();
    beep(2, 80);

    Serial.println(
      "MODO VINCULACION ACTIVADO"
    );
  } else {
    modoVinculacion = false;
    vinculacionId = "";
    vinculacionSede = "";
    momentoInicioVinculacion = 0;
    beep(1, 500);

    esperarConServicios(1200);

    Serial.println(
      "NO HAY VINCULACION PENDIENTE"
    );
  }
}

// =====================================================
// VINCULAR TARJETA
// =====================================================

void vincularTarjeta(
  String uid
) {
  if (!verificarWiFi()) {
    beep(4, 100);

    esperarConServicios(1500);

    return;
  }

  if (
    vinculacionId.length() == 0 ||
    (
      vinculacionSede != "MMA" &&
      vinculacionSede != "CAUCEL"
    )
  ) {
    Serial.println("Vinculacion cancelada: contexto incompleto");
    modoVinculacion = false;
    vinculacionId = "";
    vinculacionSede = "";
    momentoInicioVinculacion = 0;
    mostrarLCD("Vinculacion", "Invalida");
    beep(2, 180);
    return;
  }

  Serial.print("Vinculando RFID: ");
  Serial.println(uid);

  mostrarLCD(
    "Vinculando RFID",
    uid
  );

  HTTPClient http;
  http.setReuse(false);
  http.useHTTP10(true);

  http.setFollowRedirects(
    HTTPC_STRICT_FOLLOW_REDIRECTS
  );

  http.setConnectTimeout(1500);
  http.setTimeout(3500);

  if (!http.begin(endpointVincular)) {
    Serial.println("No se pudo abrir el endpoint para vincular");
    mostrarLCD("Error de red", "Reintente tarjeta");
    beep(2, 120);
    return;
  }

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  http.addHeader(
    "x-device-key",
    RFID_DEVICE_KEY
  );
  http.addHeader("x-device-group", DEVICE_GROUP);

  StaticJsonDocument<384> bodyDoc;

  bodyDoc["vinculacionId"] =
    vinculacionId;

  bodyDoc["rfid"] = uid;

  bodyDoc["dispositivo"] =
    DISPOSITIVO;
  bodyDoc["deviceId"] = obtenerIdDispositivo();
  bodyDoc["sede"] = vinculacionSede;

  String body;

  serializeJson(
    bodyDoc,
    body
  );

  const int code =
    http.POST(body);

  const String response =
    http.getString();

  Serial.print(
    "HTTP vinculacion: "
  );

  Serial.println(code);

  Serial.print(
    "Respuesta vinculacion: "
  );

  Serial.println(response);

  StaticJsonDocument<512> doc;

  const DeserializationError jsonError =
    deserializeJson(
      doc,
      response
    );

  bool ok = false;
  String mensaje =
    "Error desconocido";

  if (!jsonError) {
    ok = doc["ok"] | false;

    const char* mensajeJson =
      doc["mensaje"] | "";

    mensaje = String(mensajeJson);
  } else if (code < 0) {
    mensaje = http.errorToString(code);
  } else {
    mensaje = "Respuesta invalida del servidor";
  }

  http.end();

  const bool errorTransitorio =
    code < 0 ||
    code >= 500 ||
    jsonError;

  if (
    code >= 200 &&
    code < 300 &&
    ok
  ) {
    modoVinculacion = false;
    momentoInicioVinculacion = 0;
    apagarLeds();

    digitalWrite(
      LED_VERDE,
      HIGH
    );

    beep(3, 80);

    esperarConServicios(1000);

    digitalWrite(
      LED_VERDE,
      LOW
    );

    Serial.println(
      "TARJETA VINCULADA"
    );

    mostrarLCD(
      "Tarjeta",
      "Vinculada"
    );
  } else if (errorTransitorio) {
    // Conserva el contexto para permitir otro intento sin volver a pasar la
    // tarjeta maestra. El timeout global evita que quede activo para siempre.
    Serial.print("Fallo transitorio al vincular: ");
    Serial.println(mensaje);
    registrarEventoMonitor("warning", "RFID_LINK_TRANSIENT", "La vinculación RFID sufrió un fallo transitorio de red");
    mostrarLCD("Fallo de red", "Reintente tarjeta");
    beep(2, 120);
    esperarConServicios(700);
    return;
  } else {
    modoVinculacion = false;
    momentoInicioVinculacion = 0;
    apagarLeds();

    digitalWrite(
      LED_ROJO,
      HIGH
    );

    Serial.print("Error: ");
    Serial.println(mensaje);
    registrarEventoMonitor("error", "RFID_LINK_REJECTED", "El servidor rechazó la vinculación RFID");

    beep(4, 100);

    esperarConServicios(1000);

    digitalWrite(
      LED_ROJO,
      LOW
    );

    Serial.println(
      "ERROR AL VINCULAR"
    );

    mostrarLCD(
      "Error al",
      "vincular"
    );
  }

  vinculacionId = "";
  vinculacionSede = "";
  momentoInicioVinculacion = 0;

  esperarConServicios(1200);
}

// =====================================================
// CONSULTAR ACCESO
// =====================================================

void consultarAcceso(
  String uid
) {
  Serial.println("Consultando acceso...");

  mostrarLCD(
    "Leyendo tarjeta",
    "Espere..."
  );

  if (!verificarWiFi()) {
    mostrarLCD(
      "Sin conexion",
      "Reintente"
    );

    beep(3, 200);

    esperarConServicios(1500);

    mostrarLCD(
      "Sistema listo",
      "Acerque tarjeta"
    );

    return;
  }

  HTTPClient http;
  http.setReuse(false);
  http.useHTTP10(true);

  http.setFollowRedirects(
    HTTPC_STRICT_FOLLOW_REDIRECTS
  );

  http.setConnectTimeout(1500);
  http.setTimeout(3500);

  if (!http.begin(endpointAcceso)) {
    Serial.println("No se pudo abrir el endpoint de acceso");
    mostrarLCD("Error de red", "Reintente");
    beep(2, 160);
    esperarConServicios(700);
    return;
  }

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  http.addHeader(
    "x-device-key",
    RFID_DEVICE_KEY
  );
  http.addHeader("x-device-group", DEVICE_GROUP);

  StaticJsonDocument<384> bodyDoc;

  bodyDoc["rfid"] = uid;

  bodyDoc["dispositivo"] =
    DISPOSITIVO;
  bodyDoc["deviceId"] = obtenerIdDispositivo();
  bodyDoc["sede"] = "MMA";
  JsonArray sedesAutorizadas = bodyDoc.createNestedArray("sedesAutorizadas");
  sedesAutorizadas.add("MMA");
  sedesAutorizadas.add("CAUCEL");

  String body;

  serializeJson(
    bodyDoc,
    body
  );

  const int code =
    http.POST(body);

  const String response =
    http.getString();

  Serial.print(
    "HTTP acceso: "
  );

  Serial.println(code);

  Serial.print(
    "Respuesta: "
  );

  Serial.println(response);

  StaticJsonDocument<768> doc;

  const DeserializationError jsonError =
    deserializeJson(
      doc,
      response
    );

  if (
    code < 200 ||
    code >= 300 ||
    jsonError
  ) {
    String detalleError = "HTTP " + String(code);

    if (!jsonError) {
      const char* mensajeApi = doc["mensaje"] | "";
      if (String(mensajeApi).length() > 0) {
        detalleError = String(mensajeApi);
      }
    } else if (code < 0) {
      detalleError = String(http.errorToString(code));
    }

    http.end();

    mostrarLCD(
      code == 401 || code == 403
        ? "No autorizado"
        : "Error servidor",
      detalleError
    );

    beep(3, 200);

    esperarConServicios(1500);

    mostrarLCD(
      "Sistema listo",
      "Acerque tarjeta"
    );

    return;
  }

  const bool permitido =
    doc["permitido"] | false;

  /*
    "permitido" significa que el alumno es válido y su asistencia puede
    registrarse. "abrirPuerta" es una autorización física independiente.
    Cuando el administrador bloquea el tatami, la API conserva permitido=true
    para registrar asistencia pero devuelve abrirPuerta=false.

    El valor por defecto mantiene compatibilidad con una API anterior que no
    enviaba abrirPuerta: si el campo no existe, replica el comportamiento
    histórico y abre únicamente cuando permitido=true.
  */
  const bool abrirPuerta =
    doc["abrirPuerta"] | permitido;

  const char* nombreJson =
    doc["nombre"] | "";

  const char* mensajeJson =
    doc["mensaje"] | "";

  const char* estadoLedJson =
    doc["estadoLed"] | "";

  const char* mensajePagoJson =
    doc["mensajePago"] | "";

  const String nombre =
    String(nombreJson);

  const String mensaje =
    String(mensajeJson);

  const String estadoLed =
    String(estadoLedJson);

  const String mensajePago =
    String(mensajePagoJson);

  http.end();

  ultimoRFID = uid;

  if (permitido && abrirPuerta) {
    /*
      Se libera la puerta inmediatamente
      después de recibir la autorización
      del servidor.
    */

    iniciarDesbloqueo(
      "RFID autorizado",
      true
    );

    if (
      estadoLed == "amarillo"
    ) {
      accesoAmarillo(
        nombre,
        mensajePago
      );
    } else {
      accesoVerde(
        nombre,
        mensajePago
      );
    }
  } else if (permitido) {
    /*
      Asistencia válida con tatami bloqueado. El electroimán permanece en su
      estado seguro y no se activa la alarma: simplemente informamos que la
      asistencia fue aceptada pero la puerta no está autorizada a abrir.
    */
    ultimoAlumno =
      nombre.length() > 0
        ? nombre
        : "Alumno";

    /*
      No forzamos el relé aquí. Si la puerta estuviera abierta por el sensor
      de salida, el autómata de puerta debe terminar ese ciclo y bloquear solo
      después de que el reed confirme cierre. Simplemente no iniciamos una
      nueva apertura por RFID.
    */
    apagarLeds();
    digitalWrite(LED_AMARILLO, HIGH);

    mostrarLCD(
      "Asistencia OK",
      "Tatami bloqueado"
    );

    Serial.println(
      "Asistencia autorizada; puerta bloqueada por control de tatami"
    );

    beep(1, 80);
    esperarConServicios(1200);

    digitalWrite(LED_AMARILLO, LOW);
    mostrarLCD(
      "Sistema listo",
      "Acerque tarjeta"
    );
  } else {
    ultimoAlumno =
      nombre.length() > 0
        ? nombre
        : "Denegado";

    activarAlarma(
      mensajePago.length() > 0
        ? mensajePago
        : mensaje
    );
  }
}

// =====================================================
// FINALIZAR LECTURA RFID
// =====================================================

void finalizarLecturaRFID() {
  const bool cicloExcedido =
    lecturaRFIDEnCurso &&
    millis() - inicioLecturaRFID > LIMITE_CICLO_RFID;

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  /*
    Damos tiempo para retirar la tarjeta y dejamos
    limpio el estado criptográfico para la siguiente.
  */
  esperarConServicios(80);

  if (cicloExcedido) {
    Serial.println("Lectura lenta detectada; limpiando RC522");
    rfid.PCD_Reset();
    esperarConServicios(50);
    rfid.PCD_Init();
    fallosRFIDConsecutivos = 0;
    ultimaReinicializacionRFID = millis();
  }

  lecturaRFIDEnCurso = false;
  inicioLecturaRFID = 0;
}

// =====================================================
// PREPARAR SIGUIENTE LECTURA RFID
// =====================================================

bool prepararLecturaRFID() {
  // En modo degradado no tocamos SPI desde el loop normal. La recuperacion
  // temporizada es la unica responsable de probar nuevamente el lector.
  if (!rfidDisponible) {
    return false;
  }

  /*
    Flujo recomendado por la biblioteca MFRC522:
    REQA detecta una tarjeta nueva y evita despertar continuamente una
    tarjeta que ya fue puesta en HALT. Esto elimina el ciclo inestable
    WUPA -> anticollision fallida -> reinicio del lector.
  */
  if (!rfid.PICC_IsNewCardPresent()) {
    if (momentoSinTarjeta == 0) {
      momentoSinTarjeta = millis();
    }

    if (
      millis() - momentoSinTarjeta
      >= TIEMPO_RETIRO_TARJETA
    ) {
      mismaTarjetaDebeRetirarse = false;
    }

    // Sólo reinicia el RC522 cuando su registro de versión confirma un fallo.
    if (
      millis() - ultimaReinicializacionRFID
      >= INTERVALO_REVISION_RFID
    ) {
      const byte version = rfid.PCD_ReadRegister(MFRC522::VersionReg);
      if (version == 0x00 || version == 0xFF) {
        Serial.println("RC522 sin respuesta; reinicializando");
        rfid.PCD_Reset();
        esperarConServicios(50);
        rfid.PCD_Init();
        fallosRFIDConsecutivos = 0;
      }
      ultimaReinicializacionRFID =
        millis();
    }

    return false;
  }

  momentoSinTarjeta = 0;

  if (!rfid.PICC_ReadCardSerial()) {
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
    fallosRFIDConsecutivos++;

    Serial.print("Fallo de anticollision RFID: ");
    Serial.println(fallosRFIDConsecutivos);

    // Evita martillar el bus SPI en un bucle cerrado cuando una tarjeta se
    // queda sobre la antena justo después de reinicializar el RC522.
    esperarConServicios(25);

    /*
      Un fallo aislado puede ser movimiento de la tarjeta. Reiniciar el
      RC522 en cada fallo empeora la lectura; solo se limpia después de
      tres fallos consecutivos comprobados.
    */
    if (fallosRFIDConsecutivos >= 3) {
      Serial.println("Tres fallos RFID; reinicializando lector");
      registrarEventoMonitor("warning", "RFID_READ_FAILURES", "Se reinicializó el lector después de tres fallos consecutivos");
      rfid.PCD_Reset();
      esperarConServicios(50);
      rfid.PCD_Init();
      fallosRFIDConsecutivos = 0;
      ultimaReinicializacionRFID = millis();
    }

    return false;
  }

  fallosRFIDConsecutivos = 0;

  return true;
}

// =====================================================
// SETUP
// =====================================================

const char* descripcionCausaReset(esp_reset_reason_t causa) {
  switch (causa) {
    case ESP_RST_POWERON:
      return "POWER_ON / alimentacion o reset de encendido";
    case ESP_RST_EXT:
      return "RESET_EXTERNO / pin EN";
    case ESP_RST_SW:
      return "SOFTWARE / ESP.restart()";
    case ESP_RST_PANIC:
      return "PANIC / excepcion de software";
    case ESP_RST_INT_WDT:
      return "WATCHDOG / interrupcion";
    case ESP_RST_TASK_WDT:
      return "WATCHDOG / tarea";
    case ESP_RST_WDT:
      return "WATCHDOG / otro";
    case ESP_RST_DEEPSLEEP:
      return "DEEP_SLEEP";
    case ESP_RST_BROWNOUT:
      return "BROWNOUT / caida o perturbacion de alimentacion";
    case ESP_RST_SDIO:
      return "SDIO";
    case ESP_RST_UNKNOWN:
    default:
      return "DESCONOCIDA";
  }
}

void imprimirDiagnosticoReset() {
  const esp_reset_reason_t causa = esp_reset_reason();

  Serial.println();
  Serial.println("================================");
  Serial.println(" DIAGNOSTICO DE ARRANQUE ESP32");
  Serial.println("================================");
  Serial.print("Firmware: ");
  Serial.println(VERSION_FIRMWARE);
  Serial.print("Causa de reset: ");
  Serial.println(descripcionCausaReset(causa));
  Serial.print("Codigo reset: ");
  Serial.println(static_cast<int>(causa));
  Serial.println("================================");
}

void setup() {
  Serial.begin(115200);

  // Debe ser la primera condicion funcional del arranque. El rele permanecera
  // liberado incluso cuando las esperas de setup atiendan actualizarPuerta().
  arranqueHardwareCompleto = false;

  // Se imprime antes de inicializar LCD, WiFi, relé o RFID para conservar la
  // causa real del reset anterior incluso si otro periférico vuelve a fallar.
  delay(80);
  imprimirDiagnosticoReset();

  /*
    No inicializamos ni reconfiguramos el Task Watchdog del sistema.

    Su core ESP32 ya lo trae activo. La v2.4 alteraba su idle_core_mask y eso
    hizo que IDLE1 disparara el reset aun cuando nuestro loop seguia vivo.
    Si Arduino ya registro loopTask, podemos alimentarla; si no, dejamos el
    TWDT interno exactamente como lo configuro el framework.
  */
  watchdogConfigurado = esp_task_wdt_status(NULL) == ESP_OK;

  preferencias.begin("albatros", false);
  ultimoComandoConfirmado = preferencias.getString("ultimoCmd", "");
  controlPuertaConfirmado = preferencias.getBool("puertaCfg", false);
  puertaLiberadaRemota = controlPuertaConfirmado
    ? preferencias.getBool("puertaLibre", false)
    : false;
  reiniciosBrownoutConsecutivos = preferencias.getUChar("brownouts", 0);
  if (esp_reset_reason() == ESP_RST_BROWNOUT) {
    if (reiniciosBrownoutConsecutivos < 4) reiniciosBrownoutConsecutivos++;
    preferencias.putUChar("brownouts", reiniciosBrownoutConsecutivos);
  }
  const uint8_t multiplicadorBrownout = reiniciosBrownoutConsecutivos > 0
    ? reiniciosBrownoutConsecutivos
    : 1;
  const unsigned long esperaBrownout = esp_reset_reason() == ESP_RST_BROWNOUT
    ? 15000UL * multiplicadorBrownout
    : 3000UL;
  proteccionAlimentacionHasta = millis() + esperaBrownout;
  bootId = String((uint32_t)(ESP.getEfuseMac() & 0xFFFFFFFF), HEX)
    + "-" + String(esp_random(), HEX);

  delay(300);

  // LCD I2C en SDA 32 y SCL 33.
  iniciarLCD();

  Serial.println();
  Serial.println(
    "================================"
  );

  Serial.println(
    "ALBATROS - CONTROL DE ACCESO"
  );

  Serial.println(
    "================================"
  );

  // ---------------------------------------------------
  // Configuración de salidas
  // ---------------------------------------------------

  pinMode(
    LED_VERDE,
    OUTPUT
  );

  pinMode(
    LED_ROJO,
    OUTPUT
  );

  pinMode(
    LED_AMARILLO,
    OUTPUT
  );

  pinMode(
    BUZZER,
    OUTPUT
  );

  // Precarga HIGH (imán sin corriente) antes de convertir el GPIO en salida.
  // También se requiere un pull-up físico en el driver para cubrir el tiempo
  // anterior a que el firmware tome control del pin.
  digitalWrite(PIN_RELE, RELE_DESBLOQUEAR);
  pinMode(PIN_RELE, OUTPUT);
  digitalWrite(PIN_RELE, RELE_DESBLOQUEAR);

  // ---------------------------------------------------
  // Configuración de sensores
  // ---------------------------------------------------

  pinMode(
    PIN_IR,
    INPUT
  );

  /*
    GPIO34 no dispone de resistencia
    pull-up interna.

    La conexión debe ser:

       3.3 V
         |
        10k
         |
    GPIO34 ---- sensor ---- GND
  */

  pinMode(
    PIN_PUERTA,
    INPUT
  );

  // ---------------------------------------------------
  // Estado inicial
  // ---------------------------------------------------

  apagarLeds();

  digitalWrite(
    BUZZER,
    LOW
  );

  /*
    Por seguridad comienza liberado.

    Solo activa el electroimán después
    de confirmar que la puerta está
    cerrada.
  */

  desbloquearPuerta();

  // ---------------------------------------------------
  // RFID
  // ---------------------------------------------------

  SPI.begin();

  rfid.PCD_Init();
  ultimaReinicializacionRFID =
    millis();

  const byte versionRFIDInicial =
    rfid.PCD_ReadRegister(MFRC522::VersionReg);
  rfidDisponible =
    versionRFIDInicial != 0x00 &&
    versionRFIDInicial != 0xFF;

  Serial.println(
    "Lector RFID iniciado"
  );

  Serial.print("RC522 VersionReg inicial: 0x");
  Serial.println(versionRFIDInicial, HEX);

  if (!rfidDisponible) {
    proximoIntentoRFIDDegradado = millis() +
      INTERVALO_RECUPERACION_RFID_DEGRADADO;
    Serial.println("RC522 no disponible al arrancar; se reintentara sin reiniciar");
  }

  mostrarLCD(
    "Lector RFID",
    "Iniciado"
  );

  // ---------------------------------------------------
  // Estado inicial de sensores
  // ---------------------------------------------------

  irAnterior =
    sensorIRDetectado();

  if (puertaLiberadaRemota) {
    Serial.println("Restaurando PUERTA LIBERADA confirmada por la web");
    desbloquearPuerta();
    alarmaPuertaAbierta = false;
    aperturaIniciadaPorRFID = false;
    estadoPuerta = PUERTA_LIBERADA_REMOTA;
    apagarLeds();
    digitalWrite(LED_VERDE, HIGH);
    mostrarLCD("PUERTA LIBERADA", "Control remoto");
  } else if (puertaEstaCerrada()) {
    Serial.println(
      "Puerta cerrada durante el arranque"
    );

    momentoCierre = millis();

    estadoPuerta =
      ESPERANDO_BLOQUEO;
  } else {
    Serial.println(
      "Puerta abierta durante el arranque"
    );

    estadoPuerta =
      ESPERANDO_CIERRE_INICIAL;
  }

  // Prueba breve de salidas al encender.
  digitalWrite(LED_VERDE, HIGH);
  beep(1, 100);
  esperarConServicios(200);
  digitalWrite(LED_VERDE, LOW);

  digitalWrite(LED_AMARILLO, HIGH);
  beep(1, 100);
  esperarConServicios(200);
  digitalWrite(LED_AMARILLO, LOW);

  digitalWrite(LED_ROJO, HIGH);
  beep(1, 100);
  esperarConServicios(200);
  digitalWrite(LED_ROJO, LOW);

  // ---------------------------------------------------
  // Wi-Fi y OTA
  // ---------------------------------------------------

  conectarWiFi();

  // Todo el hardware y los servicios ya fueron inicializados. A partir de
  // aqui permitimos que la maquina de estados considere energizar el iman.
  // No se activa de golpe: si la puerta esta cerrada se reinicia la ventana
  // normal de comprobacion (2 s + confirmacion), y la proteccion por brownout
  // sigue teniendo prioridad cuando corresponda.
  arranqueHardwareCompleto = true;

  if (!puertaLiberadaRemota) {
    if (puertaEstaCerrada()) {
      momentoCierre = millis();
      ultimoParpadeoCierre = millis();
      estadoParpadeoCierre = false;
      estadoPuerta = ESPERANDO_BLOQUEO;
      Serial.println("Arranque completo; comprobando puerta antes de energizar iman");
    } else {
      estadoPuerta = ESPERANDO_CIERRE_INICIAL;
      Serial.println("Arranque completo; iman apagado hasta que cierre la puerta");
    }
  }

  if (puertaLiberadaRemota) {
    mostrarLCD(
      "PUERTA LIBERADA",
      "Control remoto"
    );
  } else {
    mostrarLCD(
      "Sistema listo",
      "Acerque tarjeta"
    );
  }
}

// =====================================================
// LOOP
// =====================================================

void loop() {
  /*
    Estas funciones siempre deben ejecutarse,
    incluso cuando no hay una tarjeta presente.
  */

  actualizarServicios();
  ultimaVueltaLoop = millis();

  /*
    Después de energizar el electroimán reservamos una ventana corta y
    deliberada para estabilización y recuperación de SPI/I2C. Durante ella no
    iniciamos una lectura RFID ni tráfico HTTP/OTA. La máquina de estados de la
    puerta y el watchdog siguen atendidos dentro de actualizarServicios().
  */
  if (recuperacionPostBloqueoPendiente) {
    delay(1);
    return;
  }

  // ---------------------------------------------------
  // Buscar tarjeta RFID
  // ---------------------------------------------------

  if (!prepararLecturaRFID()) {
    // Las consultas remotas solo usan la red cuando no hay tarjeta esperando.
    consultarControlPuertaSiCorresponde();
    enviarHeartbeatSiCorresponde();
    // Cede CPU a las tareas del sistema (WiFi/IDLE) cuando no hay trabajo.
    // Es deliberadamente corto: no reduce de forma perceptible la respuesta
    // del RFID y evita un loopTask al 100 % sin necesidad.
    delay(1);
    return;
  }

  lecturaRFIDEnCurso = true;
  inicioLecturaRFID = millis();

  const String uid =
    uidToString();

  mostrarLCD(
    "Tarjeta detectada",
    uid
  );

  Serial.println();
  Serial.print("RFID: ");
  Serial.println(uid);

  /*
    La misma tarjeta debe retirarse físicamente antes
    de volver a procesarse. Una tarjeta diferente sí
    puede utilizarse inmediatamente.
  */
  if (
    uid == ultimaUidProcesada &&
    mismaTarjetaDebeRetirarse
  ) {
    finalizarLecturaRFID();
    return;
  }

  ultimaUidProcesada = uid;
  momentoUltimaLecturaRFID = millis();
  mismaTarjetaDebeRetirarse = true;

  // ---------------------------------------------------
  // TARJETA DE CONFIGURACIÓN
  // ---------------------------------------------------

  if (uid == RFID_CONFIG) {
    mostrarMenuConfig();

    finalizarLecturaRFID();

    return;
  }

  // ---------------------------------------------------
  // TARJETA MAESTRA
  // ---------------------------------------------------

  /*
    Si existe una alarma, la tarjeta
    maestra la apaga.

    Si no existe alarma, busca una
    solicitud de vinculación pendiente.
  */

  if (esTarjetaMaestra(uid)) {
    const bool habiaAlarma = alarmaActiva;

    if (alarmaActiva) {
      apagarAlarma();
    }

    /*
      La maestra es siempre la excepción física del bloqueo del tatami. La
      apertura se realiza localmente para que siga funcionando incluso si el
      servidor no está disponible. Esto no elimina su función histórica de
      iniciar una vinculación cuando no había una alarma activa.
    */
    iniciarDesbloqueo(
      "tarjeta maestra",
      true
    );

    if (!habiaAlarma) {
      entrarModoVinculacion();
    }

    finalizarLecturaRFID();

    return;
  }

  // ---------------------------------------------------
  // TARJETA NORMAL
  // ---------------------------------------------------

  ultimoRFID = uid;

  if (modoVinculacion) {
    vincularTarjeta(uid);
  } else {
    consultarAcceso(uid);
  }

  finalizarLecturaRFID();
}
