import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import { NextResponse } from 'next/server';

import type { Sede } from '@/lib/access-control';
import { adminDb } from '@/lib/firebase-admin';
import {
  RequestAccessError,
  requirePanelActorAccess,
} from '@/lib/server-access';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const SEDES: Sede[] = ['MMA', 'CAUCEL', 'JUAN_PABLO'];
const MAX_UNIDADES = 50;

const PRODUCTOS = {
  agua_600: { nombre: 'Agua 600 ml', precio: 10 },
  agua_1l: { nombre: 'Agua 1 litro', precio: 15 },
  amper_mango: { nombre: 'Amper mango', precio: 22 },
  amper_blanco: { nombre: 'Amper blanco', precio: 22 },
  amper_azul: { nombre: 'Amper azul', precio: 22 },
  barra_proteina: { nombre: 'Barra de proteína', precio: 15 },
  chocolate: { nombre: 'Chocolate', precio: 15 },
} as const;

type ProductoId = keyof typeof PRODUCTOS;
type ItemEntrada = { productoId?: unknown; cantidad?: unknown };

function normalizarSede(value: unknown): Sede | null {
  if (typeof value !== 'string') return null;
  const sede = value.trim().toUpperCase().replace(/\s+/g, '_') as Sede;
  return SEDES.includes(sede) ? sede : null;
}

function normalizarRfid(value: unknown): string {
  return typeof value === 'string'
    ? value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase()
    : '';
}

function serializarFecha(value: unknown): string | null {
  return value instanceof Timestamp ? value.toDate().toISOString() : null;
}

async function buscarAlumno(rfid: string, sede: Sede) {
  const collection = adminDb.collection('Alumnos');
  let snapshot = await collection
    .where('rfids', 'array-contains', rfid)
    .limit(1)
    .get();

  if (snapshot.empty) {
    snapshot = await collection.where('rfid', '==', rfid).limit(1).get();
  }
  if (snapshot.empty) return null;

  const document = snapshot.docs[0];
  const data = document.data();
  if (normalizarSede(data.sede) !== sede) return null;

  return {
    id: document.id,
    nombre: String(data.nombre || 'Alumno'),
    activo: data.activo !== false,
  };
}

function validarItems(value: unknown) {
  if (!Array.isArray(value) || value.length === 0 || value.length > 7) return null;

  const quantities = new Map<ProductoId, number>();
  for (const entry of value as ItemEntrada[]) {
    const productId =
      typeof entry?.productoId === 'string' ? entry.productoId : '';
    const quantity = Number(entry?.cantidad);
    if (
      !(productId in PRODUCTOS) ||
      !Number.isInteger(quantity) ||
      quantity < 1 ||
      quantity > 20
    ) {
      return null;
    }
    const id = productId as ProductoId;
    quantities.set(id, (quantities.get(id) || 0) + quantity);
  }

  const units = Array.from(quantities.values()).reduce((sum, current) => sum + current, 0);
  if (units > MAX_UNIDADES) return null;

  const items = Array.from(quantities.entries()).map(([productoId, cantidad]) => {
    const product = PRODUCTOS[productoId];
    return {
      productoId,
      nombre: product.nombre,
      precioUnitario: product.precio,
      cantidad,
      subtotal: product.precio * cantidad,
    };
  });

  return {
    items,
    units,
    total: items.reduce((sum, item) => sum + item.subtotal, 0),
  };
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const sede = normalizarSede(url.searchParams.get('sede'));
    if (!sede) {
      return NextResponse.json(
        { ok: false, mensaje: 'La sede no es válida.' },
        { status: 400 },
      );
    }

    await requirePanelActorAccess(request, sede);
    const snapshot = await adminDb
      .collection('SolicitudesCompra')
      .where('sede', '==', sede)
      .limit(100)
      .get();

    const compras = snapshot.docs
      .map((document) => {
        const data = document.data();
        return {
          id: document.id,
          alumnoId: String(data.alumnoId || ''),
          nombre: String(data.nombre || 'Alumno'),
          sede,
          items: Array.isArray(data.items) ? data.items : [],
          total: Number(data.total) || 0,
          estado: String(data.estado || 'pendiente_cobro'),
          confirmadaPorRfid: data.confirmadaPorRfid === true,
          creadaEn: serializarFecha(data.creadaEn),
        };
      })
      .sort((a, b) => String(b.creadaEn || '').localeCompare(String(a.creadaEn || '')));

    return NextResponse.json({ ok: true, compras });
  } catch (error) {
    if (error instanceof RequestAccessError) {
      return NextResponse.json(
        { ok: false, mensaje: error.message },
        { status: error.status },
      );
    }
    console.error('ERROR_LISTAR_COMPRAS:', error);
    return NextResponse.json(
      { ok: false, mensaje: 'No se pudieron cargar las compras.' },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => null)) as {
      sede?: unknown;
      rfid?: unknown;
      items?: unknown;
      requestId?: unknown;
    } | null;

    const sede = normalizarSede(body?.sede);
    const rfid = normalizarRfid(body?.rfid);
    const requestId =
      typeof body?.requestId === 'string' ? body.requestId.trim() : '';
    const order = validarItems(body?.items);

    if (
      !sede ||
      !rfid ||
      !order ||
      !/^[a-f0-9-]{20,50}$/i.test(requestId)
    ) {
      return NextResponse.json(
        { ok: false, mensaje: 'La compra contiene datos no válidos.' },
        { status: 400 },
      );
    }

    const actor = await requirePanelActorAccess(request, sede);
    const alumno = await buscarAlumno(rfid, sede);
    if (!alumno) {
      return NextResponse.json(
        { ok: false, mensaje: 'La tarjeta no pertenece a un alumno de esta sede.' },
        { status: 404 },
      );
    }
    if (!alumno.activo) {
      return NextResponse.json(
        { ok: false, mensaje: 'El alumno tiene una baja temporal.' },
        { status: 409 },
      );
    }

    const documentId = `${actor.uid}_${requestId}`;
    const reference = adminDb.collection('SolicitudesCompra').doc(documentId);
    const created = await adminDb.runTransaction(async (transaction) => {
      const existing = await transaction.get(reference);
      if (existing.exists) return false;

      transaction.create(reference, {
        alumnoId: alumno.id,
        nombre: alumno.nombre,
        sede,
        rfidConfirmacion: rfid,
        confirmadaPorRfid: true,
        items: order.items,
        totalUnidades: order.units,
        total: order.total,
        estado: 'pendiente_cobro',
        origen: 'catalogo_android_nfc',
        creadoPor: actor.uid,
        creadoPorEmail: actor.email || '',
        creadaEn: FieldValue.serverTimestamp(),
        actualizadaEn: FieldValue.serverTimestamp(),
      });
      return true;
    });

    return NextResponse.json({
      ok: true,
      duplicada: !created,
      compraId: documentId,
      nombre: alumno.nombre,
      total: order.total,
      mensaje: created
        ? `Compra confirmada por ${alumno.nombre}.`
        : 'Esta compra ya había sido registrada.',
    });
  } catch (error) {
    if (error instanceof RequestAccessError) {
      return NextResponse.json(
        { ok: false, mensaje: error.message },
        { status: error.status },
      );
    }
    console.error('ERROR_CREAR_COMPRA:', error);
    return NextResponse.json(
      { ok: false, mensaje: 'No se pudo registrar la compra.' },
      { status: 500 },
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json().catch(() => null)) as {
      sede?: unknown;
      compraId?: unknown;
      accion?: unknown;
    } | null;
    const sede = normalizarSede(body?.sede);
    const compraId = typeof body?.compraId === 'string' ? body.compraId.trim() : '';
    const accion = body?.accion === 'cobrar' || body?.accion === 'cancelar'
      ? body.accion
      : null;

    if (!sede || !accion || !/^[A-Za-z0-9_-]{20,160}$/.test(compraId)) {
      return NextResponse.json({ ok: false, mensaje: 'La operación no es válida.' }, { status: 400 });
    }

    const actor = await requirePanelActorAccess(request, sede);
    const reference = adminDb.collection('SolicitudesCompra').doc(compraId);

    await adminDb.runTransaction(async (transaction) => {
      const snapshot = await transaction.get(reference);
      if (!snapshot.exists || normalizarSede(snapshot.data()?.sede) !== sede) {
        throw new RequestAccessError('La compra no existe en esta sede.', 404);
      }
      const current = String(snapshot.data()?.estado || 'pendiente_cobro');
      if (current !== 'pendiente_cobro') {
        throw new RequestAccessError('Esta compra ya fue atendida.', 409);
      }
      transaction.update(reference, {
        estado: accion === 'cobrar' ? 'cobrada' : 'cancelada',
        atendidaPor: actor.uid,
        atendidaPorEmail: actor.email || '',
        atendidaEn: FieldValue.serverTimestamp(),
        actualizadaEn: FieldValue.serverTimestamp(),
      });
    });

    return NextResponse.json({
      ok: true,
      estado: accion === 'cobrar' ? 'cobrada' : 'cancelada',
      mensaje: accion === 'cobrar' ? 'Compra marcada como cobrada.' : 'Compra cancelada.',
    });
  } catch (error) {
    if (error instanceof RequestAccessError) {
      return NextResponse.json({ ok: false, mensaje: error.message }, { status: error.status });
    }
    console.error('ERROR_ACTUALIZAR_COMPRA:', error);
    return NextResponse.json({ ok: false, mensaje: 'No se pudo actualizar la compra.' }, { status: 500 });
  }
}
