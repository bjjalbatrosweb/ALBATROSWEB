import { FieldValue, Timestamp } from "firebase-admin/firestore";
import { NextResponse } from "next/server";

import { adminDb } from "@/lib/firebase-admin";
import {
  RequestAccessError,
  requirePanelActorAccess,
} from "@/lib/server-access";
import type { Sede } from "@/lib/access-control";
import { publishKioskEvent } from "@/lib/kiosk-events";

export const runtime = "nodejs";

const SEDES_VALIDAS: Sede[] = ["MMA", "CAUCEL", "JUAN_PABLO"];

function normalizarSede(valor: unknown): Sede | null {
  if (typeof valor !== "string") return null;
  const sede = valor.trim().toUpperCase().replace(/\s+/g, "_") as Sede;
  return SEDES_VALIDAS.includes(sede) ? sede : null;
}

function fechaMerida(fecha = new Date()) {
  const partes = new Intl.DateTimeFormat("es-MX", {
    timeZone: "America/Merida",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(fecha);
  const valor = (tipo: Intl.DateTimeFormatPartTypes) =>
    partes.find((parte) => parte.type === tipo)?.value || "";

  return `${valor("year")}-${valor("month")}-${valor("day")}`;
}

async function registrarEnClaseActiva(datos: {
  alumnoId: string;
  nombre: string;
  sede: Sede;
  fecha: Date;
}) {
  const activa = await adminDb.collection('ClasesActivas').doc(datos.sede).get();
  const clase = activa.exists ? activa.data() || {} : {};
  const claseId = typeof clase.claseId === 'string' ? clase.claseId : '';
  if (!claseId) return false;

  const reference = adminDb
    .collection('AsistenciasClase')
    .doc(`${claseId}_${datos.alumnoId}`);
  return adminDb.runTransaction(async (transaction) => {
    const current = await transaction.get(reference);
    if (current.exists) return false;
    transaction.create(reference, {
      claseId,
      alumnoId: datos.alumnoId,
      nombre: datos.nombre,
      sede: datos.sede,
      disciplina: String(clase.disciplina || ''),
      dispositivo: 'Modo recepción',
      metodo: 'Recepción',
      fecha: Timestamp.fromDate(datos.fecha),
    });
    return true;
  });
}

async function publicarEventoKiosco(datos: {
  alumnoId: string;
  nombre: string;
  sede: Sede;
  duplicado: boolean;
  mensaje: string;
  registroOffline: boolean;
}) {
  if (
    datos.registroOffline ||
    (datos.sede !== "MMA" && datos.sede !== "CAUCEL")
  ) {
    return;
  }
  try {
    await publishKioskEvent({
      alumnoId: datos.alumnoId,
      nombre: datos.nombre.trim().split(/\s+/)[0] || "Atleta",
      sede: datos.sede,
      duplicado: datos.duplicado,
      permitido: true,
      estadoLed: datos.duplicado ? "amarillo" : "verde",
      metodo: "CELULAR",
      mensaje: datos.mensaje,
      claseActiva: null,
    });
  } catch (error) {
    console.error("ERROR_PUBLICAR_EVENTO_KIOSCO:", error);
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => null)) as {
      alumnoId?: unknown;
      sede?: unknown;
      fecha?: unknown;
      offline?: unknown;
    } | null;
    const alumnoId =
      typeof body?.alumnoId === "string" ? body.alumnoId.trim() : "";
    const sede = normalizarSede(body?.sede);

    if (!alumnoId || !sede) {
      return NextResponse.json(
        { ok: false, mensaje: "Alumno o sede inválidos." },
        { status: 400 },
      );
    }

    const actor = await requirePanelActorAccess(request, sede);
    const registroOffline = body?.offline === true;
    const fechaRegistro =
      typeof body?.fecha === "string" ? new Date(body.fecha) : new Date();
    if (Number.isNaN(fechaRegistro.getTime())) {
      return NextResponse.json(
        { ok: false, mensaje: "La fecha de asistencia es inválida." },
        { status: 400 },
      );
    }
    const diferencia = Date.now() - fechaRegistro.getTime();
    if (diferencia < -5 * 60_000 || diferencia > 7 * 24 * 60 * 60_000) {
      return NextResponse.json(
        {
          ok: false,
          mensaje: "La asistencia offline debe pertenecer a los últimos 7 días.",
        },
        { status: 400 },
      );
    }
    const dia = fechaMerida(fechaRegistro);
    const asistenciaId = `${alumnoId}_${dia.replaceAll("-", "")}`;
    const alumnoRef = adminDb.collection("Alumnos").doc(alumnoId);
    const asistenciaRef = adminDb
      .collection("Asistencias")
      .doc(asistenciaId);
    const auditoriaRef = adminDb
      .collection("Auditoria")
      .doc(sede)
      .collection("movimientos")
      .doc();

    /*
     * Compatibilidad con asistencias antiguas y con registros creados por
     * RFID/NFC usando un ID automático. La consulta usa solo alumnoId para no
     * requerir un índice compuesto; la comparación del día se hace en el
     * servidor con la zona horaria de Mérida.
     */
    const alumnoPrevio = await alumnoRef.get();
    if (!alumnoPrevio.exists) {
      return NextResponse.json(
        { ok: false, mensaje: "El alumno no existe." },
        { status: 404 },
      );
    }

    const datosAlumnoPrevio = alumnoPrevio.data() || {};
    if (normalizarSede(datosAlumnoPrevio.sede) !== sede) {
      return NextResponse.json(
        { ok: false, mensaje: "El alumno pertenece a otra sede." },
        { status: 403 },
      );
    }
    if (datosAlumnoPrevio.activo === false) {
      return NextResponse.json(
        { ok: false, mensaje: "El alumno tiene una baja temporal." },
        { status: 409 },
      );
    }

    const asistenciasPrevias = await adminDb
      .collection("Asistencias")
      .where("alumnoId", "==", alumnoId)
      .get();
    const yaRegistroHoy = asistenciasPrevias.docs.some((documento) => {
      const fecha = documento.data().fecha;
      const fechaDate =
        fecha && typeof fecha.toDate === "function" ? fecha.toDate() : null;
      return fechaDate instanceof Date && fechaMerida(fechaDate) === dia;
    });

    const nombreAlumno = String(datosAlumnoPrevio.nombre || 'Alumno');
    const registradoEnClase = registroOffline
      ? false
      : await registrarEnClaseActiva({
          alumnoId,
          nombre: nombreAlumno,
          sede,
          fecha: fechaRegistro,
        });

    if (yaRegistroHoy) {
      if (registradoEnClase) {
        const mensaje = `${nombreAlumno} ya había ingresado hoy y quedó registrado en la clase activa.`;
        await publicarEventoKiosco({
          alumnoId,
          nombre: nombreAlumno,
          sede,
          duplicado: true,
          mensaje,
          registroOffline,
        });
        return NextResponse.json({
          ok: true,
          duplicadoDiario: true,
          asistenciaClase: true,
          nombre: nombreAlumno,
          mensaje,
        });
      }
      await publicarEventoKiosco({
        alumnoId,
        nombre: nombreAlumno,
        sede,
        duplicado: true,
        mensaje: `${nombreAlumno} ya ingresó hoy.`,
        registroOffline,
      });
      return NextResponse.json(
        {
          ok: false,
          duplicado: true,
          mensaje: `${String(datosAlumnoPrevio.nombre || "Alumno")} ya ingresó hoy.`,
        },
        { status: 409 },
      );
    }

    const resultado = await adminDb.runTransaction(async (transaction) => {
      const [alumnoSnapshot, asistenciaSnapshot] = await Promise.all([
        transaction.get(alumnoRef),
        transaction.get(asistenciaRef),
      ]);

      if (!alumnoSnapshot.exists) {
        return { estado: "no_encontrado" as const };
      }

      const alumno = alumnoSnapshot.data() || {};
      if (normalizarSede(alumno.sede) !== sede) {
        return { estado: "otra_sede" as const };
      }
      if (alumno.activo === false) {
        return { estado: "inactivo" as const };
      }
      if (asistenciaSnapshot.exists) {
        return {
          estado: "duplicado" as const,
          nombre: String(alumno.nombre || "Alumno"),
        };
      }

      const nombre = String(alumno.nombre || "Alumno");
      transaction.create(asistenciaRef, {
        alumnoId,
        nombre,
        sede,
        fecha: Timestamp.fromDate(fechaRegistro),
        acceso: "permitido",
        dispositivo: "Modo recepción",
        registroManual: true,
        registroOffline,
        sincronizadoEn: registroOffline ? FieldValue.serverTimestamp() : null,
      });
      transaction.create(auditoriaRef, {
        action: "agregar_asistencia",
        entity: "asistencia",
        entityId: asistenciaId,
        entityName: nombre,
        summary: `Recepción registró la asistencia de ${nombre}.`,
        reason: `Recepción registró la asistencia de ${nombre}.`,
        details: { alumnoId, fecha: dia, registroOffline },
        before: null,
        after: null,
        sede,
        actorUid: actor.uid,
        actorName: actor.profile.nombre || actor.email || "Usuario",
        actorEmail: actor.email || "",
        createdAt: FieldValue.serverTimestamp(),
      });

      return { estado: "creado" as const, nombre };
    });

    if (resultado.estado === "duplicado") {
      await publicarEventoKiosco({
        alumnoId,
        nombre: resultado.nombre,
        sede,
        duplicado: true,
        mensaje: `${resultado.nombre} ya ingresó hoy.`,
        registroOffline,
      });
      return NextResponse.json(
        {
          ok: false,
          duplicado: true,
          mensaje: `${resultado.nombre} ya ingresó hoy.`,
        },
        { status: 409 },
      );
    }
    if (resultado.estado === "no_encontrado") {
      return NextResponse.json(
        { ok: false, mensaje: "El alumno no existe." },
        { status: 404 },
      );
    }
    if (resultado.estado === "otra_sede") {
      return NextResponse.json(
        { ok: false, mensaje: "El alumno pertenece a otra sede." },
        { status: 403 },
      );
    }
    if (resultado.estado === "inactivo") {
      return NextResponse.json(
        { ok: false, mensaje: "El alumno tiene una baja temporal." },
        { status: 409 },
      );
    }

    await publicarEventoKiosco({
      alumnoId,
      nombre: resultado.nombre,
      sede,
      duplicado: false,
      mensaje: `¡Listo, ${resultado.nombre}! Tu asistencia se registró desde recepción.`,
      registroOffline,
    });

    return NextResponse.json({
      ok: true,
      asistenciaId,
      nombre: resultado.nombre,
      registroOffline,
    });
  } catch (error) {
    if (error instanceof RequestAccessError) {
      return NextResponse.json(
        { ok: false, mensaje: error.message },
        { status: error.status },
      );
    }
    console.error("ERROR_RECEPCION_ASISTENCIA:", error);
    return NextResponse.json(
      { ok: false, mensaje: "No se pudo registrar la asistencia." },
      { status: 500 },
    );
  }
}
