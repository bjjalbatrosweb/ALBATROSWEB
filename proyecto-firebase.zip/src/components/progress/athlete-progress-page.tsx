"use client";

import {useEffect,useState} from "react";
import {collection,doc,getDoc,getDocs,query,where} from "firebase/firestore";
import {Activity,Loader2,Network} from "lucide-react";
import {useFirestore,useUser} from "@/firebase";
import {SkillTreeView} from "./skill-tree-view";
import {PhysicalHistory} from "./physical-history";
import {normalizeSkillDiscipline,type PhysicalAssessment,type PhysicalGoals,type SkillProgress,type WellnessCheckin} from "@/lib/athlete-progress";

type Data={nombre:string;disciplina:string;habilidadesTecnicas:SkillProgress;historialFisico:PhysicalAssessment[];metasFisicas?:PhysicalGoals;bienestar:WellnessCheckin[]};

export function AthleteProgressPage({mode}:{mode:"skills"|"physical"}){
 const db=useFirestore(),{user}=useUser(),[data,setData]=useState<Data|null>(null),[error,setError]=useState('');
 useEffect(()=>{void(async()=>{if(!db||!user)return;try{const profile=await getDoc(doc(db,'usuarios',user.uid)),alumnoId=String(profile.data()?.alumnoId||'');if(!alumnoId)throw new Error('Tu cuenta todavía no está vinculada con un expediente de atleta.');const [athlete,wellness]=await Promise.all([getDoc(doc(db,'Alumnos',alumnoId)),mode==='physical'?getDocs(query(collection(db,'BienestarAtletas'),where('alumnoId','==',alumnoId))):Promise.resolve(null)]);if(!athlete.exists())throw new Error('No se encontró tu expediente.');const value=athlete.data(),bienestar=(wellness?.docs||[]).map(item=>item.data() as WellnessCheckin).filter(item=>/^\d{4}-\d{2}-\d{2}$/.test(item.fecha||'')).sort((a,b)=>b.fecha.localeCompare(a.fecha)).slice(0,45);setData({nombre:String(value.nombre||'Atleta'),disciplina:String(value.habilidadesDisciplina||value.disciplina||''),habilidadesTecnicas:(value.habilidadesTecnicas||{}) as SkillProgress,historialFisico:Array.isArray(value.historialFisico)?value.historialFisico:[],metasFisicas:(value.metasFisicas||{}) as PhysicalGoals,bienestar})}catch(e){setError(e instanceof Error?e.message:'No se pudo cargar la información.')}})()},[db,user,mode]);
 if(error)return <main className="p-8 text-white"><p className="rounded-xl bg-red-500/15 p-4 text-red-200">{error}</p></main>;
 if(!data)return <main className="grid min-h-[60vh] place-items-center"><Loader2 className="animate-spin text-cyan-300"/></main>;
 return <main className="min-h-screen bg-slate-950 p-4 text-white md:p-8"><header className="mb-6"><p className="flex items-center gap-2 text-sm font-bold text-cyan-300">{mode==='skills'?<Network className="h-4 w-4"/>:<Activity className="h-4 w-4"/>} {data.nombre}</p><h1 className="text-3xl font-black">{mode==='skills'?'Mi árbol de habilidades':'Mi estado físico'}</h1><p className="text-slate-400">{mode==='skills'?'Consulta el progreso actualizado por tu profesor.':'Consulta mediciones, recuperación, evolución y metas personales.'}</p></header>{mode==='skills'?<SkillTreeView discipline={normalizeSkillDiscipline(data.disciplina)} progress={data.habilidadesTecnicas}/>:<PhysicalHistory records={data.historialFisico} goals={data.metasFisicas} wellness={data.bienestar}/>}</main>;
}
