"use client";

import { useEffect, useState } from "react";
import {
  collection,
  doc,
  onSnapshot,
  query,
  Timestamp,
  where,
} from "firebase/firestore";
import { CalendarCheck, Loader2, MapPin, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useFirestore, useUser } from "@/firebase";
import {
  availablePlaces,
  canReserve,
  type ReservationStatus,
} from "@/lib/class-reservations";

type Reservation = {
  id: string;
  nombre: string;
  disciplina: string;
  profesor: string;
  sede: string;
  inicio: Timestamp;
  cupo: number;
  reservados: number;
  estado: ReservationStatus;
};

export default function AthleteReservationsPage() {
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();
  const [site, setSite] = useState("");
  const [items, setItems] = useState<Reservation[]>([]);
  const [reserved, setReserved] = useState<Set<string>>(new Set());
  const [working, setWorking] = useState("");
  const [message, setMessage] = useState("");
  useEffect(() => {
    if (!user) return;
    return onSnapshot(doc(firestore, "usuarios", user.uid), (snapshot) =>
      setSite(String(snapshot.data()?.sede || "")),
    );
  }, [firestore, user]);
  useEffect(() => {
    if (!site) return;
    const q = query(
      collection(firestore, "ReservasClases"),
      where("sede", "==", site),
      where("estado", "==", "publicada"),
    );
    return onSnapshot(
      q,
      (snapshot) =>
        setItems(
          snapshot.docs
            .map((entry) => ({
              id: entry.id,
              ...(entry.data() as Omit<Reservation, "id">),
            }))
            .filter((item) => (item.inicio?.toMillis?.() || 0) > Date.now())
            .sort((a, b) => a.inicio.toMillis() - b.inicio.toMillis()),
        ),
      () => setItems([]),
    );
  }, [firestore, site]);
  useEffect(() => {
    if (!user || !site || items.length === 0) {
      setReserved(new Set());
      return;
    }
    let cancelled = false;
    const ids = items.slice(0, 100).map((item) => item.id).join(",");
    void user
      .getIdToken()
      .then((token) =>
        fetch(`/api/reservas?claseIds=${encodeURIComponent(ids)}`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      )
      .then(async (response) => {
        const result = (await response.json()) as { claseIds?: string[] };
        if (!response.ok) throw new Error();
        if (!cancelled) setReserved(new Set(result.claseIds || []));
      })
      .catch(() => {
        if (!cancelled) setReserved(new Set());
      });
    return () => {
      cancelled = true;
    };
  }, [items, site, user]);
  async function toggle(item: Reservation) {
    if (!user || working) return;
    setWorking(item.id);
    setMessage("");
    try {
      const token = await user.getIdToken();
      const active = reserved.has(item.id);
      const response = await fetch(
        active
          ? `/api/reservas?claseId=${encodeURIComponent(item.id)}`
          : "/api/reservas",
        {
          method: active ? "DELETE" : "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          ...(active ? {} : { body: JSON.stringify({ claseId: item.id }) }),
        },
      );
      const result = await response.json();
      if (!response.ok)
        throw new Error(result.mensaje || "No se pudo procesar.");
      setReserved((current) => {
        const next = new Set(current);
        if (active) next.delete(item.id);
        else next.add(item.id);
        return next;
      });
      setMessage(result.mensaje);
    } catch (error) {
      setMessage(
        error instanceof Error ? error.message : "No se pudo procesar.",
      );
    } finally {
      setWorking("");
    }
  }
  if (isUserLoading)
    return (
      <main className="grid min-h-screen place-items-center bg-[#08090c] text-white">
        <Loader2 className="h-7 w-7 animate-spin" />
      </main>
    );
  return (
    <main className="min-h-screen bg-[#08090c] px-4 py-8 text-white">
      <div className="mx-auto max-w-5xl">
        <header className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#1a1c22] to-[#111824] p-6">
          <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[.2em] text-sky-300">
            <CalendarCheck className="h-4 w-4" /> Agenda del atleta
          </p>
          <h1 className="mt-2 text-3xl font-black">Reserva tu clase</h1>
          <p className="mt-2 text-sm text-white/70">
            Asegura tu lugar sin modificar tu asistencia ni tu acceso a la
            academia.
          </p>
        </header>
        {message && (
          <p
            role="status"
            className="mt-5 rounded-xl border border-sky-400/25 bg-sky-500/10 p-4 font-bold text-sky-100"
          >
            {message}
          </p>
        )}
        <section className="mt-6 grid gap-4 md:grid-cols-2">
          {!user ? (
            <p className="col-span-full rounded-2xl border border-white/15 p-8 text-center">
              Inicia sesión como atleta para consultar las clases.
            </p>
          ) : items.length === 0 ? (
            <p className="col-span-full rounded-2xl border border-dashed border-white/20 p-8 text-center text-white/70">
              No hay clases publicadas para tu sede.
            </p>
          ) : (
            items.map((item) => {
              const active = reserved.has(item.id);
              const availability = canReserve({
                status: item.estado,
                capacity: item.cupo,
                reserved: item.reservados || 0,
                startsAt: item.inicio.toDate(),
              });
              return (
                <article
                  key={item.id}
                  className="rounded-3xl border border-white/10 bg-[#15171d] p-5"
                >
                  <p className="text-xs font-black uppercase tracking-wider text-sky-300">
                    {item.disciplina}
                  </p>
                  <h2 className="mt-1 text-xl font-black">{item.nombre}</h2>
                  <p className="mt-3 text-sm text-white/70">
                    {item.inicio
                      .toDate()
                      .toLocaleString("es-MX", {
                        dateStyle: "full",
                        timeStyle: "short",
                      })}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-3 text-xs font-bold text-white/70">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />{" "}
                      {item.sede.replace("_", " ")}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-4 w-4" />{" "}
                      {availablePlaces(item.cupo, item.reservados || 0)} lugares
                    </span>
                  </div>
                  <Button
                    onClick={() => void toggle(item)}
                    disabled={
                      working === item.id || (!active && !availability.allowed)
                    }
                    variant={active ? "outline" : "default"}
                    className="mt-5 w-full font-black"
                  >
                    {working === item.id && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    {active
                      ? "Cancelar reserva"
                      : availability.allowed
                        ? "Reservar lugar"
                        : availability.reason}
                  </Button>
                </article>
              );
            })
          )}
        </section>
      </div>
    </main>
  );
}
