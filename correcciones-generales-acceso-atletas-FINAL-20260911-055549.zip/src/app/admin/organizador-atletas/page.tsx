"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { collection, getDocs, query, where } from "firebase/firestore";
import {
  AlertTriangle,
  BarChart3,
  ChevronDown,
  CirclePause,
  CirclePlay,
  Combine,
  Expand,
  Grip,
  History,
  LayoutGrid,
  Link2,
  Loader2,
  Lock,
  MapPin,
  Minimize2,
  Palette,
  Plus,
  RefreshCw,
  RotateCw,
  Search,
  Settings2,
  ShieldAlert,
  Shuffle,
  Split,
  TimerReset,
  Trash2,
  Unlink,
  Unlock,
  UserPlus,
  UserRound,
  X,
} from "lucide-react";
import { useFirestore } from "@/firebase";
import {
  calculateOrganizerAge,
  estimateOrganizerLevel,
  generateOrganizerGroups,
  normalizeOrganizerGuestName,
  oddModeLabels,
  organizerGroupingKey,
  organizerModeLabels,
  organizerPairKey,
  organizerVoiceMessage,
  OrganizerActivityPlacement,
  OrganizerExercise,
  OrganizerExerciseId,
  OrganizerHistoryRound,
  OrganizerMode,
  OrganizerRule,
  OrganizerRuleKind,
  OrganizerSafety,
  OddMode,
  pickOrganizerExercise,
  rotationStats,
  ruleKindLabels,
  safetyWarnings,
} from "@/lib/athlete-organizer";

type ColorKey =
  | "cyan"
  | "violet"
  | "lime"
  | "amber"
  | "rose"
  | "orange"
  | "blue"
  | "emerald"
  | "fuchsia"
  | "red"
  | "yellow"
  | "teal"
  | "indigo"
  | "pink"
  | "sky";
type PairMode = "fusion" | "ab";
type AthleteDocument = {
  nombre?: string;
  disciplina?: string;
  grado?: string;
  activo?: boolean;
  pesoActual?: number;
  edad?: number;
  fechaNacimiento?: string;
  emergencia?: { fechaNacimiento?: string };
};
type CubeAthlete = {
  id: string;
  nombre: string;
  disciplina: string;
  grado: string;
  peso: number | null;
  edad: number | null;
  nivel: number;
  x: number;
  y: number;
  color: ColorKey;
  note: string;
};
type AthleteGroup = {
  id: string;
  members: string[];
  x: number;
  y: number;
  mode: PairMode;
  locked: boolean;
  stationId: string;
  assignment?: "active-rest" | "floater";
  warnings: string[];
};
type Station = { id: string; name: string; color: string };
type OrganizerSettings = {
  mode: OrganizerMode;
  oddMode: OddMode;
  safety: OrganizerSafety;
  roundSeconds: number;
  restSeconds: number;
  totalRounds: number;
  autoRotate: boolean;
  sound: boolean;
  activityEnabled: boolean;
  activitySeconds: number;
  activityPlacement: OrganizerActivityPlacement;
  activityReplaceRest: boolean;
  activityBeforeFirstRound: boolean;
};
type SavedBoard = {
  version: 2;
  cubes: CubeAthlete[];
  groups: AthleteGroup[];
  history: OrganizerHistoryRound[];
  rules: OrganizerRule[];
  rulesInitialized: boolean;
  settings: OrganizerSettings;
  stations: Station[];
};
type LegacyBoard = {
  version: 1;
  cubes?: CubeAthlete[];
  pairs?: Array<{
    id: string;
    a: string;
    b: string;
    x: number;
    y: number;
    mode: PairMode;
  }>;
};
type DragState = {
  kind: "cube" | "group";
  id: string;
  width: number;
  offsetX: number;
  offsetY: number;
} | null;
type TimerPhase = "round" | "rest" | "activity";
type ActivityNext = "rest" | "start-round" | "next-round";

const BOARD_WIDTH = 1240,
  BOARD_HEIGHT = 820,
  CUBE_WIDTH = 142,
  STORAGE_PREFIX = "albatros-neon-athlete-organizer-v1";
const stationColors = [
  "#22d3ee",
  "#a78bfa",
  "#a3e635",
  "#fbbf24",
  "#fb7185",
  "#fb923c",
];
const defaultStations: Station[] = [
  "Técnica",
  "Sparring",
  "Costal",
  "Trabajo físico",
].map((name, index) => ({
  id: `station-${index + 1}`,
  name,
  color: stationColors[index],
}));
const defaultSettings = (): OrganizerSettings => ({
  mode: "fair",
  oddMode: "trio",
  safety: {
    enabled: true,
    maxWeightDifference: 12,
    maxAgeDifference: 10,
    separateMinors: true,
  },
  roundSeconds: 180,
  restSeconds: 60,
  totalRounds: 5,
  autoRotate: true,
  sound: true,
  activityEnabled: false,
  activitySeconds: 15,
  activityPlacement: "before-rest",
  activityReplaceRest: false,
  activityBeforeFirstRound: false,
});
const colors: Record<
  ColorKey,
  {
    label: string;
    hex: string;
    border: string;
    surface: string;
    text: string;
    glow: string;
  }
> = {
  cyan: {
    label: "Cian",
    hex: "#22d3ee",
    border: "border-cyan-100",
    surface: "from-cyan-200 via-cyan-400 to-cyan-600",
    text: "text-cyan-950",
    glow: "shadow-[0_0_0_1px_rgba(34,211,238,.6),0_0_18px_rgba(34,211,238,.72),0_0_48px_rgba(34,211,238,.42),0_0_90px_rgba(34,211,238,.18)]",
  },
  violet: {
    label: "Violeta",
    hex: "#a78bfa",
    border: "border-violet-100",
    surface: "from-violet-200 via-violet-400 to-violet-600",
    text: "text-violet-950",
    glow: "shadow-[0_0_0_1px_rgba(167,139,250,.6),0_0_18px_rgba(167,139,250,.7),0_0_48px_rgba(167,139,250,.4),0_0_90px_rgba(167,139,250,.18)]",
  },
  lime: {
    label: "Lima",
    hex: "#a3e635",
    border: "border-lime-100",
    surface: "from-lime-200 via-lime-400 to-lime-600",
    text: "text-lime-950",
    glow: "shadow-[0_0_0_1px_rgba(163,230,53,.6),0_0_18px_rgba(163,230,53,.7),0_0_48px_rgba(163,230,53,.4),0_0_90px_rgba(163,230,53,.17)]",
  },
  amber: {
    label: "Ámbar",
    hex: "#fbbf24",
    border: "border-amber-100",
    surface: "from-amber-200 via-amber-400 to-amber-600",
    text: "text-amber-950",
    glow: "shadow-[0_0_0_1px_rgba(251,191,36,.62),0_0_18px_rgba(251,191,36,.72),0_0_48px_rgba(251,191,36,.42),0_0_90px_rgba(251,191,36,.18)]",
  },
  rose: {
    label: "Rosa",
    hex: "#fb7185",
    border: "border-rose-100",
    surface: "from-rose-200 via-rose-400 to-rose-600",
    text: "text-rose-950",
    glow: "shadow-[0_0_0_1px_rgba(251,113,133,.62),0_0_18px_rgba(251,113,133,.72),0_0_48px_rgba(251,113,133,.42),0_0_90px_rgba(251,113,133,.18)]",
  },
  orange: {
    label: "Naranja",
    hex: "#fb923c",
    border: "border-orange-100",
    surface: "from-orange-200 via-orange-400 to-orange-600",
    text: "text-orange-950",
    glow: "shadow-[0_0_0_1px_rgba(251,146,60,.62),0_0_18px_rgba(251,146,60,.72),0_0_48px_rgba(251,146,60,.42),0_0_90px_rgba(251,146,60,.18)]",
  },
  blue: {
    label: "Azul",
    hex: "#3b82f6",
    border: "border-blue-100",
    surface: "from-blue-200 via-blue-400 to-blue-600",
    text: "text-blue-950",
    glow: "shadow-[0_0_0_1px_rgba(59,130,246,.62),0_0_18px_rgba(59,130,246,.72),0_0_48px_rgba(59,130,246,.42),0_0_90px_rgba(59,130,246,.18)]",
  },
  emerald: {
    label: "Esmeralda",
    hex: "#10b981",
    border: "border-emerald-100",
    surface: "from-emerald-200 via-emerald-400 to-emerald-600",
    text: "text-emerald-950",
    glow: "shadow-[0_0_0_1px_rgba(16,185,129,.62),0_0_18px_rgba(16,185,129,.72),0_0_48px_rgba(16,185,129,.42),0_0_90px_rgba(16,185,129,.18)]",
  },
  fuchsia: {
    label: "Fucsia",
    hex: "#d946ef",
    border: "border-fuchsia-100",
    surface: "from-fuchsia-200 via-fuchsia-400 to-fuchsia-600",
    text: "text-fuchsia-950",
    glow: "shadow-[0_0_0_1px_rgba(217,70,239,.62),0_0_18px_rgba(217,70,239,.72),0_0_48px_rgba(217,70,239,.42),0_0_90px_rgba(217,70,239,.18)]",
  },
  red: {
    label: "Rojo",
    hex: "#ef4444",
    border: "border-red-100",
    surface: "from-red-200 via-red-400 to-red-600",
    text: "text-red-950",
    glow: "shadow-[0_0_0_1px_rgba(239,68,68,.62),0_0_18px_rgba(239,68,68,.72),0_0_48px_rgba(239,68,68,.42),0_0_90px_rgba(239,68,68,.18)]",
  },
  yellow: {
    label: "Amarillo",
    hex: "#facc15",
    border: "border-yellow-100",
    surface: "from-yellow-200 via-yellow-400 to-yellow-600",
    text: "text-yellow-950",
    glow: "shadow-[0_0_0_1px_rgba(250,204,21,.62),0_0_18px_rgba(250,204,21,.72),0_0_48px_rgba(250,204,21,.42),0_0_90px_rgba(250,204,21,.18)]",
  },
  teal: {
    label: "Turquesa",
    hex: "#14b8a6",
    border: "border-teal-100",
    surface: "from-teal-200 via-teal-400 to-teal-600",
    text: "text-teal-950",
    glow: "shadow-[0_0_0_1px_rgba(20,184,166,.62),0_0_18px_rgba(20,184,166,.72),0_0_48px_rgba(20,184,166,.42),0_0_90px_rgba(20,184,166,.18)]",
  },
  indigo: {
    label: "Índigo",
    hex: "#6366f1",
    border: "border-indigo-100",
    surface: "from-indigo-200 via-indigo-400 to-indigo-600",
    text: "text-indigo-950",
    glow: "shadow-[0_0_0_1px_rgba(99,102,241,.62),0_0_18px_rgba(99,102,241,.72),0_0_48px_rgba(99,102,241,.42),0_0_90px_rgba(99,102,241,.18)]",
  },
  pink: {
    label: "Magenta",
    hex: "#ec4899",
    border: "border-pink-100",
    surface: "from-pink-200 via-pink-400 to-pink-600",
    text: "text-pink-950",
    glow: "shadow-[0_0_0_1px_rgba(236,72,153,.62),0_0_18px_rgba(236,72,153,.72),0_0_48px_rgba(236,72,153,.42),0_0_90px_rgba(236,72,153,.18)]",
  },
  sky: {
    label: "Celeste",
    hex: "#0ea5e9",
    border: "border-sky-100",
    surface: "from-sky-200 via-sky-400 to-sky-600",
    text: "text-sky-950",
    glow: "shadow-[0_0_0_1px_rgba(14,165,233,.62),0_0_18px_rgba(14,165,233,.72),0_0_48px_rgba(14,165,233,.42),0_0_90px_rgba(14,165,233,.18)]",
  },
};
const palette = Object.keys(colors) as ColorKey[];
const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));
const normalizeName = (value: string) =>
  value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("es")
    .trim();
const groupWidth = (count: number) =>
  count <= 1 ? CUBE_WIDTH : count * CUBE_WIDTH + (count - 1) * 5;
const formatClock = (seconds: number) =>
  `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
const repetitionLabel = (value: number, uppercase = false) =>
  `${value} ${value === 1 ? (uppercase ? "REPETICIÓN" : "repetición") : uppercase ? "REPETICIONES" : "repeticiones"}`;
function hydratedCube(value: Partial<CubeAthlete>): CubeAthlete {
  return {
    id: String(value.id || ""),
    nombre: String(value.nombre || "Atleta"),
    disciplina: String(value.disciplina || ""),
    grado: String(value.grado || ""),
    peso: Number(value.peso) > 0 ? Number(value.peso) : null,
    edad: Number.isFinite(value.edad) ? Number(value.edad) : null,
    nivel:
      Number(value.nivel) || estimateOrganizerLevel(String(value.grado || "")),
    x: Number(value.x) || 24,
    y: Number(value.y) || 28,
    color: palette.includes(value.color as ColorKey)
      ? (value.color as ColorKey)
      : "cyan",
    note: String(value.note || ""),
  };
}

export default function AthleteOrganizerPage() {
  const firestore = useFirestore(),
    boardRef = useRef<HTMLDivElement>(null),
    fullscreenRef = useRef<HTMLElement>(null),
    dragFrame = useRef<number | null>(null),
    messageTimer = useRef<number | null>(null),
    flashTimers = useRef<number[]>([]),
    lastExerciseRef = useRef<OrganizerExerciseId | null>(null);
  const [site, setSite] = useState("MMA"),
    [siteReady, setSiteReady] = useState(false),
    [available, setAvailable] = useState<CubeAthlete[]>([]),
    [cubes, setCubes] = useState<CubeAthlete[]>([]),
    [groups, setGroups] = useState<AthleteGroup[]>([]),
    [history, setHistory] = useState<OrganizerHistoryRound[]>([]),
    [rules, setRules] = useState<OrganizerRule[]>([]),
    [rulesInitialized, setRulesInitialized] = useState(false),
    [settings, setSettings] = useState<OrganizerSettings>(defaultSettings),
    [stations, setStations] = useState<Station[]>(defaultStations);
  const [selected, setSelected] = useState<string[]>([]),
    [search, setSearch] = useState(""),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [ready, setReady] = useState(false),
    [drag, setDrag] = useState<DragState>(null),
    [editing, setEditing] = useState<string | null>(null),
    [noteDraft, setNoteDraft] = useState(""),
    [message, setMessage] = useState(""),
    [isFullscreen, setIsFullscreen] = useState(false),
    [trayOpen, setTrayOpen] = useState(false),
    [guestOpen, setGuestOpen] = useState(false),
    [guestName, setGuestName] = useState("");
  const [ruleA, setRuleA] = useState(""),
    [ruleB, setRuleB] = useState(""),
    [ruleKind, setRuleKind] = useState<OrganizerRuleKind>("avoid"),
    [currentRound, setCurrentRound] = useState(1),
    [timeLeft, setTimeLeft] = useState(180),
    [running, setRunning] = useState(false),
    [phase, setPhase] = useState<TimerPhase>("round"),
    [flash, setFlash] = useState<"green" | "red" | "blue" | "yellow" | null>(
      null,
    ),
    [activeExercise, setActiveExercise] = useState<OrganizerExercise | null>(
      null,
    ),
    [activityNext, setActivityNext] = useState<ActivityNext>("next-round");
  const showMessage = useCallback((value: string) => {
    setMessage(value);
    if (messageTimer.current) window.clearTimeout(messageTimer.current);
    messageTimer.current = window.setTimeout(() => setMessage(""), 3800);
  }, []);
  useEffect(
    () => () => {
      if (messageTimer.current) window.clearTimeout(messageTimer.current);
      flashTimers.current.forEach((timer) => window.clearTimeout(timer));
    },
    [],
  );
  useEffect(() => {
    const element = fullscreenRef.current;
    if (!element) return;
    if (flash) element.dataset.screenFlash = flash;
    else delete element.dataset.screenFlash;
  }, [flash]);
  useEffect(() => {
    const update = () =>
      setIsFullscreen(document.fullscreenElement === fullscreenRef.current);
    document.addEventListener("fullscreenchange", update);
    return () => document.removeEventListener("fullscreenchange", update);
  }, []);
  useEffect(() => {
    setSite(localStorage.getItem("userSede") || "MMA");
    setSiteReady(true);
  }, []);
  useEffect(() => {
    if (!siteReady) return;
    setReady(false);
    const raw = localStorage.getItem(`${STORAGE_PREFIX}:${site}`);
    try {
      const parsed = raw ? (JSON.parse(raw) as SavedBoard | LegacyBoard) : null;
      if (parsed?.version === 2) {
        setCubes((parsed.cubes || []).map(hydratedCube));
        setGroups(parsed.groups || []);
        setHistory((parsed.history || []).slice(0, 40));
        setRules(parsed.rules || []);
        setRulesInitialized(Boolean(parsed.rulesInitialized));
        setSettings({
          ...defaultSettings(),
          ...parsed.settings,
          safety: { ...defaultSettings().safety, ...parsed.settings?.safety },
        });
        setStations(
          parsed.stations?.length ? parsed.stations : defaultStations,
        );
      } else if (parsed?.version === 1) {
        const legacy = parsed as LegacyBoard;
        setCubes((legacy.cubes || []).map(hydratedCube));
        setGroups(
          (legacy.pairs || []).map((pair) => ({
            id: pair.id,
            members: [pair.a, pair.b],
            x: pair.x,
            y: pair.y,
            mode: pair.mode,
            locked: false,
            stationId: "",
            warnings: [],
          })),
        );
        setHistory([]);
        setRules([]);
        setRulesInitialized(false);
        setSettings(defaultSettings());
        setStations(defaultStations);
      } else {
        setCubes([]);
        setGroups([]);
        setHistory([]);
        setRules([]);
        setRulesInitialized(false);
        setSettings(defaultSettings());
        setStations(defaultStations);
      }
    } catch {
      setCubes([]);
      setGroups([]);
      setHistory([]);
      setRules([]);
      setRulesInitialized(false);
      setSettings(defaultSettings());
      setStations(defaultStations);
    }
    setSelected([]);
    setCurrentRound(1);
    setPhase("round");
    setActiveExercise(null);
    setRunning(false);
    setReady(true);
  }, [site, siteReady]);
  useEffect(() => {
    if (ready)
      localStorage.setItem(
        `${STORAGE_PREFIX}:${site}`,
        JSON.stringify({
          version: 2,
          cubes,
          groups,
          history,
          rules,
          rulesInitialized,
          settings,
          stations,
        } satisfies SavedBoard),
      );
  }, [
    cubes,
    groups,
    history,
    ready,
    rules,
    rulesInitialized,
    settings,
    site,
    stations,
  ]);
  useEffect(() => {
    if (!running && phase !== "activity")
      setTimeLeft(
        phase === "round" ? settings.roundSeconds : settings.restSeconds,
      );
  }, [phase, running, settings.restSeconds, settings.roundSeconds]);
  const loadAthletes = useCallback(async () => {
    if (!firestore || !site || !siteReady) return;
    setLoading(true);
    setError("");
    try {
      const snapshot = await getDocs(
          query(collection(firestore, "Alumnos"), where("sede", "==", site)),
        ),
        loaded = snapshot.docs
          .filter(
            (record) => (record.data() as AthleteDocument).activo !== false,
          )
          .map((record) => {
            const data = record.data() as AthleteDocument,
              birth = data.fechaNacimiento || data.emergencia?.fechaNacimiento,
              age = calculateOrganizerAge(data.edad ?? birth);
            return hydratedCube({
              id: record.id,
              nombre: data.nombre,
              disciplina: data.disciplina,
              grado: data.grado,
              peso:
                Number(data.pesoActual) > 0 ? Number(data.pesoActual) : null,
              edad: age,
              nivel: estimateOrganizerLevel(String(data.grado || "")),
              x: 0,
              y: 0,
              color: "cyan",
              note: "",
            });
          })
          .sort((a, b) => a.nombre.localeCompare(b.nombre, "es"));
      setAvailable(loaded);
      const map = new Map(loaded.map((athlete) => [athlete.id, athlete]));
      setCubes((items) =>
        items.map((cube) =>
          map.has(cube.id)
            ? {
                ...cube,
                ...map.get(cube.id),
                x: cube.x,
                y: cube.y,
                color: cube.color,
                note: cube.note,
              }
            : cube,
        ),
      );
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : "No se pudieron cargar los atletas.",
      );
    } finally {
      setLoading(false);
    }
  }, [firestore, site, siteReady]);
  useEffect(() => {
    void loadAthletes();
  }, [loadAthletes]);
  useEffect(() => {
    if (!ready || rulesInitialized || !available.length) return;
    const find = (pattern: RegExp) =>
        available.find((athlete) =>
          pattern.test(normalizeName(athlete.nombre)),
        ),
      andrea = find(/andrea/),
      lion = find(/lion/),
      karla = find(/karla/),
      partner = find(/prueba|couch|coach/),
      seeded: OrganizerRule[] = [];
    if (andrea && lion)
      seeded.push({
        id: `rule-${Date.now()}-avoid`,
        a: andrea.id,
        b: lion.id,
        kind: "avoid",
        strength: 100,
        maxConsecutive: 1,
      });
    if (karla && partner)
      seeded.push({
        id: `rule-${Date.now()}-prefer`,
        a: karla.id,
        b: partner.id,
        kind: "prefer",
        strength: 70,
        maxConsecutive: 2,
      });
    setRules(seeded);
    setRulesInitialized(true);
  }, [available, ready, rulesInitialized]);
  useEffect(() => {
    if (!drag) return;
    const move = (event: PointerEvent) => {
        const clientX = event.clientX,
          clientY = event.clientY;
        if (dragFrame.current !== null) cancelAnimationFrame(dragFrame.current);
        dragFrame.current = requestAnimationFrame(() => {
          const rect = boardRef.current?.getBoundingClientRect();
          if (!rect) return;
          const x = clamp(
              clientX - rect.left - drag.offsetX,
              8,
              BOARD_WIDTH - drag.width - 8,
            ),
            y = clamp(clientY - rect.top - drag.offsetY, 8, BOARD_HEIGHT - 145);
          if (drag.kind === "cube")
            setCubes((items) =>
              items.map((item) =>
                item.id === drag.id ? { ...item, x, y } : item,
              ),
            );
          else
            setGroups((items) =>
              items.map((item) =>
                item.id === drag.id ? { ...item, x, y } : item,
              ),
            );
          dragFrame.current = null;
        });
      },
      up = () => setDrag(null);
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("pointerup", up, { once: true });
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      if (dragFrame.current !== null) cancelAnimationFrame(dragFrame.current);
    };
  }, [drag]);
  const cubeMap = useMemo(
      () => new Map(cubes.map((cube) => [cube.id, cube])),
      [cubes],
    ),
    groupedIds = useMemo(
      () => new Set(groups.flatMap((group) => group.members)),
      [groups],
    ),
    placedIds = useMemo(() => new Set(cubes.map((cube) => cube.id)), [cubes]),
    ungrouped = cubes.filter((cube) => !groupedIds.has(cube.id)),
    term = search.trim().toLocaleLowerCase("es"),
    tray = available.filter(
      (athlete) =>
        !placedIds.has(athlete.id) &&
        (!term ||
          `${athlete.nombre} ${athlete.grado} ${athlete.disciplina}`
            .toLocaleLowerCase("es")
            .includes(term)),
    ),
    stats = useMemo(() => rotationStats(history), [history]);
  const snapshot = useCallback((): OrganizerHistoryRound | null => {
    const active = groups
      .filter((group) => group.members.length >= 1)
      .map((group) => group.members);
    return active.length
      ? {
          id: `round-${Date.now()}`,
          createdAt: new Date().toISOString(),
          groups: active,
        }
      : null;
  }, [groups]);
  const performRotation = useCallback(
    (automatic = false) => {
      const locked = groups.filter((group) => group.locked),
        lockedIds = new Set(locked.flatMap((group) => group.members)),
        participants = cubes.filter((cube) => !lockedIds.has(cube.id)),
        current = snapshot(),
        engineHistory = current ? [current, ...history].slice(0, 40) : history,
        currentKey = organizerGroupingKey(
          groups.filter((group) => !group.locked).map((group) => group.members),
        );
      if (participants.length < 2) {
        showMessage(
          "Se necesitan al menos dos atletas libres para reacomodar.",
        );
        return false;
      }
      let generated: ReturnType<typeof generateOrganizerGroups> = null,
        fallback: ReturnType<typeof generateOrganizerGroups> = null;
      for (let attempt = 0; attempt < 80; attempt++) {
        const candidate = generateOrganizerGroups({
          athletes: participants,
          rules,
          history: engineHistory,
          mode: settings.mode,
          oddMode: settings.oddMode,
          safety: settings.safety,
        });
        if (!candidate) continue;
        fallback ??= candidate;
        if (
          organizerGroupingKey(candidate.map((group) => group.members)) !==
          currentKey
        ) {
          generated = candidate;
          break;
        }
      }
      generated ??= fallback;
      if (!generated) {
        showMessage(
          "No existe una distribución válida con las reglas actuales.",
        );
        return false;
      }
      const changed =
          organizerGroupingKey(generated.map((group) => group.members)) !==
          currentKey,
        warnings = generated.flatMap((group) => group.warnings);
      if (
        warnings.length &&
        settings.safety.enabled &&
        !automatic &&
        !window.confirm(
          `La distribución tiene ${warnings.length} aviso(s) de seguridad. ¿Deseas aplicarla de todos modos?`,
        )
      )
        return false;
      const old = groups.filter((group) => !group.locked),
        stamp = Date.now();
      let cursorX = 24,
        cursorY = 28;
      const created: AthleteGroup[] = generated.map((group, index) => {
        const width = groupWidth(group.members.length);
        if (cursorX + width > BOARD_WIDTH - 8) {
          cursorX = 24;
          cursorY += 155;
        }
        const prior = old[index],
          x = clamp(prior?.x ?? cursorX, 8, BOARD_WIDTH - width - 8),
          y = clamp(prior?.y ?? cursorY, 8, BOARD_HEIGHT - 145);
        if (!prior) cursorX += width + 12;
        return {
          id: `group-${stamp}-${index}`,
          members: group.members,
          x,
          y,
          mode: prior?.mode || "ab",
          locked: false,
          stationId:
            prior?.stationId ||
            stations[index % Math.max(1, stations.length)]?.id ||
            "",
          assignment: group.assignment,
          warnings: group.warnings,
        };
      });
      if (current) setHistory((items) => [current, ...items].slice(0, 40));
      setGroups([...locked, ...created]);
      setSelected([]);
      showMessage(
        !changed
          ? "No existe otra combinación posible con los atletas y bloqueos actuales."
          : warnings.length
            ? `Rotación aplicada al instante con ${warnings.length} aviso(s) de seguridad.`
            : "Equipos cambiados al instante con reparto justo.",
      );
      return true;
    },
    [
      cubes,
      groups,
      history,
      rules,
      settings.mode,
      settings.oddMode,
      settings.safety,
      showMessage,
      snapshot,
      stations,
    ],
  );
  const beep = useCallback(
    (frequency = 760, count = 1) => {
      if (!settings.sound) return;
      try {
        const AudioContextClass =
          window.AudioContext ||
          (
            window as typeof window & {
              webkitAudioContext?: typeof AudioContext;
            }
          ).webkitAudioContext;
        if (!AudioContextClass) return;
        const context = new AudioContextClass();
        for (let index = 0; index < count; index++) {
          const oscillator = context.createOscillator(),
            gain = context.createGain(),
            start = context.currentTime + index * 0.3;
          oscillator.type = "square";
          oscillator.frequency.value = frequency;
          gain.gain.setValueAtTime(0.0001, start);
          gain.gain.exponentialRampToValueAtTime(0.34, start + 0.018);
          gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.23);
          oscillator.connect(gain);
          gain.connect(context.destination);
          oscillator.start(start);
          oscillator.stop(start + 0.24);
        }
        window.setTimeout(() => void context.close(), count * 320 + 250);
      } catch {
        /* El cronómetro funciona aunque el navegador bloquee audio. */
      }
    },
    [settings.sound],
  );
  const speak = useCallback(
    (message: string) => {
      if (
        !settings.sound ||
        typeof window === "undefined" ||
        !("speechSynthesis" in window)
      )
        return;
      try {
        const utterance = new SpeechSynthesisUtterance(message);
        utterance.lang = "es-MX";
        utterance.rate = 0.92;
        utterance.pitch = 1;
        utterance.volume = 1;
        window.speechSynthesis.speak(utterance);
      } catch {
        /* El cronómetro funciona aunque el navegador no permita voz. */
      }
    },
    [settings.sound],
  );
  const clearFlashTimers = useCallback(() => {
      flashTimers.current.forEach((timer) => window.clearTimeout(timer));
      flashTimers.current = [];
    }, []),
    startFlash = useCallback(
      (color: "green" | "red" | "blue" | "yellow", duration = 1800) => {
        clearFlashTimers();
        setFlash(color);
        flashTimers.current = [
          window.setTimeout(() => setFlash(null), duration),
        ];
      },
      [clearFlashTimers],
    ),
    endRoundFlash = useCallback(
      (withRest: boolean) => {
        clearFlashTimers();
        setFlash("red");
        if (withRest) {
          flashTimers.current = [
            window.setTimeout(() => setFlash("blue"), 900),
            window.setTimeout(() => setFlash(null), 3900),
          ];
        } else
          flashTimers.current = [window.setTimeout(() => setFlash(null), 2000)];
      },
      [clearFlashTimers],
    );
  const chooseExercise = useCallback(
    (seconds = settings.activitySeconds) => {
      const exercise = pickOrganizerExercise(
        seconds,
        Math.random,
        lastExerciseRef.current,
      );
      lastExerciseRef.current = exercise.id;
      setActiveExercise(exercise);
      return exercise;
    },
    [settings.activitySeconds],
  );
  const announceActivity = useCallback(
    (exercise: OrganizerExercise, afterRound = false) => {
      clearFlashTimers();
      if (afterRound) {
        setFlash("red");
        flashTimers.current = [
          window.setTimeout(() => {
            setFlash("yellow");
            beep(1180, 3);
          }, 650),
          window.setTimeout(() => setFlash(null), 2850),
        ];
      } else {
        beep(1180, 3);
        startFlash("yellow", 2200);
      }
      showMessage(
        `${exercise.label.toUpperCase()} · ${repetitionLabel(exercise.repetitions)} · ${exercise.seconds} s`,
      );
    },
    [beep, clearFlashTimers, showMessage, startFlash],
  );
  const startActivity = useCallback(
    (next: ActivityNext, afterRound = false) => {
      const exercise = chooseExercise();
      setActivityNext(next);
      setPhase("activity");
      setTimeLeft(exercise.seconds);
      announceActivity(exercise, afterRound);
    },
    [announceActivity, chooseExercise],
  );
  const startRound = useCallback(
    (advance: boolean) => {
      const targetRound = Math.min(
        settings.totalRounds,
        currentRound + (advance ? 1 : 0),
      );
      setActiveExercise(null);
      setPhase("round");
      setTimeLeft(settings.roundSeconds);
      beep(980, 2);
      speak(organizerVoiceMessage("round-start", targetRound));
      startFlash("green", 1900);
      if (advance) {
        setCurrentRound((value) => value + 1);
        if (settings.autoRotate) performRotation(true);
      }
      showMessage(`Round ${targetRound} iniciado.`);
    },
    [
      beep,
      currentRound,
      performRotation,
      settings.autoRotate,
      settings.roundSeconds,
      settings.totalRounds,
      showMessage,
      speak,
      startFlash,
    ],
  );
  const startRest = useCallback(
    (embeddedActivity: boolean, afterRound = false) => {
      setPhase("rest");
      setTimeLeft(settings.restSeconds);
      speak(organizerVoiceMessage("rest", 1, settings.restSeconds));
      if (embeddedActivity) {
        const exercise = chooseExercise(
          Math.min(settings.activitySeconds, settings.restSeconds),
        );
        announceActivity(exercise, afterRound);
      } else {
        setActiveExercise(null);
        if (afterRound) endRoundFlash(true);
        else startFlash("blue", 1900);
        showMessage(`Descanso · ${settings.restSeconds} segundos`);
      }
    },
    [
      announceActivity,
      chooseExercise,
      endRoundFlash,
      settings.activitySeconds,
      settings.restSeconds,
      showMessage,
      speak,
      startFlash,
    ],
  );
  useEffect(() => {
    if (!running) return;
    const timer = window.setTimeout(() => {
      if (timeLeft <= 1) {
        if (phase === "round") {
          const hasNext = currentRound < settings.totalRounds;
          beep(430, 3);
          speak(organizerVoiceMessage(hasNext ? "round-end" : "session-end"));
          if (!hasNext) {
            endRoundFlash(false);
            setRunning(false);
            setPhase("round");
            setActiveExercise(null);
            setCurrentRound(1);
            setTimeLeft(settings.roundSeconds);
            showMessage("Sesión terminada.");
          } else if (
            settings.activityEnabled &&
            (settings.activityReplaceRest ||
              settings.activityPlacement === "before-rest")
          ) {
            startActivity(
              settings.activityReplaceRest ? "next-round" : "rest",
              true,
            );
          } else if (
            settings.activityEnabled &&
            settings.activityPlacement === "during-rest"
          )
            startRest(true, true);
          else startRest(false, true);
        } else if (phase === "activity") {
          beep(1320, 2);
          if (activityNext === "rest") startRest(false);
          else startRound(activityNext === "next-round");
        } else if (
          settings.activityEnabled &&
          !settings.activityReplaceRest &&
          settings.activityPlacement === "after-rest"
        )
          startActivity("next-round");
        else startRound(true);
      } else {
        if (
          phase === "rest" &&
          activeExercise &&
          timeLeft <= settings.restSeconds - activeExercise.seconds + 1
        )
          setActiveExercise(null);
        if (timeLeft === 30 || timeLeft === 10 || timeLeft <= 5)
          beep(
            phase === "round"
              ? 850
              : phase === "activity" || activeExercise
                ? 1120
                : 680,
            timeLeft <= 3 ? 2 : 1,
          );
        setTimeLeft((value) => value - 1);
      }
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [
    activeExercise,
    activityNext,
    beep,
    currentRound,
    endRoundFlash,
    phase,
    running,
    settings.activityEnabled,
    settings.activityPlacement,
    settings.activityReplaceRest,
    settings.restSeconds,
    settings.roundSeconds,
    settings.totalRounds,
    showMessage,
    speak,
    startActivity,
    startRest,
    startRound,
    timeLeft,
  ]);
  const toggleTimer = () => {
      if (running) {
        setRunning(false);
        return;
      }
      if (
        phase === "round" &&
        timeLeft === settings.roundSeconds &&
        currentRound === 1 &&
        settings.activityEnabled &&
        settings.activityBeforeFirstRound
      ) {
        setRunning(true);
        startActivity("start-round");
        return;
      }
      if (phase === "round" && timeLeft === settings.roundSeconds) {
        beep(980, 2);
        speak(organizerVoiceMessage("round-start", currentRound));
        startFlash("green", 1900);
      } else beep(760);
      setRunning(true);
    },
    skipToNextRound = () => {
      setActiveExercise(null);
      if (currentRound >= settings.totalRounds) {
        setRunning(false);
        setPhase("round");
        setCurrentRound(1);
        setTimeLeft(settings.roundSeconds);
        showMessage("Temporizador reiniciado.");
        return;
      }
      if (performRotation()) {
        const targetRound = currentRound + 1;
        setPhase("round");
        setCurrentRound(targetRound);
        setTimeLeft(settings.roundSeconds);
        beep(980, 2);
        speak(organizerVoiceMessage("round-start", targetRound));
        startFlash("green", 1900);
      }
    },
    resetTimer = () => {
      setRunning(false);
      setPhase("round");
      setActiveExercise(null);
      setActivityNext("next-round");
      setCurrentRound(1);
      setTimeLeft(settings.roundSeconds);
      clearFlashTimers();
      setFlash(null);
      if (typeof window !== "undefined" && "speechSynthesis" in window)
        window.speechSynthesis.cancel();
    };
  const nextPosition = () => {
      const count = ungrouped.length + groups.length,
        index = count % 7,
        row = Math.floor(count / 7);
      return { x: 24 + index * 166, y: 28 + (row % 5) * 142 };
    },
    addAthlete = (athlete: CubeAthlete) => {
      const position = nextPosition(),
        color = palette[cubes.length % palette.length];
      setCubes((items) => [...items, { ...athlete, ...position, color }]);
    },
    addAllVisible = () => {
      const candidates = tray.slice(0, 40),
        start = cubes.length;
      setCubes((items) => [
        ...items,
        ...candidates.map((athlete, index) => ({
          ...athlete,
          x: 24 + ((start + index) % 7) * 166,
          y: 28 + (Math.floor((start + index) / 7) % 5) * 142,
          color: palette[(start + index) % palette.length],
        })),
      ]);
    },
    toggleSelected = (id: string) =>
      setSelected((items) =>
        items.includes(id)
          ? items.filter((item) => item !== id)
          : [...items, id].slice(-2),
      ),
    pairRule = (a: string, b: string) =>
      rules.find(
        (rule) => organizerPairKey(rule.a, rule.b) === organizerPairKey(a, b),
      );
  const addGuest = () => {
    const nombre = normalizeOrganizerGuestName(guestName);
    if (!nombre) {
      showMessage("Escribe un nombre de al menos dos caracteres.");
      return;
    }
    const position = nextPosition(),
      color = palette[cubes.length % palette.length],
      guest = hydratedCube({
        id: `guest-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        nombre,
        disciplina: "Invitado",
        grado: "Primera clase",
        nivel: 1,
        peso: null,
        edad: null,
        note: "INVITADO",
        ...position,
        color,
      });
    setCubes((items) => [...items, guest]);
    setGuestName("");
    setGuestOpen(false);
    showMessage(`${nombre} fue agregado como invitado local.`);
  };
  const createPair = (mode: PairMode) => {
      if (selected.length !== 2 || selected.some((id) => groupedIds.has(id)))
        return;
      const [a, b] = selected,
        first = cubeMap.get(a),
        second = cubeMap.get(b),
        rule = pairRule(a, b);
      if (!first || !second) return;
      if (rule?.kind === "avoid") {
        showMessage("Esta pareja está bloqueada por una regla.");
        return;
      }
      const warnings = safetyWarnings([first, second], settings.safety);
      if (
        warnings.length &&
        !window.confirm(
          `${warnings.join("\n")}\n\n¿Crear la pareja de todos modos?`,
        )
      )
        return;
      setGroups((items) => [
        ...items,
        {
          id: `group-${Date.now()}`,
          members: [a, b],
          x: Math.round((first.x + second.x) / 2),
          y: Math.round((first.y + second.y) / 2),
          mode,
          locked: false,
          stationId: "",
          warnings,
        },
      ]);
      setSelected([]);
    },
    splitGroup = (id: string) => {
      const group = groups.find((item) => item.id === id);
      if (!group) return;
      setCubes((items) =>
        items.map((cube) => {
          const index = group.members.indexOf(cube.id);
          return index >= 0
            ? {
                ...cube,
                x: clamp(
                  group.x + index * 154,
                  8,
                  BOARD_WIDTH - CUBE_WIDTH - 8,
                ),
                y: group.y,
              }
            : cube;
        }),
      );
      setGroups((items) => items.filter((item) => item.id !== id));
    },
    removeCube = (id: string) => {
      setGroups((items) =>
        items.filter((group) => !group.members.includes(id)),
      );
      setCubes((items) => items.filter((item) => item.id !== id));
      setSelected((items) => items.filter((item) => item !== id));
    };
  const startDrag = (
      event: React.PointerEvent,
      kind: "cube" | "group",
      id: string,
      x: number,
      y: number,
      width: number,
    ) => {
      const target = event.target as HTMLElement;
      if (
        target.closest("button,input,select") &&
        !target.closest("[data-drag-handle]")
      )
        return;
      const rect = boardRef.current?.getBoundingClientRect();
      if (!rect) return;
      event.preventDefault();
      setDrag({
        kind,
        id,
        width,
        offsetX: event.clientX - rect.left - x,
        offsetY: event.clientY - rect.top - y,
      });
    },
    autoArrange = () => {
      let cursorX = 24,
        cursorY = 28;
      setGroups((items) =>
        items.map((group) => {
          const width = groupWidth(group.members.length);
          if (cursorX + width > BOARD_WIDTH - 8) {
            cursorX = 24;
            cursorY += 155;
          }
          const arranged = { ...group, x: cursorX, y: cursorY };
          cursorX += width + 12;
          return arranged;
        }),
      );
      setCubes((items) =>
        items.map((cube) => {
          if (groupedIds.has(cube.id)) return cube;
          if (cursorX + CUBE_WIDTH > BOARD_WIDTH - 8) {
            cursorX = 24;
            cursorY += 142;
          }
          const arranged = { ...cube, x: cursorX, y: cursorY };
          cursorX += CUBE_WIDTH + 12;
          return arranged;
        }),
      );
    },
    beginNote = (id: string) => {
      const cube = cubeMap.get(id);
      if (!cube) return;
      setEditing(id);
      setNoteDraft(cube.note);
    },
    saveNote = () => {
      if (editing)
        setCubes((items) =>
          items.map((cube) =>
            cube.id === editing
              ? { ...cube, note: noteDraft.trim().slice(0, 40) }
              : cube,
          ),
        );
      setEditing(null);
    };
  const rotateStations = () => {
      setGroups((items) =>
        items.map((group) => {
          const current = stations.findIndex(
            (station) => station.id === group.stationId,
          );
          return {
            ...group,
            stationId:
              stations[(current + 1 + stations.length) % stations.length]?.id ||
              "",
          };
        }),
      );
      showMessage("Las estaciones avanzaron una posición.");
    },
    addRule = () => {
      if (!ruleA || !ruleB || ruleA === ruleB) return;
      setRules((items) => [
        ...items.filter(
          (rule) =>
            organizerPairKey(rule.a, rule.b) !== organizerPairKey(ruleA, ruleB),
        ),
        {
          id: `rule-${Date.now()}`,
          a: ruleA,
          b: ruleB,
          kind: ruleKind,
          strength: 70,
          maxConsecutive: 2,
        },
      ]);
      setRuleA("");
      setRuleB("");
    },
    clearBoard = () => {
      if (
        !window.confirm(
          "¿Quitar todos los cubos, grupos e historial del tablero?",
        )
      )
        return;
      setCubes([]);
      setGroups([]);
      setHistory([]);
      setSelected([]);
    },
    toggleFullscreen = async () => {
      try {
        if (document.fullscreenElement) await document.exitFullscreen();
        else await fullscreenRef.current?.requestFullscreen();
      } catch {
        /* Continúa disponible sin pantalla completa. */
      }
    };

  return (
    <main className="min-h-screen bg-[#05070b] p-4 text-white sm:p-6 lg:p-8">
      <div className="mx-auto max-w-[1800px] space-y-5">
        <header className="relative overflow-hidden rounded-[2.2rem] border border-cyan-300/15 bg-[radial-gradient(circle_at_85%_0%,rgba(34,211,238,.17),transparent_35%),radial-gradient(circle_at_10%_100%,rgba(168,85,247,.15),transparent_35%),#0a0d14] p-6 shadow-2xl sm:p-8">
          <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rotate-12 rounded-[3rem] border-[26px] border-cyan-300/[.035]" />
          <div className="relative flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
            <div>
              <p className="eyebrow flex items-center gap-2 text-cyan-300">
                <LayoutGrid />
                Organización inteligente · {site}
              </p>
              <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-5xl">
                Organizador de atletas
              </h1>
              <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-300 sm:text-base">
                Parejas justas, reglas editables, estaciones, control de
                seguridad y rotaciones automáticas.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Status icon={UserRound} value={cubes.length} label="atletas" />
              <Status
                icon={Link2}
                value={
                  groups.filter((group) => group.members.length > 1).length
                }
                label="grupos"
              />
              <Status icon={BarChart3} value={stats.fairness} label="equidad" />
              <button
                type="button"
                onClick={() => void toggleFullscreen()}
                className="hero-button"
              >
                <Expand />
                Pantalla
              </button>
            </div>
          </div>
        </header>
        {error && (
          <div
            role="alert"
            className="rounded-2xl border border-rose-300/25 bg-rose-500/10 p-4 text-rose-100"
          >
            {error}
          </div>
        )}
        <section className="grid gap-4 xl:grid-cols-[1.3fr_.7fr]">
          <div className="rounded-[1.75rem] border border-white/10 bg-[#0c1018] p-5">
            <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
              <div>
                <p className="eyebrow text-emerald-300">Motor de rotación</p>
                <h2 className="mt-1 text-2xl font-black">
                  {organizerModeLabels[settings.mode]}
                </h2>
                <p className="mt-1 text-sm text-slate-400">
                  Cambia parejas sin perder posiciones, bloqueos ni estaciones.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                <SelectMini
                  label="Criterio"
                  value={settings.mode}
                  onChange={(value) =>
                    setSettings((item) => ({
                      ...item,
                      mode: value as OrganizerMode,
                    }))
                  }
                  options={organizerModeLabels}
                />
                <SelectMini
                  label="Impares"
                  value={settings.oddMode}
                  onChange={(value) =>
                    setSettings((item) => ({
                      ...item,
                      oddMode: value as OddMode,
                    }))
                  }
                  options={oddModeLabels}
                />
                <SelectMini
                  label="Round"
                  value={String(settings.roundSeconds)}
                  onChange={(value) =>
                    setSettings((item) => ({
                      ...item,
                      roundSeconds: Number(value),
                    }))
                  }
                  options={{
                    "60": "1 min",
                    "120": "2 min",
                    "180": "3 min",
                    "240": "4 min",
                    "300": "5 min",
                  }}
                />
                <SelectMini
                  label="Descanso"
                  value={String(settings.restSeconds)}
                  onChange={(value) =>
                    setSettings((item) => ({
                      ...item,
                      restSeconds: Number(value),
                    }))
                  }
                  options={{
                    "15": "15 s",
                    "30": "30 s",
                    "45": "45 s",
                    "60": "1 min",
                    "90": "1:30",
                    "120": "2 min",
                  }}
                />
                <SelectMini
                  label="Rondas"
                  value={String(settings.totalRounds)}
                  onChange={(value) =>
                    setSettings((item) => ({
                      ...item,
                      totalRounds: Number(value),
                    }))
                  }
                  options={{
                    "3": "3",
                    "5": "5",
                    "6": "6",
                    "8": "8",
                    "10": "10",
                  }}
                />
              </div>
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => performRotation()}
                className="primary-button"
              >
                <RefreshCw />
                Cambiar parejas
              </button>
              <button
                type="button"
                onClick={toggleTimer}
                className="tool-button"
              >
                {running ? <CirclePause /> : <CirclePlay />}
                {running
                  ? "Pausar"
                  : phase === "rest"
                    ? "Continuar descanso"
                    : phase === "activity"
                      ? "Continuar actividad"
                      : "Iniciar"}
              </button>
              <button
                type="button"
                onClick={skipToNextRound}
                className="tool-button"
              >
                <RotateCw />
                Siguiente ronda
              </button>
              <Switch
                label="Rotación automática"
                checked={settings.autoRotate}
                onChange={(autoRotate) =>
                  setSettings((item) => ({ ...item, autoRotate }))
                }
              />
              <Switch
                label="Sonido"
                checked={settings.sound}
                onChange={(sound) =>
                  setSettings((item) => ({ ...item, sound }))
                }
              />
              <Switch
                label="Actividad aleatoria"
                checked={settings.activityEnabled}
                onChange={(activityEnabled) =>
                  setSettings((item) => ({ ...item, activityEnabled }))
                }
              />
            </div>
            {settings.activityEnabled && (
              <div className="mt-4 rounded-2xl border border-amber-300/20 bg-amber-400/[.06] p-3">
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                  <PlacementSwitch
                    value={settings.activityPlacement}
                    onChange={(activityPlacement) =>
                      setSettings((item) => ({ ...item, activityPlacement }))
                    }
                  />
                  <SelectMini
                    label="Actividad"
                    value={String(settings.activitySeconds)}
                    onChange={(value) =>
                      setSettings((item) => ({
                        ...item,
                        activitySeconds: Number(value),
                      }))
                    }
                    options={{
                      "5": "5 s",
                      "10": "10 s",
                      "15": "15 s",
                      "20": "20 s",
                      "25": "25 s",
                      "30": "30 s",
                    }}
                  />
                  <Switch
                    label="Sustituye descanso"
                    checked={settings.activityReplaceRest}
                    onChange={(activityReplaceRest) =>
                      setSettings((item) => ({ ...item, activityReplaceRest }))
                    }
                  />
                  <Switch
                    label="Antes del primer round"
                    checked={settings.activityBeforeFirstRound}
                    onChange={(activityBeforeFirstRound) =>
                      setSettings((item) => ({
                        ...item,
                        activityBeforeFirstRound,
                      }))
                    }
                  />
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-black/25 px-3 py-2">
                  <span className="eyebrow text-amber-300">
                    Secuencia activa
                  </span>
                  <b className="text-xs text-amber-50">
                    {settings.activityReplaceRest
                      ? "Roleo → actividad → roleo"
                      : settings.activityPlacement === "before-rest"
                        ? "Roleo → actividad → descanso → roleo"
                        : settings.activityPlacement === "during-rest"
                          ? "Roleo → descanso activo → roleo"
                          : "Roleo → descanso → actividad → roleo"}
                  </b>
                </div>
              </div>
            )}
          </div>
          <div className="rounded-[1.75rem] border border-cyan-300/15 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,.14),transparent_42%),#0b1018] p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="eyebrow text-cyan-300">Resumen de clase</p>
                <h3 className="mt-1 text-xl font-black">
                  Rotación inteligente activa
                </h3>
                <p className="mt-1 text-xs text-slate-500">
                  El reloj principal está integrado en el tablero.
                </p>
              </div>
              <BarChart3 className="h-10 w-10 text-cyan-300" />
            </div>
            <div className="mt-5 grid grid-cols-3 gap-2 text-center">
              <MiniMetric value={stats.rounds} label="rotaciones" />
              <MiniMetric value={stats.uniquePairs} label="parejas únicas" />
              <MiniMetric value={`${stats.fairness}%`} label="equidad" />
            </div>
          </div>
        </section>
        <details className="group rounded-[1.75rem] border border-white/10 bg-[#0a0e15] p-4">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-3">
            <span className="flex items-center gap-3">
              <span className="neon-icon">
                <Settings2 />
              </span>
              <span>
                <b className="block">Configuración avanzada</b>
                <small className="text-slate-500">
                  Reglas, seguridad, estaciones e historial
                </small>
              </span>
            </span>
            <span className="rounded-full bg-white/[.06] px-3 py-1 text-[10px] font-black text-slate-400">
              ABRIR
            </span>
          </summary>
          <div className="mt-5 grid gap-4 border-t border-white/[.07] pt-5 2xl:grid-cols-4">
            <ConfigCard
              icon={Link2}
              title="Reglas de pareja"
              subtitle="Sin modificar código"
            >
              <div className="grid gap-2">
                <select
                  className="config-input"
                  value={ruleA}
                  onChange={(event) => setRuleA(event.target.value)}
                >
                  <option value="">Atleta A</option>
                  {cubes.map((cube) => (
                    <option key={cube.id} value={cube.id}>
                      {cube.nombre}
                    </option>
                  ))}
                </select>
                <select
                  className="config-input"
                  value={ruleB}
                  onChange={(event) => setRuleB(event.target.value)}
                >
                  <option value="">Atleta B</option>
                  {cubes
                    .filter((cube) => cube.id !== ruleA)
                    .map((cube) => (
                      <option key={cube.id} value={cube.id}>
                        {cube.nombre}
                      </option>
                    ))}
                </select>
                <select
                  className="config-input"
                  value={ruleKind}
                  onChange={(event) =>
                    setRuleKind(event.target.value as OrganizerRuleKind)
                  }
                >
                  {Object.entries(ruleKindLabels).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={addRule}
                  disabled={!ruleA || !ruleB}
                  className="secondary-button"
                >
                  <Plus />
                  Agregar regla
                </button>
              </div>
              <div className="mt-3 max-h-52 space-y-2 overflow-auto">
                {rules.map((rule) => (
                  <RuleRow
                    key={rule.id}
                    rule={rule}
                    names={cubeMap}
                    onChange={(patch) =>
                      setRules((items) =>
                        items.map((item) =>
                          item.id === rule.id ? { ...item, ...patch } : item,
                        ),
                      )
                    }
                    onDelete={() =>
                      setRules((items) =>
                        items.filter((item) => item.id !== rule.id),
                      )
                    }
                  />
                ))}
              </div>
            </ConfigCard>
            <ConfigCard
              icon={ShieldAlert}
              title="Control de seguridad"
              subtitle="Advierte; tú decides"
            >
              <Switch
                label="Revisar diferencias"
                checked={settings.safety.enabled}
                onChange={(enabled) =>
                  setSettings((item) => ({
                    ...item,
                    safety: { ...item.safety, enabled },
                  }))
                }
              />
              <div className="mt-3 grid grid-cols-2 gap-2">
                <NumberMini
                  label="Peso máximo"
                  value={settings.safety.maxWeightDifference}
                  suffix="kg"
                  onChange={(maxWeightDifference) =>
                    setSettings((item) => ({
                      ...item,
                      safety: { ...item.safety, maxWeightDifference },
                    }))
                  }
                />
                <NumberMini
                  label="Edad máxima"
                  value={settings.safety.maxAgeDifference}
                  suffix="años"
                  onChange={(maxAgeDifference) =>
                    setSettings((item) => ({
                      ...item,
                      safety: { ...item.safety, maxAgeDifference },
                    }))
                  }
                />
              </div>
              <Switch
                label="Avisar menor + adulto"
                checked={settings.safety.separateMinors}
                onChange={(separateMinors) =>
                  setSettings((item) => ({
                    ...item,
                    safety: { ...item.safety, separateMinors },
                  }))
                }
              />
              <p className="mt-3 text-[10px] leading-4 text-slate-500">
                {
                  cubes.filter((cube) => !cube.peso || cube.edad === null)
                    .length
                }{" "}
                atleta(s) tienen peso o edad incompletos.
              </p>
            </ConfigCard>
            <ConfigCard
              icon={MapPin}
              title="Estaciones"
              subtitle="Rota grupos completos"
            >
              <div className="space-y-2">
                {stations.map((station) => (
                  <div key={station.id} className="flex items-center gap-2">
                    <span
                      className="h-3 w-3 rounded-full"
                      style={{ background: station.color }}
                    />
                    <input
                      className="config-input min-w-0 flex-1"
                      value={station.name}
                      onChange={(event) =>
                        setStations((items) =>
                          items.map((item) =>
                            item.id === station.id
                              ? {
                                  ...item,
                                  name: event.target.value.slice(0, 24),
                                }
                              : item,
                          ),
                        )
                      }
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setStations((items) =>
                          items.filter((item) => item.id !== station.id),
                        )
                      }
                      className="icon-button"
                      aria-label="Eliminar estación"
                    >
                      <X />
                    </button>
                  </div>
                ))}
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setStations((items) =>
                      [
                        ...items,
                        {
                          id: `station-${Date.now()}`,
                          name: `Estación ${items.length + 1}`,
                          color:
                            stationColors[items.length % stationColors.length],
                        },
                      ].slice(0, 8),
                    )
                  }
                  className="secondary-button"
                >
                  <Plus />
                  Estación
                </button>
                <button
                  type="button"
                  onClick={rotateStations}
                  disabled={!stations.length}
                  className="secondary-button"
                >
                  <RotateCw />
                  Rotar
                </button>
              </div>
            </ConfigCard>
            <ConfigCard
              icon={History}
              title="Rotación justa"
              subtitle="Historial por sede"
            >
              <div className="grid grid-cols-2 gap-2">
                <MiniMetric value={stats.uniquePairs} label="combinaciones" />
                <MiniMetric value={stats.repeatedPairs} label="repetidas" />
              </div>
              <div className="mt-3 max-h-44 space-y-2 overflow-auto">
                {history.slice(0, 8).map((round, index) => (
                  <div key={round.id} className="rounded-xl bg-black/25 p-2">
                    <b className="text-[10px] text-cyan-200">
                      Ronda anterior {index + 1}
                    </b>
                    <p className="mt-1 line-clamp-2 text-[10px] text-slate-500">
                      {round.groups
                        .map((group) =>
                          group
                            .map((id) => cubeMap.get(id)?.nombre || "Atleta")
                            .join(" + "),
                        )
                        .join(" · ")}
                    </p>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("¿Reiniciar el historial de rotaciones?"))
                    setHistory([]);
                }}
                disabled={!history.length}
                className="secondary-button mt-3 w-full"
              >
                <Trash2 />
                Reiniciar historial
              </button>
            </ConfigCard>
          </div>
        </details>
        <section className="grid min-w-0 gap-5">
          <aside className="h-fit rounded-[1.75rem] border border-white/10 bg-[#0c1018] p-4">
            <button
              type="button"
              onClick={() => setTrayOpen((value) => !value)}
              aria-expanded={trayOpen}
              className="flex w-full items-center justify-between gap-4 text-left"
            >
              <div className="flex items-center gap-3">
                <span className="neon-icon text-violet-200">
                  <UserRound />
                </span>
                <div>
                  <p className="eyebrow text-violet-300">Bandeja</p>
                  <h2 className="text-xl font-black">Atletas disponibles</h2>
                  <small className="text-slate-500">
                    {tray.length} fuera del tablero · toca para{" "}
                    {trayOpen ? "contraer" : "abrir"}
                  </small>
                </div>
              </div>
              <ChevronDown
                className={`h-5 w-5 text-slate-400 transition-transform ${trayOpen ? "rotate-180" : ""}`}
              />
            </button>
            {trayOpen && (
              <div className="mt-4 border-t border-white/[.07] pt-4">
                <div className="flex flex-wrap items-center gap-3">
                  <label className="relative min-w-56 flex-1">
                    <Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input
                      value={search}
                      onChange={(event) => setSearch(event.target.value)}
                      placeholder="Buscar atleta…"
                      className="config-input min-h-11 w-full pl-9"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() => void loadAthletes()}
                    className="neon-icon"
                    aria-label="Recargar atletas"
                  >
                    <RefreshCw className={loading ? "animate-spin" : ""} />
                  </button>
                  <button
                    type="button"
                    onClick={addAllVisible}
                    disabled={!tray.length}
                    className="primary-button"
                  >
                    <UserPlus />
                    Agregar visibles
                  </button>
                  <button
                    type="button"
                    onClick={() => setGuestOpen((value) => !value)}
                    aria-expanded={guestOpen}
                    className="tool-button text-amber-100"
                  >
                    <Plus />
                    {guestOpen ? "Cerrar invitado" : "Agregar invitado"}
                  </button>
                </div>
                {guestOpen && (
                  <form
                    onSubmit={(event) => {
                      event.preventDefault();
                      addGuest();
                    }}
                    className="mt-3 flex flex-col gap-2 rounded-2xl border border-amber-300/20 bg-amber-400/[.06] p-3 sm:flex-row sm:items-end"
                  >
                    <label className="min-w-0 flex-1">
                      <span className="mb-1 block text-[9px] font-black uppercase tracking-wider text-amber-200">
                        Nombre del invitado
                      </span>
                      <input
                        autoFocus
                        value={guestName}
                        onChange={(event) => setGuestName(event.target.value)}
                        maxLength={40}
                        placeholder="Ej. Carlos (primera clase)"
                        className="config-input min-h-11 w-full"
                      />
                    </label>
                    <button
                      type="submit"
                      disabled={!normalizeOrganizerGuestName(guestName)}
                      className="primary-button min-h-11"
                    >
                      <UserPlus />
                      Agregar al tablero
                    </button>
                    <p className="text-[9px] leading-4 text-slate-500 sm:max-w-44">
                      Se guarda sólo en este tablero; no crea una cuenta.
                    </p>
                  </form>
                )}
                <div className="mt-4 grid max-h-[420px] gap-2 overflow-y-auto pr-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {loading ? (
                    <div className="col-span-full grid min-h-32 place-items-center">
                      <Loader2 className="h-7 w-7 animate-spin text-cyan-300" />
                    </div>
                  ) : tray.length ? (
                    tray.map((athlete) => (
                      <button
                        key={athlete.id}
                        type="button"
                        onClick={() => addAthlete(athlete)}
                        className="flex w-full items-center gap-3 rounded-xl border border-white/[.07] bg-black/20 p-3 text-left transition hover:border-cyan-300/25"
                      >
                        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/[.06] text-sm font-black text-cyan-200">
                          {athlete.nombre.slice(0, 2).toUpperCase()}
                        </span>
                        <span className="min-w-0 flex-1">
                          <b className="block truncate text-sm">
                            {athlete.nombre}
                          </b>
                          <small className="block truncate text-slate-500">
                            {athlete.grado || athlete.disciplina || "Atleta"}
                          </small>
                          <small className="mt-1 flex gap-2 text-[9px] text-slate-600">
                            {athlete.peso && <span>{athlete.peso} kg</span>}
                            {athlete.edad !== null && (
                              <span>{athlete.edad} años</span>
                            )}
                          </small>
                        </span>
                        <Plus className="h-4 w-4 text-cyan-300" />
                      </button>
                    ))
                  ) : (
                    <p className="col-span-full rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-slate-500">
                      Todos los atletas visibles ya están en el tablero.
                    </p>
                  )}
                </div>
              </div>
            )}
          </aside>
          <section
            ref={fullscreenRef}
            className="min-w-0 rounded-[1.75rem] border border-white/10 bg-[#080b11] p-3 shadow-2xl sm:p-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[.07] pb-4">
              <div>
                <p className="eyebrow text-cyan-300">Tablero neón</p>
                <p className="mt-1 text-xs text-slate-500">
                  Arrastra · selecciona dos · doble toque para nota · bloquea
                  grupos que no deben cambiar.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                {selected.length === 2 &&
                  !selected.some((id) => groupedIds.has(id)) && (
                    <>
                      <button
                        type="button"
                        onClick={() => createPair("fusion")}
                        className="tool-button text-violet-100"
                      >
                        <Combine />
                        Fusionar
                      </button>
                      <button
                        type="button"
                        onClick={() => createPair("ab")}
                        className="tool-button text-sky-100"
                      >
                        <Split />
                        Pareja A/B
                      </button>
                    </>
                  )}
                {selected.length > 0 && (
                  <div className="flex max-w-[28rem] flex-wrap items-center gap-1 rounded-xl border border-white/10 bg-black/25 p-2">
                    <Palette className="mx-1 h-4 w-4 text-slate-500" />
                    {palette.map((color) => (
                      <button
                        key={color}
                        type="button"
                        onClick={() =>
                          setCubes((items) =>
                            items.map((cube) =>
                              selected.includes(cube.id)
                                ? { ...cube, color }
                                : cube,
                            ),
                          )
                        }
                        aria-pressed={selected.every(
                          (id) => cubeMap.get(id)?.color === color,
                        )}
                        className="h-7 w-7 rounded-lg border border-white/30 transition hover:scale-110 aria-pressed:ring-2 aria-pressed:ring-white"
                        style={{
                          background: colors[color].hex,
                          boxShadow: `0 0 10px ${colors[color].hex}55`,
                        }}
                        aria-label={`Asignar color ${colors[color].label}`}
                      />
                    ))}
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => void toggleFullscreen()}
                  className="tool-button text-cyan-100"
                  aria-pressed={isFullscreen}
                >
                  {isFullscreen ? <Minimize2 /> : <Expand />}
                  {isFullscreen ? "Minimizar" : "Pantalla completa"}
                </button>
                <button
                  type="button"
                  onClick={() => performRotation()}
                  disabled={cubes.length < 2}
                  className="tool-button bg-violet-400/10 text-violet-100"
                >
                  <RefreshCw />
                  Cambiar parejas
                </button>
                <button
                  type="button"
                  onClick={autoArrange}
                  className="tool-button"
                >
                  <Shuffle />
                  Ordenar
                </button>
                <button
                  type="button"
                  onClick={clearBoard}
                  disabled={!cubes.length}
                  className="tool-button text-rose-200"
                >
                  <X />
                  Limpiar
                </button>
              </div>
            </div>
            <BoardClock
              phase={phase}
              currentRound={currentRound}
              totalRounds={settings.totalRounds}
              timeLeft={timeLeft}
              duration={
                phase === "round"
                  ? settings.roundSeconds
                  : phase === "activity"
                    ? settings.activitySeconds
                    : settings.restSeconds
              }
              running={running}
              exercise={activeExercise}
              onToggle={toggleTimer}
              onReset={resetTimer}
            />
            {message && (
              <div
                role="status"
                aria-live="polite"
                className="mt-3 rounded-xl border border-emerald-300/20 bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-100"
              >
                {message}
              </div>
            )}
            <div className="mt-3 flex flex-wrap gap-2">
              {stations.map((station) => (
                <span
                  key={station.id}
                  className="rounded-full border border-white/10 bg-white/[.035] px-3 py-1 text-[9px] font-black text-slate-400"
                >
                  <i
                    className="mr-1.5 inline-block h-2 w-2 rounded-full"
                    style={{ background: station.color }}
                  />
                  {station.name}
                </span>
              ))}
            </div>
            <div className="mt-3 overflow-auto rounded-2xl border border-white/[.07] bg-[#05070c]">
              <div
                ref={boardRef}
                className="relative touch-none overflow-hidden bg-[linear-gradient(rgba(255,255,255,.035)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.035)_1px,transparent_1px),radial-gradient(circle_at_center,rgba(34,211,238,.05),transparent_65%)] [background-size:32px_32px,32px_32px,100%_100%]"
                style={{ width: BOARD_WIDTH, height: BOARD_HEIGHT }}
              >
                {!cubes.length && (
                  <div className="absolute inset-0 grid place-items-center text-center">
                    <div>
                      <LayoutGrid className="mx-auto h-16 w-16 text-white/10" />
                      <h3 className="mt-4 text-xl font-black text-white/35">
                        Tu tablero está vacío
                      </h3>
                    </div>
                  </div>
                )}
                {ungrouped.map((cube) => (
                  <AthleteCube
                    key={cube.id}
                    cube={cube}
                    selected={selected.includes(cube.id)}
                    onSelect={() => toggleSelected(cube.id)}
                    onRemove={() => removeCube(cube.id)}
                    onNote={() => beginNote(cube.id)}
                    onPointerDown={(event) =>
                      startDrag(
                        event,
                        "cube",
                        cube.id,
                        cube.x,
                        cube.y,
                        CUBE_WIDTH,
                      )
                    }
                  />
                ))}
                {groups.map((group) => {
                  const members = group.members
                    .map((id) => cubeMap.get(id))
                    .filter(Boolean) as CubeAthlete[];
                  if (!members.length) return null;
                  return (
                    <AthleteGroupCard
                      key={group.id}
                      group={group}
                      members={members}
                      stations={stations}
                      selected={selected}
                      onSelect={toggleSelected}
                      onNote={beginNote}
                      onSplit={() => splitGroup(group.id)}
                      onSwap={() =>
                        setGroups((items) =>
                          items.map((item) =>
                            item.id === group.id
                              ? {
                                  ...item,
                                  members: [...item.members].reverse(),
                                }
                              : item,
                          ),
                        )
                      }
                      onMode={() =>
                        setGroups((items) =>
                          items.map((item) =>
                            item.id === group.id
                              ? {
                                  ...item,
                                  mode:
                                    item.mode === "fusion" ? "ab" : "fusion",
                                }
                              : item,
                          ),
                        )
                      }
                      onLock={() =>
                        setGroups((items) =>
                          items.map((item) =>
                            item.id === group.id
                              ? { ...item, locked: !item.locked }
                              : item,
                          ),
                        )
                      }
                      onStation={() =>
                        setGroups((items) =>
                          items.map((item) =>
                            item.id === group.id
                              ? {
                                  ...item,
                                  stationId:
                                    stations[
                                      (stations.findIndex(
                                        (station) =>
                                          station.id === item.stationId,
                                      ) +
                                        1 +
                                        stations.length) %
                                        stations.length
                                    ]?.id || "",
                                }
                              : item,
                          ),
                        )
                      }
                      onPointerDown={(event) =>
                        startDrag(
                          event,
                          "group",
                          group.id,
                          group.x,
                          group.y,
                          groupWidth(group.members.length),
                        )
                      }
                    />
                  );
                })}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-[10px] text-slate-500">
              <span>
                Guardado automático por sede ·{" "}
                {groups.filter((group) => group.locked).length} grupo(s)
                bloqueados
              </span>
              <span>{selected.length}/2 seleccionados para unir</span>
            </div>
          </section>
        </section>
      </div>
      {editing && (
        <NoteDialog
          name={cubeMap.get(editing)?.nombre || "Atleta"}
          value={noteDraft}
          onChange={setNoteDraft}
          onSave={saveNote}
          onClose={() => setEditing(null)}
        />
      )}{" "}
      {flash && (
        <div
          aria-hidden="true"
          className={`organizer-flash pointer-events-none fixed inset-0 z-[250] ${flash === "green" ? "bg-emerald-400" : flash === "red" ? "bg-rose-500" : flash === "yellow" ? "bg-amber-300" : "bg-sky-500"}`}
        />
      )}
      <style jsx global>{`
        @keyframes organizerScreenFlash {
          0%,
          100% {
            opacity: 0;
          }
          50% {
            opacity: 0.52;
          }
        }
        .organizer-flash {
          animation: organizerScreenFlash 0.42s ease-in-out infinite;
        }
        [data-screen-flash] {
          position: relative;
        }
        [data-screen-flash]::after {
          content: "";
          pointer-events: none;
          position: fixed;
          inset: 0;
          z-index: 250;
          animation: organizerScreenFlash 0.42s ease-in-out infinite;
        }
        [data-screen-flash="green"]::after {
          background: #34d399;
        }
        [data-screen-flash="red"]::after {
          background: #f43f5e;
        }
        [data-screen-flash="blue"]::after {
          background: #0ea5e9;
        }
        [data-screen-flash="yellow"]::after {
          background: #fbbf24;
        }
        .eyebrow {
          font-size: 0.625rem;
          font-weight: 900;
          text-transform: uppercase;
          letter-spacing: 0.2em;
        }
        .eyebrow svg {
          height: 0.9rem;
          width: 0.9rem;
        }
        .hero-button,
        .primary-button,
        .secondary-button,
        .tool-button {
          display: inline-flex;
          min-height: 2.65rem;
          align-items: center;
          justify-content: center;
          gap: 0.45rem;
          border-radius: 0.8rem;
          font-size: 0.72rem;
          font-weight: 900;
          transition: 0.2s;
        }
        .hero-button,
        .tool-button,
        .secondary-button {
          border: 1px solid rgba(255, 255, 255, 0.1);
          background: rgba(255, 255, 255, 0.045);
          padding: 0 0.8rem;
        }
        .primary-button {
          background: #67e8f9;
          color: #082f49;
          padding: 0 1rem;
        }
        .secondary-button {
          min-height: 2.4rem;
        }
        .hero-button svg,
        .primary-button svg,
        .secondary-button svg,
        .tool-button svg,
        .neon-icon svg,
        .icon-button svg {
          height: 0.95rem;
          width: 0.95rem;
        }
        .neon-icon,
        .icon-button {
          display: grid;
          height: 2.5rem;
          width: 2.5rem;
          place-items: center;
          border-radius: 0.75rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          background: rgba(255, 255, 255, 0.05);
        }
        .icon-button {
          height: 2.2rem;
          width: 2.2rem;
        }
        .config-input {
          min-height: 2.55rem;
          border-radius: 0.75rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          background: rgba(0, 0, 0, 0.28);
          padding: 0 0.7rem;
          font-size: 0.72rem;
          color: white;
          outline: none;
        }
        .group-action {
          display: grid;
          height: 1.9rem;
          width: 2.25rem;
          place-items: center;
          border-right: 1px solid rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.68);
        }
        .group-action:last-child {
          border-right: 0;
        }
        .group-action svg {
          height: 0.78rem;
          width: 0.78rem;
        }
        :fullscreen {
          background: #05070b;
          padding: 1rem;
          overflow: auto;
        }
      `}</style>
    </main>
  );
}

function BoardClock({
  phase,
  currentRound,
  totalRounds,
  timeLeft,
  duration,
  running,
  exercise,
  onToggle,
  onReset,
}: {
  phase: TimerPhase;
  currentRound: number;
  totalRounds: number;
  timeLeft: number;
  duration: number;
  running: boolean;
  exercise: OrganizerExercise | null;
  onToggle: () => void;
  onReset: () => void;
}) {
  const activity = phase === "activity" || Boolean(exercise),
    resting = phase === "rest" && !exercise,
    displayTime =
      phase === "rest" && exercise
        ? Math.max(0, timeLeft - (duration - exercise.seconds))
        : timeLeft,
    progressDuration = activity ? exercise?.seconds || duration : duration,
    urgent = displayTime <= 5;
  return (
    <section
      className={`mt-3 overflow-hidden rounded-2xl border p-4 transition sm:p-5 ${activity ? "border-amber-300/40 bg-[radial-gradient(circle_at_center,rgba(251,191,36,.18),transparent_70%),rgba(245,158,11,.08)]" : resting ? "border-sky-300/30 bg-sky-500/10" : "border-emerald-300/20 bg-emerald-500/[.07]"}`}
    >
      <div className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] sm:items-center">
        <div className="min-w-0 text-center sm:text-left">
          <p
            className={`eyebrow ${activity ? "text-amber-300" : resting ? "text-sky-300" : "text-emerald-300"}`}
          >
            {activity
              ? "Actividad aleatoria"
              : resting
                ? "Descanso"
                : "Round en curso"}
          </p>
          <b className="mt-1 block text-sm sm:text-base">
            {activity
              ? `Antes del round ${phase === "activity" && currentRound === 1 ? currentRound : Math.min(totalRounds, currentRound + 1)}`
              : resting
                ? `Antes del round ${Math.min(totalRounds, currentRound + 1)}`
                : `Round ${currentRound} de ${totalRounds}`}
          </b>
        </div>
        <div className="min-w-[190px] text-center sm:min-w-[250px] lg:min-w-[340px]">
          {activity && exercise && (
            <strong className="mb-1 block text-xl font-black uppercase tracking-tight text-amber-100 sm:text-2xl lg:text-3xl">
              {exercise.label}
            </strong>
          )}
          <strong
            className={`block font-mono text-5xl font-black leading-none tracking-[-.055em] sm:text-7xl lg:text-8xl ${urgent ? "animate-pulse text-rose-300" : activity ? "text-amber-200" : resting ? "text-sky-200" : "text-white"}`}
          >
            {formatClock(displayTime)}
          </strong>
          {activity && exercise && (
            <span className="mt-2 inline-flex rounded-full border border-amber-200/30 bg-amber-300/15 px-4 py-1 text-xs font-black text-amber-100 sm:text-sm">
              {repetitionLabel(exercise.repetitions, true)}
            </span>
          )}
        </div>
        <div className="flex flex-wrap justify-center gap-2 sm:justify-end">
          <button
            type="button"
            onClick={onToggle}
            className={`tool-button ${running ? "text-amber-200" : resting ? "text-sky-100" : "text-emerald-100"}`}
          >
            {running ? <CirclePause /> : <CirclePlay />}
            {running ? "Pausar" : "Continuar"}
          </button>
          <button
            type="button"
            onClick={onReset}
            className="tool-button"
            title="Reiniciar temporizador"
          >
            <TimerReset />
            Reiniciar
          </button>
        </div>
      </div>
      <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-black/30">
        <div
          className={`h-full rounded-full transition-all duration-700 ${urgent ? "bg-rose-400" : activity ? "bg-amber-300" : resting ? "bg-sky-400" : "bg-emerald-400"}`}
          style={{
            width: `${Math.max(0, Math.min(100, (displayTime / Math.max(1, progressDuration)) * 100))}%`,
          }}
        />
      </div>
      <div className="mt-2 flex justify-between gap-3 text-[9px] font-bold uppercase tracking-wider text-slate-500">
        <span>{running ? "Cronómetro activo" : "Cronómetro pausado"}</span>
        <span>
          {activity
            ? "Amarillo: actividad · pitidos de acción"
            : resting
              ? "Azul: recuperación"
              : "Verde: inicio · Rojo: final"}
        </span>
      </div>
    </section>
  );
}
function AthleteCube({
  cube,
  selected,
  onSelect,
  onRemove,
  onNote,
  onPointerDown,
}: {
  cube: CubeAthlete;
  selected: boolean;
  onSelect: () => void;
  onRemove: () => void;
  onNote: () => void;
  onPointerDown: (event: React.PointerEvent) => void;
}) {
  const style = colors[cube.color],
    lastTap = useRef(0),
    tap = () => {
      const now = Date.now();
      if (now - lastTap.current < 420) {
        lastTap.current = 0;
        onNote();
      } else {
        lastTap.current = now;
        onSelect();
      }
    };
  return (
    <article
      onPointerDown={onPointerDown}
      onClick={tap}
      className={`absolute flex h-[122px] w-[142px] cursor-grab select-none flex-col overflow-hidden rounded-2xl border-2 bg-gradient-to-br p-3 will-change-transform ${style.border} ${style.surface} ${style.glow} ${selected ? "ring-2 ring-white ring-offset-2 ring-offset-[#05070c]" : ""}`}
      style={{ transform: `translate3d(${cube.x}px,${cube.y}px,0)` }}
    >
      <div className="flex items-start justify-between">
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-black/15 text-[10px] font-black text-slate-950">
          {cube.nombre.slice(0, 2).toUpperCase()}
        </span>
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            onRemove();
          }}
          className="grid h-6 w-6 place-items-center rounded-lg bg-black/15 text-slate-950/55"
        >
          <X className="h-3 w-3" />
        </button>
      </div>
      <div className="mt-auto min-w-0">
        <b className="block truncate text-sm text-slate-950">{cube.nombre}</b>
        <span className={`block truncate text-[10px] font-black ${style.text}`}>
          {cube.note || cube.grado || cube.disciplina || "Doble toque: nota"}
        </span>
      </div>
    </article>
  );
}
function AthleteGroupCard({
  group,
  members,
  stations,
  selected,
  onSelect,
  onNote,
  onSplit,
  onSwap,
  onMode,
  onLock,
  onStation,
  onPointerDown,
}: {
  group: AthleteGroup;
  members: CubeAthlete[];
  stations: Station[];
  selected: string[];
  onSelect: (id: string) => void;
  onNote: (id: string) => void;
  onSplit: () => void;
  onSwap: () => void;
  onMode: () => void;
  onLock: () => void;
  onStation: () => void;
  onPointerDown: (event: React.PointerEvent) => void;
}) {
  const fused = group.mode === "fusion",
    width = groupWidth(members.length),
    station = stations.find((item) => item.id === group.stationId),
    solo = members.length === 1,
    memberColors = members.map((member) => colors[member.color].hex),
    outline = `linear-gradient(90deg,${memberColors.map((color, index) => `${color} ${(index / Math.max(1, memberColors.length)) * 100}% ${((index + 1) / memberColors.length) * 100}%`).join(",")})`,
    neon = memberColors
      .map((color, index) => `0 0 ${18 + index * 6}px ${color}88`)
      .join(",");
  return (
    <article
      className="absolute h-[136px] select-none rounded-[1.4rem] border-2 border-white/70 p-1 will-change-transform"
      style={{
        width,
        transform: `translate3d(${group.x}px,${group.y}px,0)`,
        background: outline,
        boxShadow: neon,
      }}
    >
      <button
        type="button"
        data-drag-handle
        onPointerDown={onPointerDown}
        className="absolute -top-3 left-1/2 z-20 grid h-8 w-14 -translate-x-1/2 cursor-grab place-items-center rounded-full border border-white/20 bg-[#10141d]"
      >
        <Grip className="h-4 w-4" />
      </button>
      {group.locked && (
        <span className="absolute -right-2 -top-2 z-30 grid h-7 w-7 place-items-center rounded-full bg-amber-300 text-amber-950">
          <Lock className="h-3.5 w-3.5" />
        </span>
      )}
      {group.warnings.length > 0 && (
        <span
          title={group.warnings.join(" · ")}
          className="absolute -left-2 -top-2 z-30 grid h-7 w-7 place-items-center rounded-full bg-rose-400 text-rose-950"
        >
          <AlertTriangle className="h-3.5 w-3.5" />
        </span>
      )}
      <div
        className={`grid h-full overflow-hidden rounded-[1.15rem] ${fused ? "" : "gap-1 bg-[#080b11]"}`}
        style={{
          gridTemplateColumns: `repeat(${members.length},minmax(0,1fr))`,
        }}
      >
        {members.map((member, index) => (
          <GroupHalf
            key={member.id}
            cube={member}
            side={
              !fused && members.length === 2
                ? index === 0
                  ? "A"
                  : "B"
                : undefined
            }
            selected={selected.includes(member.id)}
            onSelect={() => onSelect(member.id)}
            onNote={() => onNote(member.id)}
            assignment={solo ? group.assignment : undefined}
          />
        ))}
      </div>
      {station && (
        <span className="absolute bottom-1 left-1/2 z-20 -translate-x-1/2 rounded-full bg-[#0b1018]/95 px-2 py-1 text-[8px] font-black">
          <i
            className="mr-1 inline-block h-1.5 w-1.5 rounded-full"
            style={{ background: station.color }}
          />
          {station.name}
        </span>
      )}
      <div className="absolute -bottom-3 left-1/2 z-30 flex -translate-x-1/2 overflow-hidden rounded-full border border-white/15 bg-[#10141d]">
        {members.length === 2 && (
          <button type="button" onClick={onSwap} className="group-action">
            <RefreshCw />
          </button>
        )}
        {members.length > 1 && (
          <button type="button" onClick={onMode} className="group-action">
            {fused ? <Split /> : <Combine />}
          </button>
        )}
        <button
          type="button"
          onClick={onLock}
          className={`group-action ${group.locked ? "text-amber-300" : ""}`}
        >
          {group.locked ? <Unlock /> : <Lock />}
        </button>
        <button type="button" onClick={onStation} className="group-action">
          <MapPin />
        </button>
        <button
          type="button"
          onClick={onSplit}
          className="group-action text-rose-300"
        >
          <Unlink />
        </button>
      </div>
    </article>
  );
}
function GroupHalf({
  cube,
  side,
  selected,
  onSelect,
  onNote,
  assignment,
}: {
  cube: CubeAthlete;
  side?: "A" | "B";
  selected: boolean;
  onSelect: () => void;
  onNote: () => void;
  assignment?: "active-rest" | "floater";
}) {
  const lastTap = useRef(0),
    style = colors[cube.color],
    tap = () => {
      const now = Date.now();
      if (now - lastTap.current < 420) {
        lastTap.current = 0;
        onNote();
      } else {
        lastTap.current = now;
        onSelect();
      }
    };
  return (
    <button
      type="button"
      onClick={tap}
      aria-label={`${cube.nombre} · color ${style.label}${side ? ` · lado ${side}` : ""}`}
      className={`relative min-w-0 border-r border-black/20 bg-gradient-to-br p-3 text-left text-slate-950 last:border-r-0 ${style.surface} ${selected ? "ring-2 ring-inset ring-white" : ""}`}
    >
      <div className="flex items-center justify-between gap-1">
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-black/15 text-[10px] font-black">
          {cube.nombre.slice(0, 2).toUpperCase()}
        </span>
        {side ? (
          <b className="rounded-lg bg-black/20 px-2 py-1 text-[10px] font-black text-white">
            LADO {side}
          </b>
        ) : (
          <i
            className="h-2.5 w-2.5 rounded-full border border-white/70"
            style={{
              background: style.hex,
              boxShadow: `0 0 10px ${style.hex}`,
            }}
          />
        )}
      </div>
      <b className="mt-3 block truncate text-sm">{cube.nombre}</b>
      <span className="block truncate text-[10px] font-black text-slate-950/80">
        {assignment === "active-rest"
          ? "DESCANSO ACTIVO"
          : assignment === "floater"
            ? "COMODÍN DE ROTACIÓN"
            : cube.note || cube.grado || cube.disciplina || "Doble toque: nota"}
      </span>
    </button>
  );
}
function ConfigCard({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: typeof Link2;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-white/[.07] bg-black/20 p-4">
      <div className="mb-4 flex items-center gap-3">
        <span className="neon-icon">
          <Icon />
        </span>
        <span>
          <b className="block text-sm">{title}</b>
          <small className="text-[10px] text-slate-500">{subtitle}</small>
        </span>
      </div>
      {children}
    </section>
  );
}
function RuleRow({
  rule,
  names,
  onChange,
  onDelete,
}: {
  rule: OrganizerRule;
  names: Map<string, CubeAthlete>;
  onChange: (patch: Partial<OrganizerRule>) => void;
  onDelete: () => void;
}) {
  return (
    <div className="rounded-xl border border-white/[.07] bg-white/[.035] p-2">
      <div className="flex items-center gap-2">
        <span
          className={`h-2 w-2 rounded-full ${rule.kind === "avoid" ? "bg-rose-400" : rule.kind === "keep" ? "bg-amber-300" : "bg-violet-400"}`}
        />
        <span className="min-w-0 flex-1 truncate text-[10px] font-bold">
          {names.get(rule.a)?.nombre || "Atleta"} +{" "}
          {names.get(rule.b)?.nombre || "Atleta"}
        </span>
        <button type="button" onClick={onDelete}>
          <Trash2 className="h-3.5 w-3.5 text-slate-500" />
        </button>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <select
          className="config-input min-h-8 flex-1"
          value={rule.kind}
          onChange={(event) =>
            onChange({ kind: event.target.value as OrganizerRuleKind })
          }
        >
          {Object.entries(ruleKindLabels).map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
        {rule.kind === "prefer" && (
          <>
            <label className="text-[9px] text-slate-500">Máx.</label>
            <select
              className="config-input min-h-8 w-14"
              value={rule.maxConsecutive}
              onChange={(event) =>
                onChange({ maxConsecutive: Number(event.target.value) })
              }
            >
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </>
        )}
      </div>
      {rule.kind === "prefer" && (
        <label className="mt-2 flex items-center gap-2 text-[9px] text-slate-500">
          <span>Probabilidad</span>
          <input
            type="range"
            min="20"
            max="100"
            step="10"
            value={rule.strength}
            onChange={(event) =>
              onChange({ strength: Number(event.target.value) })
            }
            className="min-w-0 flex-1 accent-violet-400"
          />
          <b>{rule.strength}%</b>
        </label>
      )}
    </div>
  );
}
function SelectMini({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Record<string, string>;
}) {
  return (
    <label className="min-w-0">
      <span className="mb-1 block text-[9px] font-black uppercase text-slate-500">
        {label}
      </span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="config-input w-full"
      >
        {Object.entries(options).map(([key, text]) => (
          <option key={key} value={key}>
            {text}
          </option>
        ))}
      </select>
    </label>
  );
}
function PlacementSwitch({
  value,
  onChange,
}: {
  value: OrganizerActivityPlacement;
  onChange: (value: OrganizerActivityPlacement) => void;
}) {
  const options: Array<[OrganizerActivityPlacement, string]> = [
    ["before-rest", "Antes"],
    ["during-rest", "Durante"],
    ["after-rest", "Después"],
  ];
  return (
    <div className="min-w-0 sm:col-span-2 lg:col-span-1">
      <span className="mb-1 block text-[9px] font-black uppercase text-slate-500">
        Momento
      </span>
      <div
        role="radiogroup"
        aria-label="Momento de la actividad"
        className="grid min-h-[2.55rem] grid-cols-3 overflow-hidden rounded-xl border border-white/10 bg-black/30 p-1"
      >
        {options.map(([option, label]) => (
          <button
            key={option}
            type="button"
            role="radio"
            aria-checked={value === option}
            onClick={() => onChange(option)}
            className={`rounded-lg px-1 text-[9px] font-black transition ${value === option ? "bg-amber-300 text-amber-950 shadow-[0_0_16px_rgba(251,191,36,.22)]" : "text-slate-500 hover:text-slate-200"}`}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}
function NumberMini({
  label,
  value,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  suffix: string;
  onChange: (value: number) => void;
}) {
  return (
    <label>
      <span className="mb-1 block text-[9px] font-black uppercase text-slate-500">
        {label}
      </span>
      <span className="flex items-center rounded-xl border border-white/10 bg-black/30">
        <input
          type="number"
          min="1"
          value={value}
          onChange={(event) =>
            onChange(Math.max(1, Number(event.target.value)))
          }
          className="min-h-10 min-w-0 flex-1 bg-transparent px-2 text-sm font-bold outline-none"
        />
        <small className="pr-2 text-[9px] text-slate-500">{suffix}</small>
      </span>
    </label>
  );
}
function Switch({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      role="switch"
      aria-checked={checked}
      className="mt-2 inline-flex min-h-9 items-center gap-2 rounded-xl border border-white/10 bg-white/[.035] px-3 text-[10px] font-bold"
    >
      <span
        className={`relative h-5 w-9 rounded-full ${checked ? "bg-emerald-400" : "bg-slate-700"}`}
      >
        <i
          className={`absolute top-1 h-3 w-3 rounded-full bg-white transition ${checked ? "left-5" : "left-1"}`}
        />
      </span>
      {label}
    </button>
  );
}
function MiniMetric({
  value,
  label,
}: {
  value: number | string;
  label: string;
}) {
  return (
    <span className="rounded-xl border border-white/[.07] bg-black/20 p-2">
      <b className="block text-sm text-white">{value}</b>
      <small className="text-[8px] font-black uppercase text-slate-500">
        {label}
      </small>
    </span>
  );
}
function Status({
  icon: Icon,
  value,
  label,
}: {
  icon: typeof UserRound;
  value: number;
  label: string;
}) {
  return (
    <span className="flex min-h-12 items-center gap-3 rounded-2xl border border-white/10 bg-black/20 px-4">
      <Icon className="h-4 w-4 text-cyan-300" />
      <span>
        <b className="block leading-none">{value}</b>
        <small className="text-[9px] font-black uppercase text-slate-500">
          {label}
        </small>
      </span>
    </span>
  );
}
function NoteDialog({
  name,
  value,
  onChange,
  onSave,
  onClose,
}: {
  name: string;
  value: string;
  onChange: (value: string) => void;
  onSave: () => void;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-[120] grid place-items-center bg-black/75 p-4 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
    >
      <form
        onSubmit={(event) => {
          event.preventDefault();
          onSave();
        }}
        className="w-full max-w-md rounded-[1.75rem] border border-cyan-300/20 bg-[#0c111a] p-5"
      >
        <div className="flex justify-between">
          <div>
            <p className="eyebrow text-cyan-300">Nota del cubo</p>
            <h2 className="text-xl font-black">{name}</h2>
          </div>
          <button type="button" onClick={onClose} className="neon-icon">
            <X />
          </button>
        </div>
        <input
          autoFocus
          value={value}
          onChange={(event) => onChange(event.target.value)}
          maxLength={40}
          placeholder="Ej. 1, capitán…"
          className="config-input mt-5 min-h-12 w-full"
        />
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button type="button" onClick={onClose} className="tool-button">
            Cancelar
          </button>
          <button type="submit" className="primary-button">
            Guardar nota
          </button>
        </div>
      </form>
    </div>
  );
}
