"use client";
/* eslint-disable react-hooks/exhaustive-deps -- goals are reloaded only when the selected athlete changes */
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  query,
  runTransaction,
  updateDoc,
  where,
} from "firebase/firestore";
import {
  Activity,
  Calculator,
  ChevronDown,
  ClipboardCheck,
  Droplets,
  Dumbbell,
  History,
  Ruler,
  Save,
  ShieldCheck,
  Target,
} from "lucide-react";
import { useFirestore, useUser } from "@/firebase";
import {
  AdminAthletePicker,
  type ProgressAthlete,
} from "@/components/progress/admin-athlete-picker";
import { PhysicalHistory } from "@/components/progress/physical-history";
import { PhysicalTestLab } from "@/components/progress/physical-test-lab";
import { PhysicalAnalysisCenter } from "@/components/progress/physical-analysis-center";
import { HydrationLab } from "@/components/progress/hydration-lab";
import { BodyCompositionWheel } from "@/components/progress/body-composition-wheel";
import {
  assessSkinfolds,
  bmiZone,
  calculateBmi,
  calculateBodyComposition,
  calculateWaistHeight,
  calculateWaistHip,
  estimateAdultBodyFat,
  estimateNavetteVo2,
  healthyBodyFatRange,
  measurementQuality,
  optionalNumber,
  optionalSignedNumber,
  scientificHealthIndicators,
  SKINFOLD_SITES,
  vo2Reference,
  type PhysicalAssessment,
  type PhysicalGoals,
  type SkinfoldAssessment,
  type SkinfoldReadings,
} from "@/lib/athlete-progress";
import {
  physicalDataErrorMessage,
  validatePhysicalData,
} from "@/lib/physical-data-validation";
import type { HydrationSession } from "@/lib/hydration";
import {
  buildFitnessScoreReport,
  fitnessScoreSnapshot,
  latestFitnessValues,
  type FitnessExerciseKey,
} from "@/lib/fitness-scoring";
import { latestPhysicalSnapshot, latestProfile } from "@/lib/physical-records";
type Section = "composition" | "tests" | "history" | "goals";
type Form = Record<string, string>;
type HealthAthlete = ProgressAthlete & {
  metasFisicas?: PhysicalGoals;
  historialHidratacion?: HydrationSession[];
};
const measures = [
  ["cuelloCm", "Cuello"],
  ["hombrosCm", "Hombros"],
  ["pechoCm", "Pecho"],
  ["brazoCm", "Brazo"],
  ["antebrazoCm", "Antebrazo"],
  ["cinturaCm", "Cintura"],
  ["abdomenCm", "Abdomen"],
  ["caderaCm", "Cadera"],
  ["gluteoCm", "Glúteo"],
  ["musloCm", "Muslo"],
  ["pantorrillaCm", "Pantorrilla"],
] as const;
const numericKeys = [
  "pesoKg",
  "estaturaCm",
  "grasaPorcentaje",
  ...measures.map((x) => x[0]),
  "lagartijas",
  "sentadillas",
  "abdominales",
  "burpees",
  "suicidios",
  "planchaSegundos",
  "saltoHorizontalCm",
  "saltoVerticalCm",
  "sprint10mSegundos",
  "agilidad505Segundos",
  "sitAndReachCm",
  "equilibrioSegundos",
  "fuerzaAgarreKg",
  "navetteNivel",
  "navetteIdas",
  "ayunoHoras",
  "ejercicioPrevioHoras",
  "dolorMenstrual",
  "fatigaMenstrual",
  "retencionLiquidos",
  "sangradoMenstrual",
  "suenoCalidad",
  "esfuerzoPercibido",
] as string[];
const testKeys = [
  "lagartijas",
  "sentadillas",
  "abdominales",
  "burpees",
  "suicidios",
  "planchaSegundos",
  "saltoHorizontalCm",
  "saltoVerticalCm",
  "sprint10mSegundos",
  "agilidad505Segundos",
  "sitAndReachCm",
  "equilibrioSegundos",
  "fuerzaAgarreKg",
  "navetteNivel",
  "navetteIdas",
] as const;
const integerTestKeys = new Set<string>([
  "lagartijas",
  "sentadillas",
  "abdominales",
  "burpees",
  "suicidios",
  "navetteIdas",
]);
const today = () => new Date().toISOString().slice(0, 10);
const physicalNumber = (key: string, value: string) =>
  key === "sitAndReachCm" ? optionalSignedNumber(value) : optionalNumber(value);
const freshForm = (profile?: ReturnType<typeof latestProfile>): Form => ({
  fecha: today(),
  sexoCalculo: profile?.sexoCalculo || "masculino",
  pesoKg: profile?.pesoKg?.toString() || "",
  estaturaCm: profile?.estaturaCm?.toString() || "",
  edad: profile?.edad?.toString() || "",
  hidratacion: "habitual",
  contextoMenstrual: "false",
});
export default function AdminPhysicalPage() {
  const db = useFirestore(),
    { user } = useUser(),
    [site, setSite] = useState("MMA"),
    [siteReady, setSiteReady] = useState(false),
    [athletes, setAthletes] = useState<HealthAthlete[]>([]),
    [selectedId, setSelectedId] = useState(""),
    [workspace, setWorkspace] = useState<
      "choose" | "analyze" | "evaluate" | "hydration"
    >("choose"),
    [section, setSection] = useState<Section>("composition"),
    [autoFat, setAutoFat] = useState(false),
    [saving, setSaving] = useState(false),
    [message, setMessage] = useState(""),
    [form, setForm] = useState<Form>(() => freshForm()),
    [goalForm, setGoalForm] = useState<Form>({ enfoque: "salud" });
  useEffect(() => {
    setSite(localStorage.getItem("userSede") || "MMA");
    setSiteReady(true);
  }, []);
  const load = useCallback(async () => {
    if (!db || !siteReady) return;
    const snap = await getDocs(
        query(collection(db, "Alumnos"), where("sede", "==", site)),
      ),
      list = snap.docs
        .filter((d) => d.data().activo !== false)
        .map((d) => ({
          id: d.id,
          nombre: String(d.data().nombre || "Atleta"),
          disciplina: String(d.data().disciplina || ""),
          historialFisico: Array.isArray(d.data().historialFisico)
            ? d.data().historialFisico
            : [],
          historialHidratacion: Array.isArray(d.data().historialHidratacion)
            ? d.data().historialHidratacion
            : [],
          metasFisicas: (d.data().metasFisicas || {}) as PhysicalGoals,
        }))
        .sort((a, b) => a.nombre.localeCompare(b.nombre, "es"));
    setAthletes(list);
    setSelectedId((v) =>
      list.some((a) => a.id === v) ? v : list[0]?.id || "",
    );
  }, [db, site, siteReady]);
  useEffect(() => {
    void load();
  }, [load]);
  const selected = athletes.find((a) => a.id === selectedId),
    records = useMemo(
      () => (selected?.historialFisico || []) as PhysicalAssessment[],
      [selected],
    ),
    currentSnapshot = useMemo(() => latestPhysicalSnapshot(records), [records]),
    set = (key: string, value: string) => {
      setForm((v) => ({ ...v, [key]: value }));
      setMessage("");
    };
  const weight = optionalNumber(form.pesoKg || ""),
    height = optionalNumber(form.estaturaCm || ""),
    waist = optionalNumber(form.cinturaCm || ""),
    hip = optionalNumber(form.caderaCm || ""),
    age = optionalNumber(form.edad || ""),
    sex = form.sexoCalculo as "masculino" | "femenino",
    bmi = calculateBmi(weight || 0, height || 0),
    waistHeight = calculateWaistHeight(waist, height),
    waistHip = calculateWaistHip(waist, hip),
    estimatedFat = estimateAdultBodyFat(bmi, age, sex),
    activeFat = autoFat
      ? estimatedFat
      : optionalNumber(form.grasaPorcentaje || ""),
    body = calculateBodyComposition(weight, height, activeFat),
    vo2 = estimateNavetteVo2(optionalNumber(form.navetteNivel || ""), age),
    fatRange = healthyBodyFatRange(age, sex),
    vo2Goal = vo2Reference(age, sex),
    quality = measurementQuality({
      hora: form.horaMedicion,
      ayunoHoras: optionalNumber(form.ayunoHoras || ""),
      exerciseHours: optionalNumber(form.ejercicioPrevioHoras || ""),
      hydration: form.hidratacion,
      fluidRetention: optionalNumber(form.retencionLiquidos || ""),
    }),
    previewIndicators = scientificHealthIndicators({
      id: "preview",
      fecha: form.fecha,
      pesoKg: weight || 0,
      estaturaCm: height || 0,
      imc: bmi,
      edad: age,
      sexoCalculo: sex,
      cinturaEstatura: waistHeight,
      grasaPorcentaje: activeFat,
      vo2MaxEstimado: vo2,
      calidadMedicion: quality,
    }),
    bmiStatus = bmiZone(bmi, age);
  const minuteValues = useMemo(
      () =>
        Object.fromEntries(
          ["lagartijas", "sentadillas", "abdominales", "burpees"].map((key) => [
            key,
            optionalNumber(form[key] || ""),
          ]),
        ) as Partial<Record<FitnessExerciseKey, number>>,
      [form],
    ),
    fitnessReport = useMemo(
      () =>
        buildFitnessScoreReport({
          values: minuteValues,
          age,
          sex,
          weightKg: weight,
          history: records,
          cohort: athletes,
          athleteId: selectedId,
        }),
      [minuteValues, age, sex, weight, records, athletes, selectedId],
    );
  const skinfoldReadings = useMemo(
      () =>
        Object.fromEntries(
          SKINFOLD_SITES.map((site) => [
            site.key,
            [1, 2, 3]
              .map((attempt) =>
                optionalNumber(form[`skinfold_${site.key}_${attempt}`] || ""),
              )
              .filter(
                (value): value is number => value !== undefined && value > 0,
              ),
          ]),
        ) as SkinfoldReadings,
      [form],
    ),
    skinfolds = assessSkinfolds(skinfoldReadings);
  useEffect(() => {
    const g = selected?.metasFisicas;
    setGoalForm({
      enfoque: g?.enfoque || "salud",
      fechaObjetivo: g?.fechaObjetivo || "",
      pesoKg: g?.pesoKg?.toString() || "",
      grasaPorcentaje: g?.grasaPorcentaje?.toString() || "",
      cinturaEstatura: g?.cinturaEstatura?.toString() || "",
      vo2Max: g?.vo2Max?.toString() || "",
      lagartijas: g?.lagartijas?.toString() || "",
      sentadillas: g?.sentadillas?.toString() || "",
      abdominales: g?.abdominales?.toString() || "",
      planchaSegundos: g?.planchaSegundos?.toString() || "",
      saltoHorizontalCm: g?.saltoHorizontalCm?.toString() || "",
      sprint10mSegundos: g?.sprint10mSegundos?.toString() || "",
      notas: g?.notas || "",
    });
  }, [selectedId]);
  useEffect(() => {
    const profile = latestProfile(
      (selected?.historialFisico || []) as PhysicalAssessment[],
    );
    setForm(freshForm(profile));
    setAutoFat(false);
    setMessage("");
  }, [selectedId]);
  async function save() {
    if (
      !db ||
      !selected ||
      !bmi ||
      !form.fecha ||
      !age ||
      (autoFat && !estimatedFat)
    ) {
      setMessage(
        "Completa atleta, fecha, edad, peso y estatura antes de guardar.",
      );
      return;
    }
    const values = Object.fromEntries(
      numericKeys.map((key) => [key, physicalNumber(key, form[key] || "")]),
    ) as Record<string, number | undefined>;
    values.edad = age;
    values.pesoKg = weight;
    values.estaturaCm = height;
    values.grasaPorcentaje = activeFat;
    const dataIssues = validatePhysicalData(values),
      dataError = physicalDataErrorMessage(dataIssues);
    if (dataError) {
      setMessage(`Revisa los datos: ${dataError}`);
      return;
    }
    setSaving(true);
    const record: Record<string, unknown> = {
      id: crypto.randomUUID(),
      fecha: form.fecha,
      schemaVersion: 2,
      protocolVersion: "salud-composicion-v2",
      tipoRegistro: "salud",
      imc: bmi,
      edad: age,
      sexoCalculo: sex,
      registradoPor: user?.email || "personal",
      grasaAutomatica: autoFat,
      calidadMedicion: quality,
      contextoMenstrual: form.contextoMenstrual === "true",
      anticoncepcionHormonal: form.anticoncepcionHormonal === "true",
      cicloIrregular: form.cicloIrregular === "true",
    };
    for (const key of numericKeys) {
      const value = physicalNumber(key, form[key] || "");
      if (value !== undefined && key !== "grasaPorcentaje") record[key] = value;
    }
    const qualityWarnings = dataIssues
      .filter((issue) => issue.level === "warning")
      .map((issue) => issue.message);
    if (qualityWarnings.length) record.advertenciasCalidad = qualityWarnings;
    if (waistHeight !== undefined) record.cinturaEstatura = waistHeight;
    if (waistHip !== undefined) record.cinturaCadera = waistHip;
    if (activeFat !== undefined) record.grasaPorcentaje = activeFat;
    if (body.fatMass !== undefined) record.masaGrasaKg = body.fatMass;
    if (body.leanMass !== undefined) record.masaLibreGrasaKg = body.leanMass;
    if (body.ffmi !== undefined) record.ffmi = body.ffmi;
    if (vo2 !== undefined) {
      record.vo2MaxEstimado = vo2;
      record.navetteVelocidadFinal =
        8 + 0.5 * (optionalNumber(form.navetteNivel || "") || 0);
    }
    if (Object.keys(skinfolds.values).length) {
      record.plieguesMm = skinfolds.values;
      record.plieguesLecturasMm = skinfolds.readings;
      record.calidadPliegues = skinfolds.quality;
      record.protocoloPliegues = "ISAK-8";
      if (skinfolds.sum !== undefined) record.sumaPlieguesMm = skinfolds.sum;
      if (form.plicometro?.trim()) record.plicometro = form.plicometro.trim();
    }
    for (const key of ["horaMedicion", "hidratacion", "faseMenstrual"])
      if (form[key]) record[key] = form[key];
    record.metodoGrasa = autoFat
      ? "Estimación Deurenberg (IMC, edad y sexo)"
      : form.metodoGrasa?.trim() || "No especificado";
    if (form.notas) record.notas = form.notas.trim();
    try {
      const reference = doc(db, "Alumnos", selected.id),
        history = await runTransaction(db, async (transaction) => {
          const snapshot = await transaction.get(reference);
          if (!snapshot.exists())
            throw new Error("No se encontró el expediente del atleta.");
          const current = Array.isArray(snapshot.data().historialFisico)
            ? (snapshot.data().historialFisico as PhysicalAssessment[])
            : [];
          const next = [
            record as unknown as PhysicalAssessment,
            ...current,
          ].slice(0, 100);
          transaction.update(reference, { historialFisico: next });
          return next;
        });
      setAthletes((v) =>
        v.map((a) =>
          a.id === selected.id ? { ...a, historialFisico: history } : a,
        ),
      );
      setMessage(
        qualityWarnings.length
          ? "Evaluación guardada con advertencias de calidad."
          : "Evaluación guardada correctamente.",
      );
      setSection("history");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "No se pudo guardar.");
    } finally {
      setSaving(false);
    }
  }
  async function saveTestForAthlete(
    athleteId: string,
    input: Record<string, string>,
  ) {
    if (!db) throw new Error("No hay conexión con la base de datos.");
    const athlete = athletes.find((item) => item.id === athleteId);
    if (!athlete) throw new Error("No se encontró al atleta.");
    const prior = (athlete.historialFisico || []) as PhysicalAssessment[],
      profile = latestProfile(prior),
      parsed = Object.fromEntries(
        testKeys
          .map((key) => [key, physicalNumber(key, input[key] || "")])
          .filter(([, value]) => value !== undefined),
      ) as Record<string, number>;
    if (!Object.keys(parsed).length)
      throw new Error("Captura al menos un resultado físico.");
    for (const [key, value] of Object.entries(parsed))
      if (integerTestKeys.has(key) && !Number.isInteger(value))
        throw new Error(
          `${key}: registra únicamente repeticiones o unidades completas.`,
        );
    const dataIssues = validatePhysicalData(parsed),
      dataError = physicalDataErrorMessage(dataIssues);
    if (dataError) throw new Error(dataError);
    const incoming = Object.fromEntries(
        ["lagartijas", "sentadillas", "abdominales", "burpees"]
          .map((key) => [key, parsed[key]])
          .filter(([, value]) => value !== undefined),
      ) as Partial<Record<FitnessExerciseKey, number>>,
      combined = { ...latestFitnessValues(prior), ...incoming },
      profileAge = optionalNumber(input.edad || "") ?? profile.edad,
      profileSex =
        (input.sexoCalculo as "masculino" | "femenino" | undefined) ||
        profile.sexoCalculo,
      profileWeight = optionalNumber(input.pesoKg || "") ?? profile.pesoKg,
      score = buildFitnessScoreReport({
        values: combined,
        age: profileAge,
        sex: profileSex,
        weightKg: profileWeight,
        history: prior,
        cohort: athletes,
        athleteId,
      });
    const result: Record<string, unknown> = {
      id: crypto.randomUUID(),
      fecha: /^\d{4}-\d{2}-\d{2}$/.test(input.fecha || "")
        ? input.fecha
        : form.fecha || today(),
      schemaVersion: 2,
      protocolVersion: "pruebas-fisicas-v2",
      tipoRegistro: "pruebas",
      registradoPor: user?.email || "personal",
      puntajeBateria60: fitnessScoreSnapshot(score),
      ...parsed,
    };
    const warnings = dataIssues
      .filter((issue) => issue.level === "warning")
      .map((issue) => issue.message);
    if (warnings.length) result.advertenciasCalidad = warnings;
    const reference = doc(db, "Alumnos", athleteId),
      history = await runTransaction(db, async (transaction) => {
        const snapshot = await transaction.get(reference);
        if (!snapshot.exists())
          throw new Error("No se encontró el expediente del atleta.");
        const current = Array.isArray(snapshot.data().historialFisico)
          ? (snapshot.data().historialFisico as PhysicalAssessment[])
          : [];
        const next = [
          result as unknown as PhysicalAssessment,
          ...current,
        ].slice(0, 100);
        transaction.update(reference, { historialFisico: next });
        return next;
      });
    setAthletes((current) =>
      current.map((item) =>
        item.id === athleteId ? { ...item, historialFisico: history } : item,
      ),
    );
  }
  async function saveTests() {
    if (!selected) return;
    setSaving(true);
    try {
      await saveTestForAthlete(selected.id, form);
      setMessage("Pruebas físicas guardadas correctamente.");
      setSection("history");
    } catch (e) {
      setMessage(
        e instanceof Error ? e.message : "No se pudieron guardar las pruebas.",
      );
    } finally {
      setSaving(false);
    }
  }
  async function deleteRecord(recordId: string) {
    if (
      !db ||
      !selected ||
      !window.confirm(
        "¿Eliminar este registro del historial? Esta acción no se puede deshacer.",
      )
    )
      return;
    setSaving(true);
    try {
      const reference = doc(db, "Alumnos", selected.id),
        history = await runTransaction(db, async (transaction) => {
          const snapshot = await transaction.get(reference);
          if (!snapshot.exists())
            throw new Error("No se encontró el expediente del atleta.");
          const current = Array.isArray(snapshot.data().historialFisico)
            ? (snapshot.data().historialFisico as PhysicalAssessment[])
            : [];
          const next = current.filter((record) => record.id !== recordId);
          transaction.update(reference, { historialFisico: next });
          return next;
        });
      setAthletes((current) =>
        current.map((item) =>
          item.id === selected.id
            ? { ...item, historialFisico: history }
            : item,
        ),
      );
      setMessage("Registro eliminado correctamente.");
    } catch (e) {
      setMessage(
        e instanceof Error ? e.message : "No se pudo eliminar el registro.",
      );
    } finally {
      setSaving(false);
    }
  }
  async function saveGoals() {
    if (!db || !selected) return;
    setSaving(true);
    const goals: PhysicalGoals = {
      enfoque: goalForm.enfoque as PhysicalGoals["enfoque"],
      fechaObjetivo: goalForm.fechaObjetivo || undefined,
      notas: goalForm.notas?.trim() || undefined,
      actualizadoEn: new Date().toISOString(),
    };
    for (const key of [
      "pesoKg",
      "grasaPorcentaje",
      "cinturaEstatura",
      "vo2Max",
      "lagartijas",
      "sentadillas",
      "abdominales",
      "planchaSegundos",
      "saltoHorizontalCm",
      "sprint10mSegundos",
    ] as const) {
      const value = optionalNumber(goalForm[key] || "");
      if (value !== undefined) goals[key] = value;
    }
    try {
      await updateDoc(doc(db, "Alumnos", selected.id), { metasFisicas: goals });
      setAthletes((v) =>
        v.map((a) =>
          a.id === selected.id ? { ...a, metasFisicas: goals } : a,
        ),
      );
      setMessage("Metas guardadas correctamente.");
    } catch (e) {
      setMessage(
        e instanceof Error ? e.message : "No se pudieron guardar las metas.",
      );
    } finally {
      setSaving(false);
    }
  }
  return (
    <main className="min-h-screen bg-[#070b12] p-4 text-white md:p-8">
      <section className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-white/10 bg-white/[.035] p-3">
        <button
          type="button"
          onClick={() => setWorkspace("choose")}
          className="px-3 text-left"
        >
          <p className="text-xs font-black uppercase tracking-[.2em] text-cyan-300">
            Centro físico
          </p>
          <h1 className="text-2xl font-black">
            Análisis, evaluación e hidratación
          </h1>
        </button>
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => setWorkspace("analyze")}
            className={`flex items-center gap-2 rounded-xl px-4 py-3 font-black ${workspace === "analyze" ? "bg-cyan-300 text-slate-950" : "bg-white/[.06] text-slate-200"}`}
          >
            <Activity className="h-4 w-4" />
            Analizar
          </button>
          <button
            type="button"
            onClick={() => setWorkspace("evaluate")}
            className={`flex items-center gap-2 rounded-xl px-4 py-3 font-black ${workspace === "evaluate" ? "bg-violet-300 text-slate-950" : "bg-white/[.06] text-slate-200"}`}
          >
            <ClipboardCheck className="h-4 w-4" />
            Evaluar
          </button>
          <button
            type="button"
            onClick={() => setWorkspace("hydration")}
            className={`flex items-center gap-2 rounded-xl px-4 py-3 font-black ${workspace === "hydration" ? "bg-sky-300 text-slate-950" : "bg-white/[.06] text-slate-200"}`}
          >
            <Droplets className="h-4 w-4" />
            Hidratación
          </button>
        </div>
      </section>
      {workspace === "choose" ? (
        <section className="grid min-h-[65vh] place-content-center gap-5 md:grid-cols-3">
          <button
            type="button"
            onClick={() => setWorkspace("analyze")}
            className="group max-w-xl rounded-[2.25rem] border border-cyan-300/20 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,.18),transparent_45%),#101827] p-8 text-left transition hover:-translate-y-1 hover:border-cyan-300/50"
          >
            <Activity className="h-12 w-12 text-cyan-300" />
            <h2 className="mt-6 text-3xl font-black">Analizar</h2>
            <p className="mt-2 text-slate-400">
              Métricas integradas, puntuaciones, tendencias, prioridades y
              ranking de rendimiento.
            </p>
          </button>
          <button
            type="button"
            onClick={() => setWorkspace("evaluate")}
            className="group max-w-xl rounded-[2.25rem] border border-violet-300/20 bg-[radial-gradient(circle_at_top_right,rgba(167,139,250,.18),transparent_45%),#101827] p-8 text-left transition hover:-translate-y-1 hover:border-violet-300/50"
          >
            <ClipboardCheck className="h-12 w-12 text-violet-300" />
            <h2 className="mt-6 text-3xl font-black">Evaluar</h2>
            <p className="mt-2 text-slate-400">
              Composición, medidas, pruebas físicas, historial individual y
              metas.
            </p>
          </button>
          <button
            type="button"
            onClick={() => setWorkspace("hydration")}
            className="group max-w-xl rounded-[2.25rem] border border-sky-300/20 bg-[radial-gradient(circle_at_top_right,rgba(56,189,248,.2),transparent_45%),#101827] p-8 text-left transition hover:-translate-y-1 hover:border-sky-300/50"
          >
            <Droplets className="h-12 w-12 text-sky-300" />
            <h2 className="mt-6 text-3xl font-black">Hidratación</h2>
            <p className="mt-2 text-slate-400">
              Ingesta, pérdida de líquidos, tasa de sudoración e historial por
              clase.
            </p>
          </button>
        </section>
      ) : workspace === "analyze" ? (
        <PhysicalAnalysisCenter
          athletes={athletes}
          onEvaluate={(id) => {
            setSelectedId(id);
            setWorkspace("evaluate");
          }}
        />
      ) : workspace === "hydration" ? (
        <HydrationLab athletes={athletes} />
      ) : (
        <>
          <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="flex items-center gap-2 text-sm font-bold text-cyan-300">
                <Activity className="h-4 w-4" />
                Evaluación longitudinal
              </p>
              <h1 className="text-4xl font-black">Estado físico</h1>
              <p className="mt-1 max-w-3xl text-slate-400">
                Composición, condición física, objetivos personalizados y
                evolución. Las estimaciones no sustituyen una valoración médica.
              </p>
            </div>
            <button
              onClick={() => void save()}
              disabled={!selected || !bmi || !age || saving}
              className="flex min-h-12 items-center gap-2 rounded-xl bg-cyan-300 px-5 font-black text-slate-950 disabled:opacity-40"
            >
              <Save />
              {saving ? "Guardando…" : "Guardar evaluación"}
            </button>
          </header>
          <section className="mb-6 rounded-3xl border border-white/10 bg-white/[.04] p-5">
            <div className="grid gap-4 md:grid-cols-[1fr_220px]">
              <AdminAthletePicker
                athletes={athletes}
                selectedId={selectedId}
                onSelect={setSelectedId}
              />
              <Field label="Fecha">
                <input
                  type="date"
                  value={form.fecha}
                  onChange={(e) => set("fecha", e.target.value)}
                  className="input"
                />
              </Field>
            </div>
          </section>
          <BmiBanner status={bmiStatus} bmi={bmi} />
          <nav className="mb-6 grid gap-2 rounded-2xl border border-white/10 bg-black/20 p-2 sm:grid-cols-2 xl:grid-cols-4">
            <Tab
              active={section === "composition"}
              onClick={() => setSection("composition")}
              icon={Ruler}
              label="Composición y salud"
            />
            <Tab
              active={section === "tests"}
              onClick={() => setSection("tests")}
              icon={Dumbbell}
              label="Pruebas físicas"
            />
            <Tab
              active={section === "history"}
              onClick={() => setSection("history")}
              icon={History}
              label={`Evolución (${records.length})`}
            />
            <Tab
              active={section === "goals"}
              onClick={() => setSection("goals")}
              icon={Target}
              label="Metas"
            />
          </nav>
          {section === "composition" && (
            <div className="grid gap-6 xl:grid-cols-[1fr_380px]">
              <div className="space-y-6">
                <Card
                  icon={Ruler}
                  title="Composición y medidas"
                  subtitle="Usa siempre condiciones comparables."
                >
                  <BodyCompositionWheel
                    sex={sex}
                    weight={weight || 70}
                    height={height || 170}
                    onSexChange={(v) => set("sexoCalculo", v)}
                    onWeightChange={(v) => set("pesoKg", String(v))}
                    onHeightChange={(v) => set("estaturaCm", String(v))}
                  />
                  <div className="grid gap-4 sm:grid-cols-2">
                    <NumberField
                      label="Edad"
                      unit="años"
                      value={form.edad || ""}
                      onChange={(v) => set("edad", v)}
                    />
                    <Switch
                      label="Calcular PGC automáticamente"
                      detail="Estimación Deurenberg para adultos"
                      checked={autoFat}
                      onChange={setAutoFat}
                    />
                  </div>
                  <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {!autoFat && (
                      <NumberField
                        label="Grasa corporal"
                        unit="%"
                        value={form.grasaPorcentaje || ""}
                        onChange={(v) => set("grasaPorcentaje", v)}
                      />
                    )}{" "}
                    {measures.map(([key, label]) => (
                      <NumberField
                        key={key}
                        label={label}
                        unit="cm"
                        value={form[key] || ""}
                        onChange={(v) => set(key, v)}
                      />
                    ))}
                  </div>
                  <div className="mt-4 grid gap-4 md:grid-cols-2">
                    {!autoFat && (
                      <Field label="Método PGC">
                        <input
                          className="input"
                          value={form.metodoGrasa || ""}
                          onChange={(e) => set("metodoGrasa", e.target.value)}
                          placeholder="Bioimpedancia, plicómetro…"
                        />
                      </Field>
                    )}
                    <Field label="Notas">
                      <input
                        className="input"
                        value={form.notas || ""}
                        onChange={(e) => set("notas", e.target.value)}
                        placeholder="Condiciones o incidencias"
                      />
                    </Field>
                  </div>
                </Card>
                <MeasurementContext form={form} set={set} />
                <MenstrualContext form={form} set={set} />
              </div>
              <aside className="h-fit space-y-4 xl:sticky xl:top-6">
                <Card
                  icon={Calculator}
                  title="Análisis automático"
                  subtitle="Separa cribado, estimaciones y calidad."
                >
                  <div className="grid gap-3">
                    <Result
                      label="Calidad de medición"
                      value={`${quality}/100`}
                      note={
                        quality >= 80
                          ? "Comparable"
                          : quality >= 60
                            ? "Interpretar con cautela"
                            : "Baja confiabilidad"
                      }
                    />
                    <Result
                      label="Referencias con datos"
                      value={`${previewIndicators.filter((item) => item.level !== "neutral").length}/${previewIndicators.length}`}
                      note="No es una puntuación de salud"
                    />
                    <Result
                      label="IMC"
                      value={bmi || "—"}
                      target={
                        age && age >= 20
                          ? "Cribado adulto 18.5–24.9"
                          : "Usar percentiles pediátricos"
                      }
                    />
                    <Result
                      label="PGC"
                      value={activeFat !== undefined ? `${activeFat}%` : "—"}
                      target={
                        fatRange
                          ? `Orientativo ${fatRange[0]}–${fatRange[1]}%; confirma el método`
                          : "Seguir con el mismo método"
                      }
                    />
                    <Result
                      label="Masa grasa"
                      value={
                        body.fatMass !== undefined ? `${body.fatMass} kg` : "—"
                      }
                    />
                    <Result
                      label="Masa libre de grasa"
                      value={
                        body.leanMass !== undefined
                          ? `${body.leanMass} kg`
                          : "—"
                      }
                    />
                    <Result
                      label="FFMI"
                      value={body.ffmi ?? "—"}
                      note="Descriptivo, sin diagnóstico"
                    />
                    <Result
                      label="Cintura/altura"
                      value={waistHeight ?? "—"}
                      target={
                        age && age >= 20
                          ? "Referencia práctica adulta < 0.50"
                          : "Interpretar por edad"
                      }
                    />
                    <Result
                      label="VO₂ estimado"
                      value={vo2 ? `${vo2} ml/kg/min` : "—"}
                      target={
                        vo2Goal
                          ? `Contexto orientativo ≥ ${vo2Goal}`
                          : "Completa edad y Navette"
                      }
                    />
                  </div>
                </Card>
                <div className="rounded-2xl border border-amber-300/20 bg-amber-500/10 p-4 text-xs leading-5 text-amber-100">
                  <ShieldCheck className="mb-2 h-5 w-5" />
                  No se genera un diagnóstico ni un “peso ideal”. Repite
                  mediciones antes de ajustar el plan y prioriza síntomas,
                  rendimiento y evolución personal.
                </div>
              </aside>
            </div>
          )}
          {section === "composition" && (
            <div className="mt-6">
              <SkinfoldPanel form={form} set={set} assessment={skinfolds} />
            </div>
          )}
          {section === "tests" && (
            <PhysicalTestLab
              values={form}
              onChange={set}
              athletes={athletes}
              selectedId={selectedId}
              onSave={saveTests}
              onSaveAthleteTests={saveTestForAthlete}
              saving={saving}
              scoreReport={fitnessReport}
            />
          )}{" "}
          {section === "history" && (
            <PhysicalHistory
              records={records}
              goals={selected?.metasFisicas}
              hydration={selected?.historialHidratacion}
              onDelete={(record) => void deleteRecord(record.id)}
            />
          )}{" "}
          {section === "goals" && (
            <GoalsPanel
              form={goalForm}
              set={setGoalForm}
              latest={currentSnapshot}
              saving={saving}
              save={() => void saveGoals()}
            />
          )}{" "}
          {message && (
            <p
              className={`mt-5 rounded-xl p-3 ${message.includes("correctamente") || message.includes("guardadas") || message.includes("eliminado") ? "bg-emerald-500/15 text-emerald-200" : "bg-red-500/15 text-red-200"}`}
            >
              {message}
            </p>
          )}
        </>
      )}
    </main>
  );
}
function SkinfoldPanel({
  form,
  set,
  assessment,
}: {
  form: Form;
  set: (k: string, v: string) => void;
  assessment: SkinfoldAssessment;
}) {
  const hasData = assessment.sites.some((site) => site.readings.length),
    [open, setOpen] = useState(hasData);
  return (
    <section className="overflow-hidden rounded-3xl border border-violet-300/15 bg-[radial-gradient(circle_at_top_right,rgba(139,92,246,.12),transparent_35%),rgba(15,23,42,.72)]">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="flex w-full items-center justify-between gap-4 p-5 text-left"
      >
        <span>
          <span className="text-xs font-black uppercase tracking-[.2em] text-violet-300">
            Antropometría ISAK
          </span>
          <b className="mt-1 block text-xl text-white">
            Perfil de ocho pliegues cutáneos
          </b>
          <small className="mt-1 block text-slate-400">
            Dos lecturas por sitio; una tercera cuando no coinciden.
          </small>
        </span>
        <span className="flex items-center gap-3">
          <span
            className={`rounded-full px-3 py-1.5 text-[10px] font-black uppercase ${assessment.complete && assessment.needsRepeat.length === 0 ? "bg-emerald-400/15 text-emerald-200" : hasData ? "bg-amber-400/15 text-amber-200" : "bg-white/[.06] text-slate-400"}`}
          >
            {assessment.complete ? `${assessment.sum} mm` : "Opcional"}
          </span>
          <ChevronDown
            className={`h-5 w-5 text-slate-400 transition ${open ? "rotate-180" : ""}`}
          />
        </span>
      </button>
      {open && (
        <div className="border-t border-white/[.07] p-5">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {assessment.sites.map((site) => (
              <article
                key={site.key}
                className={`rounded-2xl border p-4 ${site.readings.length > 1 && !site.consistent ? "border-amber-300/25 bg-amber-500/[.07]" : "border-white/[.08] bg-black/20"}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <b className="text-sm text-white">{site.label}</b>
                    <span className="block text-[10px] text-slate-500">
                      Lado derecho · mm
                    </span>
                  </div>
                  <span
                    className={`rounded-full px-2 py-1 text-[9px] font-black ${site.consistent ? "bg-emerald-400/10 text-emerald-200" : site.readings.length > 1 ? "bg-amber-400/10 text-amber-200" : "bg-white/[.05] text-slate-500"}`}
                  >
                    {site.value !== undefined ? `${site.value} mm` : "—"}
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2">
                  {[1, 2, 3].map((attempt) => (
                    <label key={attempt}>
                      <span className="mb-1 block text-center text-[9px] font-bold text-slate-600">
                        {attempt}
                      </span>
                      <input
                        aria-label={`${site.label}, lectura ${attempt}`}
                        type="number"
                        min="1"
                        max="80"
                        step="0.1"
                        inputMode="decimal"
                        value={form[`skinfold_${site.key}_${attempt}`] || ""}
                        onChange={(event) =>
                          set(
                            `skinfold_${site.key}_${attempt}`,
                            event.target.value,
                          )
                        }
                        className="h-10 w-full rounded-xl border border-white/10 bg-slate-950 px-2 text-center text-sm font-bold text-white outline-none focus:border-violet-300"
                      />
                    </label>
                  ))}
                </div>
                {site.readings.length > 1 && (
                  <p
                    className={`mt-2 text-[10px] ${site.consistent ? "text-emerald-300" : "text-amber-200"}`}
                  >
                    {site.consistent
                      ? "Lecturas consistentes"
                      : `Diferencia ${site.spread} mm · repite el sitio`}
                  </p>
                )}
              </article>
            ))}
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-[1fr_180px_180px]">
            <Field label="Plicómetro utilizado">
              <input
                className="input"
                value={form.plicometro || ""}
                onChange={(event) => set("plicometro", event.target.value)}
                maxLength={80}
                placeholder="Marca y modelo"
              />
            </Field>
            <Result
              label="Suma de 8"
              value={
                assessment.sum !== undefined
                  ? `${assessment.sum} mm`
                  : "Incompleta"
              }
              note="Principal indicador longitudinal"
            />
            <Result
              label="Consistencia"
              value={`${assessment.quality}/100`}
              note="Control interno, no acreditación"
            />
          </div>
          {assessment.needsRepeat.length > 0 && (
            <p className="mt-4 rounded-xl border border-amber-300/15 bg-amber-500/10 p-3 text-xs text-amber-100">
              <b>Revisar antes de guardar:</b>{" "}
              {assessment.needsRepeat.join(", ")}.
            </p>
          )}
          <p className="mt-4 text-xs leading-relaxed text-slate-500">
            La suma de pliegues sirve para comparar al atleta consigo mismo. No
            estima grasa visceral ni genera automáticamente un porcentaje de
            grasa. La localización y técnica deben seguir el manual ISAK y ser
            realizadas por personal capacitado.
          </p>
        </div>
      )}
    </section>
  );
}
function MeasurementContext({
  form,
  set,
}: {
  form: Form;
  set: (k: string, v: string) => void;
}) {
  return (
    <Card
      icon={ClipboardCheck}
      title="Calidad y condiciones"
      subtitle="Determinan qué tan comparable es la evaluación."
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Field label="Hora">
          <input
            type="time"
            className="input"
            value={form.horaMedicion || ""}
            onChange={(e) => set("horaMedicion", e.target.value)}
          />
        </Field>
        <NumberField
          label="Ayuno"
          unit="horas"
          value={form.ayunoHoras || ""}
          onChange={(v) => set("ayunoHoras", v)}
        />
        <NumberField
          label="Último ejercicio"
          unit="horas"
          value={form.ejercicioPrevioHoras || ""}
          onChange={(v) => set("ejercicioPrevioHoras", v)}
        />
        <Field label="Hidratación">
          <select
            className="input"
            value={form.hidratacion || "habitual"}
            onChange={(e) => set("hidratacion", e.target.value)}
          >
            <option value="baja">Baja</option>
            <option value="habitual">Habitual</option>
            <option value="alta">Alta</option>
          </select>
        </Field>
      </div>
    </Card>
  );
}
function MenstrualContext({
  form,
  set,
}: {
  form: Form;
  set: (k: string, v: string) => void;
}) {
  const active = form.contextoMenstrual === "true";
  return (
    <Card
      icon={Activity}
      title="Contexto menstrual opcional"
      subtitle="No modifica ni penaliza la puntuación; ayuda a interpretar líquidos y rendimiento."
    >
      <Switch
        label="Registrar contexto"
        detail="Información sensible y opcional"
        checked={active}
        onChange={(v) => set("contextoMenstrual", String(v))}
      />
      {active && (
        <div className="mt-5 space-y-4">
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Fase declarada">
              <select
                className="input"
                value={form.faseMenstrual || "desconocida"}
                onChange={(e) => set("faseMenstrual", e.target.value)}
              >
                {[
                  ["desconocida", "No sé"],
                  ["menstruacion", "Menstruación"],
                  ["folicular", "Folicular"],
                  ["ovulatoria", "Ovulatoria estimada"],
                  ["lutea", "Lútea"],
                  ["premenstrual", "Premenstrual"],
                ].map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </select>
            </Field>
            <Switch
              label="Anticoncepción hormonal"
              checked={form.anticoncepcionHormonal === "true"}
              onChange={(v) => set("anticoncepcionHormonal", String(v))}
            />
            <Switch
              label="Ciclo irregular"
              checked={form.cicloIrregular === "true"}
              onChange={(v) => set("cicloIrregular", String(v))}
            />
          </div>
          <p className="text-xs font-black uppercase tracking-wider text-slate-500">
            Síntomas 0 = ninguno · 3 = intenso
          </p>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["dolorMenstrual", "Dolor"],
              ["fatigaMenstrual", "Fatiga"],
              ["retencionLiquidos", "Retención"],
              ["sangradoMenstrual", "Sangrado"],
              ["suenoCalidad", "Sueño deficiente"],
              ["esfuerzoPercibido", "Esfuerzo percibido"],
            ].map(([key, label]) => (
              <Scale
                key={key}
                label={label}
                value={form[key] || "0"}
                set={(v) => set(key, v)}
              />
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}
function BmiBanner({
  status,
  bmi,
}: {
  status: ReturnType<typeof bmiZone>;
  bmi: number;
}) {
  const colors = {
    blue: "border-blue-300/25 bg-blue-500/10 text-blue-200",
    green: "border-emerald-300/25 bg-emerald-500/10 text-emerald-200",
    yellow: "border-amber-300/25 bg-amber-500/10 text-amber-100",
    red: "border-red-300/25 bg-red-500/10 text-red-100",
    neutral: "border-white/10 bg-white/[.03] text-slate-300",
  };
  return (
    <section className={`mb-6 rounded-3xl border p-5 ${colors[status.zone]}`}>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[.2em]">
            {status.zone === "neutral"
              ? "Interpretación de IMC"
              : "Cribado de IMC adulto"}
          </p>
          <h2 className="mt-1 text-2xl font-black">
            {status.label} · {bmi || "—"}
          </h2>
          <p className="mt-1 max-w-3xl text-sm opacity-75">{status.note}</p>
        </div>
        <b className="rounded-2xl bg-black/20 px-5 py-3 text-xl">
          {status.range}
        </b>
      </div>
      {status.zone !== "neutral" && (
        <div className="mt-4 grid grid-cols-4 overflow-hidden rounded-full text-center text-[9px] font-black uppercase">
          <span className="bg-blue-500 py-2">&lt;18.5</span>
          <span className="bg-emerald-500 py-2">18.5–24.9</span>
          <span className="bg-amber-400 py-2 text-amber-950">25–29.9</span>
          <span className="bg-red-500 py-2">≥30</span>
        </div>
      )}
    </section>
  );
}
function GoalsPanel({
  form,
  set,
  latest,
  saving,
  save,
}: {
  form: Form;
  set: React.Dispatch<React.SetStateAction<Form>>;
  latest?: PhysicalAssessment;
  saving: boolean;
  save: () => void;
}) {
  const update = (k: string, v: string) => set((x) => ({ ...x, [k]: v })),
    suggestible = (key: string) => !["pesoKg", "grasaPorcentaje"].includes(key),
    suggest = (key: string) => {
      const values: Record<string, number | undefined> = {
        cinturaEstatura: latest?.cinturaEstatura,
        vo2Max: latest?.vo2MaxEstimado,
        lagartijas: latest?.lagartijas,
        sentadillas: latest?.sentadillas,
        abdominales: latest?.abdominales,
        planchaSegundos: latest?.planchaSegundos,
        saltoHorizontalCm: latest?.saltoHorizontalCm,
        sprint10mSegundos: latest?.sprint10mSegundos,
      };
      const current = values[key];
      if (current === undefined || !suggestible(key)) return "";
      const lower = key === "cinturaEstatura" || key === "sprint10mSegundos",
        factor = lower ? 0.97 : 1.05;
      return String(Math.round(current * factor * 10) / 10);
    };
  const fields = [
    ["pesoKg", "Peso", "kg"],
    ["grasaPorcentaje", "Grasa corporal", "%"],
    ["cinturaEstatura", "Cintura/altura", "ratio"],
    ["vo2Max", "VO₂ máx.", "ml/kg/min"],
    ["lagartijas", "Lagartijas", "reps"],
    ["sentadillas", "Sentadillas", "reps"],
    ["abdominales", "Abdominales", "reps"],
    ["planchaSegundos", "Plancha", "s"],
    ["saltoHorizontalCm", "Salto horizontal", "cm"],
    ["sprint10mSegundos", "Sprint 10 m", "s"],
  ] as const;
  return (
    <div className="space-y-6">
      <Card
        icon={Target}
        title="Plan personal de salud y rendimiento"
        subtitle="Metas pequeñas, editables y revisadas con datos comparables."
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Enfoque">
            <select
              className="input"
              value={form.enfoque || "salud"}
              onChange={(e) => update("enfoque", e.target.value)}
            >
              <option value="salud">Salud general</option>
              <option value="recomposicion">Recomposición corporal</option>
              <option value="rendimiento">Rendimiento</option>
              <option value="competencia">Competencia</option>
              <option value="mantenimiento">Mantenimiento</option>
            </select>
          </Field>
          <Field label="Fecha objetivo">
            <input
              type="date"
              className="input"
              value={form.fechaObjetivo || ""}
              onChange={(e) => update("fechaObjetivo", e.target.value)}
            />
          </Field>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {fields.map(([key, label, unit]) => (
            <div
              key={key}
              className="rounded-2xl border border-white/10 bg-black/20 p-4"
            >
              <NumberField
                label={`Meta ${label}`}
                unit={unit}
                value={form[key] || ""}
                onChange={(v) => update(key, v)}
              />
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="text-slate-500">
                  Actual:{" "}
                  {key === "vo2Max"
                    ? latest?.vo2MaxEstimado
                    : ((latest?.[key as keyof PhysicalAssessment] as
                        | number
                        | undefined) ?? "—")}
                </span>
                {suggestible(key) ? (
                  <button
                    type="button"
                    onClick={() => update(key, suggest(key))}
                    className="font-black text-cyan-300"
                  >
                    Sugerir +5%
                  </button>
                ) : (
                  <span className="text-[10px] text-slate-600">
                    Definir con contexto
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
        <p className="mt-3 rounded-xl bg-white/[.04] p-3 text-xs text-slate-400">
          Peso y grasa corporal no reciben una reducción automática. Su meta
          depende de salud, composición, categoría, alimentación y criterio
          profesional.
        </p>
        <Field label="Notas del objetivo">
          <textarea
            className="input mt-4 min-h-24 py-3"
            value={form.notas || ""}
            onChange={(e) => update("notas", e.target.value)}
            placeholder="Estrategia, restricciones, categoría o prioridades…"
          />
        </Field>
        <button
          onClick={save}
          disabled={saving}
          className="mt-5 flex min-h-12 items-center gap-2 rounded-xl bg-cyan-300 px-6 font-black text-slate-950 disabled:opacity-40"
        >
          <Save />
          {saving ? "Guardando…" : "Guardar plan de metas"}
        </button>
      </Card>
      <div className="rounded-3xl border border-white/10 bg-white/[.03] p-5">
        <p className="font-black">Criterios del entorno de salud</p>
        <ul className="mt-3 grid gap-2 text-sm text-slate-400 sm:grid-cols-2">
          <li>• No recomienda peso ideal único.</li>
          <li>• Menores requieren percentiles pediátricos.</li>
          <li>• El ciclo menstrual no penaliza resultados.</li>
          <li>• El IMC es cribado, no diagnóstico.</li>
          <li>• Las metas físicas parten de la línea base.</li>
          <li>• Cortes de peso rápidos no se automatizan.</li>
        </ul>
      </div>
    </div>
  );
}
function Card({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: typeof Ruler;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-3xl border border-white/10 bg-slate-900/70 p-5">
      <header className="mb-5 flex gap-3">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-cyan-500/15 text-cyan-300">
          <Icon className="h-5 w-5" />
        </span>
        <div>
          <h2 className="font-black">{title}</h2>
          <p className="text-sm text-slate-400">{subtitle}</p>
        </div>
      </header>
      {children}
    </section>
  );
}
function Tab({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: typeof Ruler;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-black ${active ? "bg-cyan-300 text-slate-950" : "text-slate-400 hover:bg-white/5"}`}
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}
function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex min-w-0 flex-col">
      <span className="mb-1.5 flex min-h-8 items-end text-xs font-bold uppercase leading-4 tracking-wide text-slate-400">
        {label}
      </span>
      {children}
    </label>
  );
}
function NumberField({
  label,
  unit,
  value,
  onChange,
}: {
  label: string;
  unit: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <Field label={`${label} (${unit})`}>
      <input
        type="number"
        min="0"
        step="0.1"
        inputMode="decimal"
        className="input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </Field>
  );
}
function Switch({
  label,
  detail,
  checked,
  onChange,
}: {
  label: string;
  detail?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex min-h-14 cursor-pointer items-center justify-between gap-3 rounded-xl border border-white/10 bg-black/20 p-3">
      <span>
        <b className="block text-sm">{label}</b>
        {detail && <small className="text-slate-500">{detail}</small>}
      </span>
      <input
        type="checkbox"
        className="peer sr-only"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
      />
      <span className="relative h-7 w-12 shrink-0 rounded-full bg-slate-700 transition peer-checked:bg-cyan-300 after:absolute after:left-1 after:top-1 after:h-5 after:w-5 after:rounded-full after:bg-white after:transition peer-checked:after:translate-x-5" />
    </label>
  );
}
function Scale({
  label,
  value,
  set,
}: {
  label: string;
  value: string;
  set: (v: string) => void;
}) {
  return (
    <div className="rounded-xl bg-black/20 p-3">
      <span className="text-xs font-bold text-slate-400">{label}</span>
      <div className="mt-2 grid grid-cols-4 gap-1">
        {[0, 1, 2, 3].map((v) => (
          <button
            key={v}
            onClick={() => set(String(v))}
            className={`h-9 rounded-lg font-black ${Number(value) === v ? "bg-cyan-300 text-slate-950" : "bg-white/5 text-slate-500"}`}
          >
            {v}
          </button>
        ))}
      </div>
    </div>
  );
}
function Result({
  label,
  value,
  target,
  note,
}: {
  label: string;
  value: string | number;
  target?: string;
  note?: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
      <span className="text-xs font-bold uppercase text-slate-500">
        {label}
      </span>
      <b className="mt-1 block text-2xl">{value}</b>
      {(target || note) && (
        <small className="text-cyan-200/70">{target || note}</small>
      )}
    </div>
  );
}
