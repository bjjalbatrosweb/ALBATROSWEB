"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Copy,
  CreditCard,
  DoorOpen,
  Fullscreen,
  LogIn,
  MapPin,
  Send,
  ShieldCheck,
  UserPlus,
  X,
} from "lucide-react";
import { Logo } from "@/components/logo";

const schedules = [
  {
    discipline: "Jiu-Jitsu",
    days: "Horarios matutinos y vespertinos",
    times: [
      "Matutino · Lunes, miércoles y viernes · 9:00–10:00 a. m.",
      "Vespertino · Martes, jueves y sábado · 7:00–8:00 p. m.",
    ],
    tone: "bg-red-500",
  },
  {
    discipline: "Kick Boxing",
    days: "Horarios matutinos y vespertinos",
    times: [
      "Matutino · Lunes, miércoles y viernes · 7:00–8:00 a. m.",
      "Vespertino · Martes, jueves y sábado · 8:00–9:00 p. m.",
    ],
    tone: "bg-amber-400",
  },
  {
    discipline: "MMA",
    days: "Horarios matutinos y vespertinos",
    times: [
      "Matutino · Lunes, miércoles y viernes · 8:00–9:00 a. m.",
      "Vespertino · Martes, jueves y sábado · 8:00–9:00 p. m.",
      "Vespertino · Martes, jueves y sábado · 9:00–10:00 p. m.",
    ],
    tone: "bg-violet-400",
  },
] as const;

export default function KioskPage() {
  const router = useRouter(),
    [now, setNow] = useState(new Date()),
    [panel, setPanel] = useState<"schedules" | "trial" | null>(null),
    [exitOpen, setExitOpen] = useState(false),
    [pin, setPin] = useState(""),
    [error, setError] = useState(""),
    [sending, setSending] = useState(false),
    [sent, setSent] = useState(false),
    [form, setForm] = useState({
      nombre: "",
      telefono: "",
      disciplina: "Jiu-Jitsu",
      horario: "",
      sede: "CAUCEL",
      notas: "",
    });
  useEffect(() => {
    localStorage.setItem("albatrosKioskMode", "1");
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  const enterFullscreen = async () => {
    try {
      if (!document.fullscreenElement)
        await document.documentElement.requestFullscreen();
    } catch {
      /* El kiosco continúa aunque el navegador niegue pantalla completa. */
    }
  };
  const exit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (pin !== "1908") {
      setError("PIN incorrecto");
      setPin("");
      return;
    }
    localStorage.removeItem("albatrosKioskMode");
    if (document.fullscreenElement) await document.exitFullscreen();
    router.push("/");
  };
  const requestTrial = async (event: React.FormEvent) => {
    event.preventDefault();
    if (sending) return;
    const phone = form.telefono.replace(/\D/g, "");
    if (form.nombre.trim().length < 2 || phone.length < 10 || !form.horario) {
      setError("Completa nombre, teléfono y horario preferido.");
      return;
    }
    setSending(true);
    setError("");
    try {
      const response = await fetch("/api/clase-prueba", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          telefono: phone,
          origen: "kiosco",
          website: "",
        }),
      });
      const result = (await response.json().catch(() => ({}))) as {
        mensaje?: string;
      };
      if (!response.ok)
        throw new Error(result.mensaje || "No se pudo enviar la solicitud.");
      setSent(true);
      setForm({
        nombre: "",
        telefono: "",
        disciplina: "Jiu-Jitsu",
        horario: "",
        sede: "CAUCEL",
        notas: "",
      });
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : "No se pudo enviar la solicitud. Intenta nuevamente.",
      );
    } finally {
      setSending(false);
    }
  };
  const closePanel = () => {
    setPanel(null);
    setError("");
    setSent(false);
  };
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#050609] p-4 text-white sm:p-7 lg:p-10">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_15%_10%,rgba(239,68,68,.18),transparent_28%),radial-gradient(circle_at_85%_80%,rgba(139,92,246,.14),transparent_30%)]" />
      <header className="relative mx-auto flex max-w-6xl items-center justify-between gap-4">
        <Logo heading={false} />
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={enterFullscreen}
            className="flex min-h-12 items-center gap-2 rounded-2xl border border-white/10 bg-white/[.06] px-4 font-bold text-slate-200 backdrop-blur-xl hover:bg-white/10"
          >
            <Fullscreen className="h-4 w-4" />
            <span className="hidden sm:inline">Pantalla completa</span>
          </button>
          <button
            type="button"
            onClick={() => setExitOpen(true)}
            className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.06] text-slate-300 backdrop-blur-xl"
            aria-label="Salir del modo kiosco"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </header>
      <section className="relative mx-auto mt-10 max-w-6xl">
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <p className="text-sm font-black uppercase tracking-[.22em] text-red-400">
              Autoservicio Albatros
            </p>
            <h1 className="mt-2 text-4xl font-black tracking-tight sm:text-5xl">
              ¿Qué deseas hacer?
            </h1>
            <p className="mt-3 text-lg text-slate-400">
              Selecciona una opción para comenzar.
            </p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-black tabular-nums">
              {now.toLocaleTimeString("es-MX", {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </p>
            <p className="text-sm capitalize text-slate-500">
              {now.toLocaleDateString("es-MX", {
                weekday: "long",
                day: "numeric",
                month: "long",
              })}
            </p>
          </div>
        </div>
        <div className="mt-9 grid gap-4 md:grid-cols-2">
          <ActionLink
            href="/login"
            label="Acceso atletas"
            description="Ingresa a tu cuenta y consulta tu progreso."
            icon={LogIn}
            tone="from-red-500/25 to-red-950/20"
            iconTone="bg-red-500 text-white"
          />
          <ActionLink
            href="/pagar"
            label="Realizar un pago"
            description="Consulta y completa una solicitud de pago."
            icon={CreditCard}
            tone="from-emerald-500/20 to-emerald-950/20"
            iconTone="bg-emerald-400 text-slate-950"
          />
          <ActionButton
            onClick={() => setPanel("schedules")}
            label="Consultar horarios"
            description="Revísalos aquí sin salir del modo kiosco."
            icon={CalendarDays}
            tone="from-amber-500/20 to-amber-950/20"
            iconTone="bg-amber-400 text-slate-950"
          />
          <ActionButton
            onClick={() => setPanel("trial")}
            label="Agendar clase de prueba"
            description="Envía una solicitud y el equipo se pondrá en contacto."
            icon={UserPlus}
            tone="from-violet-500/20 to-violet-950/20"
            iconTone="bg-violet-400 text-slate-950"
          />
        </div>
      </section>
      <footer className="relative mx-auto mt-8 flex max-w-6xl items-center justify-center gap-2 text-sm text-slate-600">
        <ShieldCheck className="h-4 w-4" />
        Tus datos se protegen y la sesión se cierra al terminar.
      </footer>
      {panel && (
        <div className="fixed inset-0 z-40 grid place-items-center overflow-y-auto bg-black/80 p-3 backdrop-blur-md sm:p-5">
          <section className="relative my-4 w-full max-w-4xl overflow-hidden rounded-[2rem] border border-white/15 bg-[#101116]/95 p-5 shadow-[0_28px_100px_rgba(0,0,0,.65)] md:p-8">
            <button
              type="button"
              onClick={closePanel}
              className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full border border-white/10 bg-white/[.07] text-slate-300 transition hover:bg-white/[.12] hover:text-white"
              aria-label="Cerrar"
            >
              <X className="h-5 w-5" />
            </button>
            {panel === "schedules" ? (
              <SchedulesCard />
            ) : (
              <TrialForm
                form={form}
                setForm={setForm}
                sent={sent}
                sending={sending}
                error={error}
                onSubmit={requestTrial}
                onDone={closePanel}
              />
            )}
          </section>
        </div>
      )}
      {exitOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/75 p-4 backdrop-blur-md">
          <form
            onSubmit={exit}
            className="w-full max-w-sm rounded-[2rem] border border-white/15 bg-[#111217]/95 p-6 shadow-2xl"
          >
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-red-500/15 text-red-400">
                <DoorOpen className="h-5 w-5" />
              </span>
              <div>
                <h2 className="font-black">Salir del modo kiosco</h2>
                <p className="text-sm text-slate-500">
                  Introduce el PIN administrativo.
                </p>
              </div>
            </div>
            <input
              autoFocus
              type="password"
              inputMode="numeric"
              maxLength={4}
              value={pin}
              onChange={(event) => {
                setPin(event.target.value.replace(/\D/g, "").slice(0, 4));
                setError("");
              }}
              className="mt-5 h-14 w-full rounded-2xl border border-white/10 bg-black/30 text-center text-2xl font-black tracking-[.5em] outline-none focus:border-red-400"
              placeholder="••••"
              aria-label="PIN para salir"
            />
            {error && (
              <p className="mt-2 text-sm font-bold text-red-400">{error}</p>
            )}
            <div className="mt-5 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  setExitOpen(false);
                  setPin("");
                  setError("");
                }}
                className="rounded-xl border border-white/10 px-4 py-3 font-bold text-slate-300"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={pin.length !== 4}
                className="rounded-xl bg-red-500 px-4 py-3 font-black disabled:opacity-40"
              >
                Salir
              </button>
            </div>
          </form>
        </div>
      )}
    </main>
  );
}

function ActionLink({
  href,
  label,
  description,
  icon: Icon,
  tone,
  iconTone,
}: {
  href: string;
  label: string;
  description: string;
  icon: typeof LogIn;
  tone: string;
  iconTone: string;
}) {
  return (
    <Link
      href={href}
      className={`group min-h-44 rounded-[2rem] border border-white/10 bg-gradient-to-br ${tone} p-6 shadow-[0_24px_70px_rgba(0,0,0,.35),inset_0_1px_rgba(255,255,255,.12)] backdrop-blur-2xl transition hover:-translate-y-1 hover:border-white/20`}
    >
      <ActionContent
        label={label}
        description={description}
        Icon={Icon}
        iconTone={iconTone}
      />
    </Link>
  );
}
function ActionButton({
  onClick,
  label,
  description,
  icon: Icon,
  tone,
  iconTone,
}: {
  onClick: () => void;
  label: string;
  description: string;
  icon: typeof LogIn;
  tone: string;
  iconTone: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`group min-h-44 rounded-[2rem] border border-white/10 bg-gradient-to-br ${tone} p-6 text-left shadow-[0_24px_70px_rgba(0,0,0,.35),inset_0_1px_rgba(255,255,255,.12)] backdrop-blur-2xl transition hover:-translate-y-1 hover:border-white/20`}
    >
      <ActionContent
        label={label}
        description={description}
        Icon={Icon}
        iconTone={iconTone}
      />
    </button>
  );
}
function ActionContent({
  label,
  description,
  Icon,
  iconTone,
}: {
  label: string;
  description: string;
  Icon: typeof LogIn;
  iconTone: string;
}) {
  return (
    <div className="flex h-full items-start gap-5">
      <span
        className={`grid h-16 w-16 shrink-0 place-items-center rounded-2xl ${iconTone} shadow-lg`}
      >
        <Icon className="h-7 w-7" />
      </span>
      <div className="min-w-0">
        <h2 className="text-2xl font-black">{label}</h2>
        <p className="mt-2 max-w-sm text-slate-400">{description}</p>
      </div>
      <ChevronRight className="ml-auto mt-5 h-6 w-6 text-white/40 transition group-hover:translate-x-1 group-hover:text-white" />
    </div>
  );
}
function SchedulesCard() {
  return (
    <div>
      <header className="pr-12">
        <p className="text-xs font-black uppercase tracking-[.22em] text-amber-300">
          Horarios oficiales
        </p>
        <h2 className="mt-1 text-3xl font-black tracking-tight text-white sm:text-4xl">
          Clases disponibles
        </h2>
        <p className="mt-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[.05] px-3 py-1.5 text-sm font-semibold text-slate-300">
          <MapPin className="h-4 w-4 text-amber-300" />
          Horarios vigentes en las sedes
        </p>
      </header>
      <div className="mt-6 grid gap-4">
        {schedules.map((item) => (
          <article
            key={item.discipline}
            className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/[.075] to-white/[.025] p-5 sm:p-6"
          >
            <i className={`absolute inset-y-0 left-0 w-1 ${item.tone}`} />
            <div className="flex flex-col gap-5 lg:flex-row lg:items-start">
              <div className="lg:w-52 lg:shrink-0">
                <h3 className="text-xl font-black tracking-tight text-white">
                  {item.discipline}
                </h3>
                <p className="mt-1 text-xs font-bold uppercase tracking-[.12em] text-slate-500">
                  Matutino y vespertino
                </p>
              </div>
              <div className="grid min-w-0 flex-1 gap-3 sm:grid-cols-2">
                {item.times.map((time) => {
                  const [shift, days, hour] = time.split(" · ");
                  return (
                    <div
                      key={time}
                      className="rounded-2xl border border-white/[.08] bg-black/20 p-4"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <span className="rounded-full bg-white/[.08] px-2.5 py-1 text-[10px] font-black uppercase tracking-[.14em] text-slate-300">
                          {shift}
                        </span>
                        <strong className="whitespace-nowrap text-base font-black text-white">
                          {hour}
                        </strong>
                      </div>
                      <p className="mt-3 text-sm font-medium leading-5 text-slate-300">
                        {days}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </article>
        ))}
      </div>
      <p className="mt-5 rounded-2xl border border-amber-300/10 bg-amber-300/[.05] px-4 py-3 text-xs leading-5 text-slate-400">
        Los horarios pueden cambiar durante eventos o días festivos. Confirma
        con recepción.
      </p>
    </div>
  );
}
function TrialForm({
  form,
  setForm,
  sent,
  sending,
  error,
  onSubmit,
  onDone,
}: {
  form: {
    nombre: string;
    telefono: string;
    disciplina: string;
    horario: string;
    sede: string;
    notas: string;
  };
  setForm: React.Dispatch<
    React.SetStateAction<{
      nombre: string;
      telefono: string;
      disciplina: string;
      horario: string;
      sede: string;
      notas: string;
    }>
  >;
  sent: boolean;
  sending: boolean;
  error: string;
  onSubmit: (event: React.FormEvent) => void;
  onDone: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const copyLink = async () => {
    await navigator.clipboard.writeText(
      `${window.location.origin}/clase-prueba`,
    );
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };
  if (sent)
    return (
      <div className="py-10 text-center">
        <CheckCircle2 className="mx-auto h-16 w-16 text-emerald-400" />
        <h2 className="mt-5 text-3xl font-black">Solicitud enviada</h2>
        <p className="mx-auto mt-2 max-w-md text-slate-400">
          El equipo de Albatros se pondrá en contacto para confirmar tu clase.
        </p>
        <button
          type="button"
          onClick={onDone}
          className="mt-7 rounded-xl bg-emerald-400 px-6 py-3 font-black text-slate-950"
        >
          Terminar
        </button>
      </div>
    );
  const set = (key: string, value: string) =>
    setForm((current) => ({ ...current, [key]: value }));
  return (
    <form onSubmit={onSubmit}>
      <div className="pr-12">
        <p className="text-xs font-black uppercase tracking-[.2em] text-violet-300">
          Primera visita
        </p>
        <h2 className="mt-1 text-3xl font-black">Agenda tu clase de prueba</h2>
        <p className="mt-2 text-sm text-slate-400">
          Déjanos tus datos y preferencias para confirmar tu lugar.
        </p>
        <button
          type="button"
          onClick={copyLink}
          className="mt-3 inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[.05] px-3 py-2 text-xs font-black text-slate-300 hover:bg-white/10"
        >
          <Copy className="h-3.5 w-3.5" />
          {copied ? "Enlace copiado" : "Copiar enlace directo"}
        </button>
      </div>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Nombre completo">
          <input
            value={form.nombre}
            onChange={(e) => set("nombre", e.target.value)}
            maxLength={80}
            className="kiosk-input"
          />
        </Field>
        <Field label="Teléfono">
          <input
            value={form.telefono}
            onChange={(e) =>
              set("telefono", e.target.value.replace(/[^\d +()-]/g, ""))
            }
            inputMode="tel"
            maxLength={20}
            className="kiosk-input"
          />
        </Field>
        <Field label="Disciplina">
          <select
            value={form.disciplina}
            onChange={(e) => {
              set("disciplina", e.target.value);
              set("horario", "");
            }}
            className="kiosk-input"
          >
            <option>Jiu-Jitsu</option>
            <option>Kick Boxing</option>
            <option>MMA</option>
          </select>
        </Field>
        <Field label="Sede">
          <select
            value={form.sede}
            onChange={(e) => set("sede", e.target.value)}
            className="kiosk-input"
          >
            <option value="CAUCEL">Caucel</option>
            <option value="MMA">MMA</option>
            <option value="JUAN_PABLO">Juan Pablo</option>
          </select>
        </Field>
        <Field label="Horario preferido">
          <select
            value={form.horario}
            onChange={(e) => set("horario", e.target.value)}
            className="kiosk-input"
          >
            <option value="">Selecciona una opción</option>
            {schedules
              .find((item) => item.discipline === form.disciplina)
              ?.times.map((time) => (
                <option key={time}>{time}</option>
              ))}
          </select>
        </Field>
        <Field label="Nota opcional">
          <input
            value={form.notas}
            onChange={(e) => set("notas", e.target.value)}
            maxLength={300}
            placeholder="Edad, experiencia o comentario"
            className="kiosk-input"
          />
        </Field>
      </div>
      {error && (
        <p
          role="alert"
          className="mt-4 rounded-xl bg-red-500/15 p-3 text-sm font-bold text-red-300"
        >
          {error}
        </p>
      )}
      <button
        type="submit"
        disabled={sending}
        className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-violet-400 px-6 py-4 font-black text-slate-950 disabled:opacity-50"
      >
        <Send className="h-4 w-4" />
        {sending ? "Enviando…" : "Enviar solicitud"}
      </button>
    </form>
  );
}
function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label>
      <span className="mb-1.5 block text-xs font-black uppercase tracking-wide text-slate-500">
        {label}
      </span>
      {children}
    </label>
  );
}
