import { NextResponse } from "next/server";

import { adminAuth, adminDb } from "@/lib/firebase-admin";
import {
  RequestAccessError,
  requireAdminActorAccess,
} from "@/lib/server-access";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UID_PATTERN = /^[A-Za-z0-9_-]{20,128}$/;

function isMissingAuthUser(error: unknown): boolean {
  const code = String((error as { code?: unknown })?.code || "");
  return code === "auth/user-not-found" || code.endsWith("/user-not-found");
}

function errorResponse(error: unknown) {
  if (error instanceof RequestAccessError) {
    return NextResponse.json(
      { ok: false, mensaje: error.message },
      { status: error.status },
    );
  }

  console.error("ADMIN_ACCESOS_ATLETAS_DELETE_ERROR:", error);
  return NextResponse.json(
    {
      ok: false,
      mensaje: "No se pudo eliminar la solicitud y su cuenta pendiente.",
    },
    { status: 500 },
  );
}

export async function DELETE(request: Request) {
  try {
    await requireAdminActorAccess(request);

    const body = (await request.json().catch(() => ({}))) as { uid?: unknown };
    const uid = typeof body.uid === "string" ? body.uid.trim() : "";
    if (!UID_PATTERN.test(uid)) {
      throw new RequestAccessError("La solicitud tiene un UID inválido.", 400);
    }

    const requestRef = adminDb.collection("SolicitudesAcceso").doc(uid);
    const profileRef = adminDb.collection("perfiles").doc(uid);
    const userRef = adminDb.collection("usuarios").doc(uid);
    const [requestSnapshot, userSnapshot] = await Promise.all([
      requestRef.get(),
      userRef.get(),
    ]);

    if (!requestSnapshot.exists) {
      throw new RequestAccessError("La solicitud ya no existe.", 404);
    }

    const requestData = requestSnapshot.data() || {};
    if (requestData.uid && requestData.uid !== uid) {
      throw new RequestAccessError("La solicitud contiene un UID inconsistente.", 409);
    }
    if (requestData.estado !== "pendiente") {
      throw new RequestAccessError(
        "Solo se pueden eliminar solicitudes que siguen pendientes.",
        409,
      );
    }
    if (userSnapshot.exists) {
      throw new RequestAccessError(
        "La cuenta ya está vinculada. Desactívala o desvincúlala antes de eliminarla.",
        409,
      );
    }

    let authUserDeleted = true;
    try {
      await adminAuth.deleteUser(uid);
    } catch (error) {
      if (!isMissingAuthUser(error)) throw error;
      authUserDeleted = false;
    }

    const batch = adminDb.batch();
    batch.delete(requestRef);
    batch.delete(profileRef);
    await batch.commit();

    return NextResponse.json({ ok: true, authUserDeleted });
  } catch (error) {
    return errorResponse(error);
  }
}
