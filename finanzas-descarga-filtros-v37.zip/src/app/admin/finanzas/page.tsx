"use client";

import { useEffect, useMemo, useState } from "react";
import { addDoc, collection, deleteDoc, doc, onSnapshot, query, serverTimestamp, Timestamp, where } from "firebase/firestore";
import { format } from "date-fns";
import { ArrowDownRight, ArrowUpRight, Calculator, Loader2, Plus, Scale, TrendingUp, WalletCards } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ManualExpenseEditor } from "@/components/finance/manual-expense-editor";
import { ManualMovementsList } from "@/components/finance/manual-movements-list";
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, canManageManualMovement, validateMovementDraft, type ManualFinanceRecord } from "@/lib/finance-manual-movements";
import { useFirestore, useUser } from "@/firebase";
import { dailyCashFlow, financeSummary, safeAmount, totalsByCategory, type FinanceMovement } from "@/lib/finance-calculations";

type FirestorePayment = { monto?: number; fecha?: Timestamp; metodoPago?: string; nombre?: string };
type ManualRecord = ManualFinanceRecord;


const COLORS = ["#f87171", "#fb923c", "#facc15", "#a78bfa", "#38bdf8", "#34d399", "#f472b6", "#94a3b8"];
const money = new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN", maximumFractionDigits: 2 });

export default function FinancePage() {
  const firestore = useFirestore(); const { user } = useUser();
  const [isAdmin, setIsAdmin] = useState(false);
  const [editing, setEditing] = useState<ManualRecord | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [manualPeriod, setManualPeriod] = useState("");
  const [manualError, setManualError] = useState("");
  useEffect(() => {
    setIsAdmin(false);
    if (!user) return;
    return onSnapshot(doc(firestore, "usuarios", user.uid), snapshot => {
      setIsAdmin(snapshot.data()?.activo === true && snapshot.data()?.rol === "admin");
    }, () => setIsAdmin(false));
  }, [firestore, user]);
  const [site, setSite] = useState("MMA"); const [month, setMonth] = useState(format(new Date(), "yyyy-MM"));
  const [payments, setPayments] = useState<FirestorePayment[]>([]); const [manual, setManual] = useState<ManualRecord[]>([]); const [loading, setLoading] = useState(true);
  const [type, setType] = useState<"ingreso" | "egreso">("egreso"); const [amount, setAmount] = useState(""); const [category, setCategory] = useState(EXPENSE_CATEGORIES[0]); const [concept, setConcept] = useState(""); const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd")); const [saving, setSaving] = useState(false); const [message, setMessage] = useState("");
  useEffect(() => { setSite(localStorage.getItem("userSede") || "MMA"); }, []);
  const range = useMemo(() => { const [year, monthNumber] = month.split("-").map(Number); return { year, monthIndex: monthNumber - 1, start: Timestamp.fromDate(new Date(year, monthNumber - 1, 1)), end: Timestamp.fromDate(new Date(year, monthNumber, 1)) }; }, [month]);
  useEffect(() => {
    setLoading(true); setManualError("");
    const paymentsQuery = query(collection(firestore, "Pagos"), where("sede", "==", site));
    const movementsQuery = query(collection(firestore, "MovimientosFinancieros"), where("sede", "==", site));
    let paymentReady = false; let movementReady = false; const finish = () => { if (paymentReady && movementReady) setLoading(false); };
    const inSelectedMonth = (value?: Timestamp) => { const milliseconds = value?.toMillis?.() || 0; return milliseconds >= range.start.toMillis() && milliseconds < range.end.toMillis(); };
    const stopPayments = onSnapshot(paymentsQuery, (snapshot) => { setPayments(snapshot.docs.map((entry) => entry.data() as FirestorePayment).filter((entry) => inSelectedMonth(entry.fecha))); paymentReady = true; finish(); }, () => { setPayments([]); setMessage("No se pudieron consultar los ingresos. Comprueba tu sesión y vuelve a intentar."); paymentReady = true; finish(); });
    const stopMovements = onSnapshot(movementsQuery, (snapshot) => { setManual(snapshot.docs.map((entry) => ({ ...(entry.data() as Omit<ManualRecord, "id">), id: entry.id })).filter((entry) => inSelectedMonth(entry.fecha))); setManualPeriod(`${site}-${month}`); setManualError(""); movementReady = true; finish(); }, () => { setManual([]); setManualPeriod(`${site}-${month}`); setManualError("No se pudieron cargar los movimientos. Comprueba tu conexión y recarga la página."); movementReady = true; finish(); });
    return () => { stopPayments(); stopMovements(); };
  }, [firestore, range.end, range.start, site, month]);
  const movements = useMemo<FinanceMovement[]>(() => [
    ...payments.map((payment, index) => ({ id: `pago-${index}`, type: "income" as const, amount: safeAmount(payment.monto), category: "Mensualidades", date: payment.fecha?.toDate?.() || new Date(0), source: "payment" as const })),
    ...manual.map((item) => ({ id: item.id, type: item.tipo === "ingreso" ? "income" as const : "expense" as const, amount: safeAmount(item.monto), category: item.categoria, date: item.fecha?.toDate?.() || new Date(0), source: "manual" as const })),
  ], [manual, payments]);
  const summary = useMemo(() => financeSummary(movements), [movements]);
  const expensesByCategory = useMemo(() => totalsByCategory(movements, "expense"), [movements]);
  const incomeByCategory = useMemo(() => totalsByCategory(movements, "income"), [movements]);
  const cashFlow = useMemo(() => dailyCashFlow(movements, range.year, range.monthIndex), [movements, range.monthIndex, range.year]);
  const daysElapsed = month === format(new Date(), "yyyy-MM") ? new Date().getDate() : new Date(range.year, range.monthIndex + 1, 0).getDate();
  async function addMovement(event: React.FormEvent) { event.preventDefault(); if (!user || saving) return; setSaving(true); setMessage(""); try { const values = validateMovementDraft({ amount, category, concept, date }, type); await addDoc(collection(firestore, "MovimientosFinancieros"), { sede: site, tipo: type, monto: values.monto, categoria: values.categoria, concepto: values.concepto, fecha: Timestamp.fromDate(values.date), creadoPor: user.uid, creadoEn: serverTimestamp() }); setAmount(""); setConcept(""); setMessage("Movimiento guardado."); } catch (error) { setMessage(error instanceof Error ? error.message : "No se pudo guardar."); } finally { setSaving(false); } }
  async function removeMovement(item: ManualRecord) {
    if (deletingId || !canManageManualMovement(item, user?.uid, isAdmin) || !window.confirm(`¿Eliminar “${item.concepto}”?`)) return;
    setDeletingId(item.id); setMessage("");
    try { await deleteDoc(doc(firestore, "MovimientosFinancieros", item.id)); setMessage("Movimiento eliminado."); }
    catch { setMessage("No se pudo eliminar el movimiento. Comprueba tus permisos y conexión."); }
    finally { setDeletingId(null); }
  }
  function changeType(next: "ingreso" | "egreso") { setType(next); setCategory(next === "egreso" ? EXPENSE_CATEGORIES[0] : INCOME_CATEGORIES[0]); }
  return <main className="finance-page min-h-screen w-full min-w-0 max-w-full overflow-x-hidden bg-[#08090c] px-4 py-6 text-white sm:px-6"><div className="mx-auto grid w-full min-w-0 max-w-7xl gap-6 overflow-hidden">
    <header className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#1a1c22] via-[#111319] to-[#0b1915] p-6"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="flex items-center gap-2 text-xs font-black uppercase tracking-[.2em] text-emerald-300"><WalletCards className="h-4 w-4" /> Finanzas · {site}</p><h1 className="mt-2 text-3xl font-black sm:text-4xl">Ingresos y egresos</h1><p className="mt-2 max-w-3xl text-sm text-white/70">Los pagos registrados se cuentan automáticamente como ingresos. Agrega otros ingresos, gastos de operación y gastos personales.</p></div><div><Label htmlFor="finance-month" className="text-white">Periodo</Label><Input id="finance-month" type="month" value={month} onChange={(event) => { if (/^\d{4}-\d{2}$/.test(event.target.value)) setMonth(event.target.value); }} className="mt-2 border-white/15 bg-black/30 text-white [color-scheme:dark]" /></div></div></header>
    <section aria-label="Resumen financiero" className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5"><Metric icon={ArrowUpRight} label="Ingresos" value={money.format(summary.income)} tone="emerald" /><Metric icon={ArrowDownRight} label="Egresos" value={money.format(summary.expenses)} tone="red" /><Metric icon={Scale} label="Resultado" value={money.format(summary.balance)} tone={summary.balance >= 0 ? "sky" : "red"} /><Metric icon={TrendingUp} label="Margen" value={`${summary.margin.toFixed(1)}%`} tone={summary.margin >= 0 ? "amber" : "red"} /><Metric icon={Calculator} label="Ingreso diario" value={money.format(summary.income / Math.max(1, daysElapsed))} tone="violet" /></section>
    {loading ? <div className="grid min-h-52 place-items-center rounded-3xl border border-white/10 bg-[#15171d]"><Loader2 className="h-7 w-7 animate-spin text-emerald-300" /></div> : <section className="grid gap-6 xl:grid-cols-[1.35fr_.65fr]"><ChartCard title="Flujo diario" subtitle="Ingresos contra egresos del periodo"><div className="h-72"><ResponsiveContainer width="100%" height="100%"><AreaChart data={cashFlow}><defs><linearGradient id="income" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#34d399" stopOpacity={.45}/><stop offset="95%" stopColor="#34d399" stopOpacity={0}/></linearGradient><linearGradient id="expense" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#f87171" stopOpacity={.4}/><stop offset="95%" stopColor="#f87171" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#ffffff14" vertical={false}/><XAxis dataKey="day" stroke="#cbd5e1" fontSize={11}/><YAxis stroke="#cbd5e1" fontSize={11} tickFormatter={(value) => `$${Number(value) / 1000}k`}/><Tooltip content={<DarkChartTooltip />} /><Legend/><Area type="monotone" dataKey="ingresos" stroke="#34d399" fill="url(#income)" strokeWidth={2}/><Area type="monotone" dataKey="egresos" stroke="#f87171" fill="url(#expense)" strokeWidth={2}/></AreaChart></ResponsiveContainer></div></ChartCard><ChartCard title="Categorías de egreso" subtitle={expensesByCategory[0] ? `Mayor gasto: ${expensesByCategory[0].name}` : "Sin egresos registrados"}><div className="h-72">{expensesByCategory.length ? <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={expensesByCategory} dataKey="value" nameKey="name" innerRadius={55} outerRadius={88} paddingAngle={3}>{expensesByCategory.map((entry, index) => <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />)}</Pie><Tooltip content={<DarkChartTooltip />} /><Legend wrapperStyle={{ fontSize: 11 }}/></PieChart></ResponsiveContainer> : <Empty text="Agrega un egreso para ver la distribución." />}</div></ChartCard><ChartCard title="Comparativo por categoría" subtitle="Composición de ingresos y egresos"><div className="h-72"><ResponsiveContainer width="100%" height="100%"><BarChart data={[...incomeByCategory.map((item) => ({ ...item, tipo: "Ingresos" })), ...expensesByCategory.map((item) => ({ ...item, tipo: "Egresos" }))]} layout="vertical"><CartesianGrid stroke="#ffffff14" horizontal={false}/><XAxis type="number" stroke="#cbd5e1" fontSize={11}/><YAxis dataKey="name" type="category" width={90} stroke="#cbd5e1" fontSize={10}/><Tooltip content={<DarkChartTooltip />} /><Bar dataKey="value" radius={[0, 8, 8, 0]}>{[...incomeByCategory, ...expensesByCategory].map((entry, index) => <Cell key={`${entry.name}-${index}`} fill={index < incomeByCategory.length ? "#34d399" : "#f87171"}/>)}</Bar></BarChart></ResponsiveContainer></div></ChartCard><ChartCard title="Indicadores" subtitle="Lectura rápida del periodo"><div className="grid gap-3 sm:grid-cols-2"><Indicator label="Pagos de alumnos" value={String(payments.length)} /><Indicator label="Movimientos manuales" value={String(manual.length)} /><Indicator label="Mayor egreso" value={expensesByCategory[0] ? money.format(expensesByCategory[0].value) : money.format(0)} /><Indicator label="Gasto / ingreso" value={summary.income ? `${((summary.expenses / summary.income) * 100).toFixed(1)}%` : "0%"} /></div></ChartCard></section>}
    <section className="grid gap-6 xl:grid-cols-[.7fr_1.3fr]"><form onSubmit={addMovement} className="rounded-3xl border border-white/10 bg-[#15171d] p-5"><h2 className="flex items-center gap-2 text-xl font-black"><Plus className="h-5 w-5 text-emerald-300" /> Nuevo movimiento</h2><div className="mt-5 grid gap-4"><div className="grid grid-cols-2 gap-2"><Button type="button" variant={type === "ingreso" ? "default" : "outline"} onClick={() => changeType("ingreso")}>Ingreso</Button><Button type="button" variant={type === "egreso" ? "destructive" : "outline"} onClick={() => changeType("egreso")}>Egreso</Button></div><Field label="Monto" id="finance-amount"><Input id="finance-amount" type="number" inputMode="decimal" min="0.01" max="10000000" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required className="border-white/15 bg-black/30 text-white" /></Field><Field label="Categoría" id="finance-category"><select id="finance-category" value={category} onChange={(e) => setCategory(e.target.value)} className="min-h-10 w-full rounded-md border border-white/15 bg-[#090a0d] px-3 text-white">{(type === "egreso" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES).map((item) => <option key={item}>{item}</option>)}</select></Field><Field label="Concepto" id="finance-concept"><Input id="finance-concept" value={concept} onChange={(e) => setConcept(e.target.value)} required minLength={2} maxLength={140} placeholder="Ej. recibo de electricidad" className="border-white/15 bg-black/30 text-white placeholder:text-white/50" /></Field><Field label="Fecha" id="finance-date"><Input id="finance-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} required className="border-white/15 bg-black/30 text-white [color-scheme:dark]" /></Field><Button disabled={saving || !user} className="min-h-11 font-black">{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Guardar movimiento</Button>{message && <p role="status" className="rounded-xl border border-white/15 bg-white/[.05] p-3 text-sm">{message}</p>}</div></form><ManualMovementsList key={`${site}-${month}`} records={manual} month={month} site={site} loading={loading || manualPeriod !== `${site}-${month}`} error={manualError} userId={user?.uid} isAdmin={isAdmin} deletingId={deletingId} onEdit={setEditing} onDelete={item => void removeMovement(item)} /></section>
  </div>{editing && user && <ManualExpenseEditor key={`${editing.id}-${user.uid}`} record={editing} isAdmin={isAdmin} onClose={() => setEditing(null)} onSaved={savedDate => { setEditing(null); setMonth(savedDate.slice(0, 7)); setMessage("Egreso actualizado. Totales y gráficas recalculados."); }} />}</main>;
}

function Metric({ icon: Icon, label, value, tone }: { icon: typeof Calculator; label: string; value: string; tone: "emerald" | "red" | "sky" | "amber" | "violet" }) { const colors = { emerald: "text-emerald-300", red: "text-red-300", sky: "text-sky-300", amber: "text-amber-300", violet: "text-violet-300" }; return <article className="rounded-2xl border border-white/10 bg-[#15171d] p-4"><Icon className={`h-5 w-5 ${colors[tone]}`} /><p className="mt-3 text-[10px] font-black uppercase tracking-wider text-white/70">{label}</p><p className="mt-1 break-words text-xl font-black">{value}</p></article>; }
function ChartCard({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) { return <article className="min-w-0 max-w-full overflow-hidden rounded-3xl border border-white/10 bg-[#15171d] p-5"><h2 className="text-lg font-black">{title}</h2><p className="mt-1 text-xs text-white/70">{subtitle}</p><div className="mt-5 min-w-0 max-w-full overflow-hidden">{children}</div></article>; }
function Indicator({ label, value }: { label: string; value: string }) { return <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-[10px] font-black uppercase tracking-wider text-white/70">{label}</p><p className="mt-1 text-xl font-black">{value}</p></div>; }
function Empty({ text }: { text: string }) { return <div className="grid h-full place-items-center text-center text-sm text-white/60">{text}</div>; }
function Field({ label, id, children }: { label: string; id: string; children: React.ReactNode }) { return <div><Label htmlFor={id} className="mb-2 block text-white">{label}</Label>{children}</div>; }
function DarkChartTooltip({ active, payload, label }: { active?: boolean; payload?: ReadonlyArray<{ name?: string; value?: string | number; color?: string }>; label?: string | number }) {
  if (!active || !payload?.length) return null;
  return <div className="rounded-xl border border-white/20 bg-[#090b10] px-4 py-3 text-white shadow-2xl"><p className="mb-1 font-bold text-white">{label ?? payload[0]?.name}</p>{payload.map((item, index) => <p key={`${item.name}-${index}`} className="font-semibold text-white"><span aria-hidden="true" className="mr-2 inline-block h-2 w-2 rounded-full" style={{ backgroundColor: item.color || "#f8fafc" }} />{item.name}: {money.format(Number(item.value) || 0)}</p>)}</div>;
}
