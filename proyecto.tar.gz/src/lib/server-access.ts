import { timingSafeEqual } from "node:crypto";

import { adminAuth, adminDb } from "@/lib/firebase-admin";
import {
  normalizarPerfilAcceso,
  puedeAdministrarSede,
  type PerfilAcceso,
  type Sede,
} from "@/lib/access-control";

export class RequestAccessError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
  }
}

function secureEquals(received: string, expected: string): boolean {
  const receivedBuffer = Buffer.from(received);
  const expectedBuffer = Buffer.from(expected);

  return (
    receivedBuffer.length === expectedBuffer.length &&
    timingSafeEqual(receivedBuffer, expectedBuffer)
  );
}

function bearerToken(request: Request): string {
  const authorization = request.headers.get("authorization") || "";
  return authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
}

function hasValidDeviceKey(request: Request): boolean {
  const group = (request.headers.get("x-device-group") || "")
    .trim()
    .toUpperCase();
  const expectedKey =
    group === "MMA_CAUCEL"
      ? process.env.RFID_DEVICE_KEY_MMA_CAUCEL || process.env.RFID_DEVICE_KEY
      : group === "JUAN_PABLO"
        ? process.env.RFID_DEVICE_KEY_JUAN_PABLO || process.env.RFID_DEVICE_KEY
        : process.env.RFID_DEVICE_KEY;
  const receivedKey = request.headers.get("x-device-key") || "";

  return Boolean(
    expectedKey && receivedKey && secureEquals(receivedKey, expectedKey),
  );
}

function deviceGroupCanAccessSite(request: Request, site: Sede): boolean {
  const group = (request.headers.get("x-device-group") || "")
    .trim()
    .toUpperCase();
  return site === "JUAN_PABLO"
    ? group === "JUAN_PABLO"
    : group === "MMA_CAUCEL";
}

export type PanelActorAccess = {
  uid: string;
  email?: string;
  profile: PerfilAcceso;
};

type ActorCacheEntry = { profile: PerfilAcceso; expiresAt: number };
const globalActorCache = globalThis as typeof globalThis & {
  __albatrosActorCache?: Map<string, ActorCacheEntry>;
};
const actorCache =
  globalActorCache.__albatrosActorCache ??
  (globalActorCache.__albatrosActorCache = new Map());
const ACTOR_CACHE_TTL_MS = 30_000;

async function getActiveActorFromToken(
  token: string,
): Promise<PanelActorAccess> {
  if (!token) {
    throw new RequestAccessError("Sesión requerida", 401);
  }

  let decodedToken;

  try {
    decodedToken = await adminAuth.verifyIdToken(token);
  } catch {
    throw new RequestAccessError("Sesión inválida o expirada", 401);
  }

  try {
    const cached = actorCache.get(decodedToken.uid);
    if (cached && cached.expiresAt > Date.now()) {
      return {
        uid: decodedToken.uid,
        email: decodedToken.email,
        profile: cached.profile,
      };
    }
    const userSnapshot = await adminDb
      .collection("usuarios")
      .doc(decodedToken.uid)
      .get();
    const profile = userSnapshot.exists
      ? normalizarPerfilAcceso(userSnapshot.data() || {})
      : null;

    if (!profile || !profile.activo) {
      throw new RequestAccessError("Cuenta inactiva o sin permisos", 403);
    }

    actorCache.set(decodedToken.uid, {
      profile,
      expiresAt: Date.now() + ACTOR_CACHE_TTL_MS,
    });

    return {
      uid: decodedToken.uid,
      email: decodedToken.email,
      profile,
    };
  } catch (error) {
    if (error instanceof RequestAccessError) throw error;
    console.error("FIREBASE_ADMIN_ACCESS_ERROR:", error);
    const code = String(
      (error as { code?: unknown; details?: unknown })?.code || "",
    ).toLowerCase();
    if (code.includes("resource-exhausted"))
      throw new RequestAccessError(
        "Firebase alcanzó temporalmente su límite de operaciones. Intenta de nuevo más tarde.",
        503,
      );
    if (code.includes("permission-denied"))
      throw new RequestAccessError(
        "La cuenta de servicio no tiene permisos para consultar Firebase.",
        503,
      );
    if (code.includes("unavailable") || code.includes("deadline-exceeded"))
      throw new RequestAccessError(
        "Firebase no está disponible temporalmente. Intenta de nuevo.",
        503,
      );
    throw new RequestAccessError(
      "No se pudo validar el acceso administrativo en Firebase.",
      503,
    );
  }
}

async function getPanelActor(request: Request): Promise<PanelActorAccess> {
  const actor = await getActiveActorFromToken(bearerToken(request));

  if (!["admin", "profesor"].includes(actor.profile.rol)) {
    throw new RequestAccessError("Cuenta sin permisos administrativos", 403);
  }

  return actor;
}

export async function requireActiveActorAccess(
  request: Request,
): Promise<PanelActorAccess> {
  return getActiveActorFromToken(bearerToken(request));
}

export async function requireActiveActorToken(
  token: string,
): Promise<PanelActorAccess> {
  return getActiveActorFromToken(token);
}

export async function requirePanelAccess(
  request: Request,
  sede: Sede,
): Promise<PerfilAcceso> {
  const actor = await requirePanelActorAccess(request, sede);
  return actor.profile;
}

export async function requirePanelActorAccess(
  request: Request,
  sede: Sede,
): Promise<PanelActorAccess> {
  const actor = await getPanelActor(request);

  if (!puedeAdministrarSede(actor.profile, sede)) {
    throw new RequestAccessError("No tienes acceso a esta sede", 403);
  }

  return actor;
}

export async function requireAdminActorAccess(
  request: Request,
): Promise<PanelActorAccess> {
  const actor = await getPanelActor(request);

  if (actor.profile.rol !== "admin") {
    throw new RequestAccessError(
      "Solo un administrador puede gestionar accesos biométricos",
      403,
    );
  }

  return actor;
}

export async function requireDeviceAccess(
  request: Request,
  site?: Sede,
): Promise<void> {
  if (
    !process.env.RFID_DEVICE_KEY &&
    !process.env.RFID_DEVICE_KEY_MMA_CAUCEL &&
    !process.env.RFID_DEVICE_KEY_JUAN_PABLO
  ) {
    throw new RequestAccessError(
      "La clave del dispositivo no está configurada",
      503,
    );
  }

  if (!hasValidDeviceKey(request)) {
    throw new RequestAccessError("Dispositivo no autorizado", 401);
  }

  if (site && !deviceGroupCanAccessSite(request, site)) {
    throw new RequestAccessError(
      "El grupo del dispositivo no corresponde a la sede",
      403,
    );
  }
}

export async function requirePanelOrDevice(
  request: Request,
  sede: Sede,
): Promise<void> {
  if (hasValidDeviceKey(request)) {
    if (!deviceGroupCanAccessSite(request, sede)) {
      throw new RequestAccessError(
        "El grupo del dispositivo no corresponde a la sede",
        403,
      );
    }
    return;
  }
  await requirePanelAccess(request, sede);
}
