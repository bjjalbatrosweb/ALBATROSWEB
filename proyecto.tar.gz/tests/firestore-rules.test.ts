import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

test('las colecciones exclusivamente servidor permanecen cerradas al cliente', async () => {
  const rules = await readFile(new URL('../firestore.rules', import.meta.url), 'utf8');
  for (const collection of ['TarjetasRFID', 'KioscoPins', 'KioscoPinsPorAlumno', 'KioscoEventos', 'DispositivosAcceso', 'RateLimits', 'ErroresWeb']) {
    const block = new RegExp(`match /${collection}/\\{[^}]+\\} \\{[\\s\\S]*?allow (?:read, write|write): if false;[\\s\\S]*?\\}`);
    assert.match(rules, block, `${collection} debe permanecer cerrada al cliente`);
  }
  assert.match(rules, /match \/MonitorDispositivos\/\{sede\}\/\{documento=\*\*\}[\s\S]*?allow read, write: if false;/);
});

test('la auditoría y movimientos administrativos no pueden editarse o borrarse', async () => {
  const rules = await readFile(new URL('../firestore.rules', import.meta.url), 'utf8');
  assert.match(rules, /match \/MovimientosAdmin\/\{movimientoId\}[\s\S]*?allow update, delete: if false;/);
  assert.match(rules, /match \/Auditoria\/\{sede\}\/movimientos\/\{movimientoId\}[\s\S]*?allow update, delete: if false;/);
});

test('incidencias y reservas validan sede, autoría y escrituras sensibles', async () => {
  const rules = await readFile(new URL('../firestore.rules', import.meta.url), 'utf8');
  assert.match(rules, /match \/IncidenciasOperativas\/\{incidenciaId\}/);
  assert.match(rules, /request\.resource\.data\.actorUid == request\.auth\.uid/);
  assert.match(rules, /match \/ReservasClases\/\{claseId\}/);
  assert.match(rules, /match \/inscripciones\/\{userId\}[\s\S]*?allow write: if false;/);
});

test('los movimientos financieros validan alta y limitan la corrección de egresos', async () => {
  const rules = await readFile(new URL('../firestore.rules', import.meta.url), 'utf8');
  assert.match(rules, /match \/MovimientosFinancieros\/\{movimientoId\}/);
  assert.match(rules, /request\.resource\.data\.monto > 0/);
  assert.match(rules, /request\.resource\.data\.creadoPor == request\.auth\.uid/);
  const block = rules.match(/match \/MovimientosFinancieros\/\{movimientoId\} \{[\s\S]*?\n    \}/)?.[0] || '';
  assert.match(block, /resource\.data\.tipo == 'egreso'/);
  assert.match(block, /affectedKeys\(\)\.hasOnly/);
  assert.match(block, /request\.resource\.data\.revision == resource\.data\.get\('revision', 0\) \+ 1/);
  assert.match(block, /isAdmin\(\) \|\| resource\.data\.creadoPor == request\.auth\.uid/);
});

test('las invitaciones PvP separan quién reta de quién responde', async () => {
  const rules = await readFile(new URL('../firestore.rules', import.meta.url), 'utf8');
  const block = rules.match(/match \/invitaciones\/\{invitationId\} \{[\s\S]*?\n      \}/)?.[0] || '';
  assert.match(block, /challengerId == userProfile\(\)\.alumnoId/);
  assert.match(block, /resource\.data\.challengedId == userProfile\(\)\.alumnoId/);
  assert.match(block, /request\.resource\.data\.status in \['aceptado', 'rechazado'\]/);
  assert.match(block, /affectedKeys\(\)\.hasOnly/);
  assert.match(block, /resource\.data\.status == 'pendiente'/);
  assert.match(block, /invitationId == request\.resource\.data\.tournamentId/);
  assert.match(block, /\.data\.estado == 'abierta'/);
  assert.match(block, /false &&/);
});
